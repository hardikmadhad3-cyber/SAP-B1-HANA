import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import './styles/Delivery.css';
import { useLocation, useNavigate } from 'react-router-dom';
import FormSettingsPanel from '../../components/purchase-order/FormSettingsPanel';
import HeaderUdfSidebar from '../../components/purchase-order/HeaderUdfSidebar';
import ContentsTab from './components/ContentsTab';
import LogisticsTab from './components/LogisticsTab';
import AccountingTab from './components/AccountingTab';
import TaxTab from './components/TaxTab';
import ElectronicDocumentsTab from './components/ElectronicDocumentsTab';
import EWayBillModal from './components/EWayBillModal';
import AttachmentsTab from './components/AttachmentsTab';
import ReferenceDocumentsModal from '../sales-order/components/ReferenceDocumentsModal';
import AddressModal from '../../components/document/AddressComponentModal';
import { formatAddressComponent, mapAddressFields, pickAddressComponentFields } from '../../utils/documentAddress';
import TaxInfoModal from './components/TaxInfoModal';
import BatchAllocationModal from './components/BatchAllocationModal';
import BusinessPartnerModal from '../sales-order/components/BusinessPartnerModal';
import StateSelectionModal from '../../components/common/StateSelectionModal';
import HSNCodeModal from '../../components/common/HSNCodeModal';
import ItemSelectionModal from '../../components/common/ItemSelectionModal';
import QualitySelectionModal from '../sales-order/components/QualitySelectionModal';
import FreightChargesModal from '../../components/freight/FreightChargesModal';
import DocumentCurrencySelect from '../../components/document/DocumentCurrencySelect';
import SapGoldenArrowButton from '../../components/document/SapGoldenArrowButton';
import PrintLayoutToolbar from '../../components/print-layout/PrintLayoutToolbar';
import { useRelationshipMapRegistration } from '../../components/relationship-map/RelationshipMapHost';
import { summarizeFreightRows } from '../../components/freight/freightUtils';
import CopyFromModal from '../../components/document/CopyFromModal';
import { useSapWindowTaskbarActions } from '../../components/SapWindowTaskbarContext';
import { copyToDocument } from '../../services/documentCopyService';
import { filterWarehousesByBranch, getWarehouseBranchId } from '../../utils/warehouseBranch';
import { hydrateDocumentLineFromItem, mergeItemMaster } from '../../utils/documentItemHydration';
import { FALLBACK_UOM, FALLBACK_WAREHOUSES } from '../../utils/fallbackReferenceData';
import { getDefaultSeriesForCurrentYear } from '../../utils/seriesDefaults';
import { readGeneralSettings } from '../../utils/generalSettingsStorage';
import { useCompanyScopedFormSettings } from '../../utils/formSettingsStorage';
import { buildVisibleEnteredRowUdfPayload } from '../../utils/rowUdfPayload';
import { getStateCodeValue, getStateDisplayName } from '../../utils/stateDisplay';
import { findTaxCode, getTaxComponentCodes } from '../../utils/taxCodeComponents';
import { isRouteStateForActiveCompany } from '../../utils/companyStorageScope';
import {
  consumeCopyToState as consumePersistedCopyToState,
  replaceRouteStatePreservingWindow,
} from '../../utils/copyToState';
import { openLinkedBusinessPartner, openLinkedReferenceDocument } from '../../utils/sapLinkedNavigation';
import { buildDuplicateLines, duplicateDocumentInPlace } from '../../utils/documentDuplicate';
import useValidationHighlights from '../../utils/useValidationHighlights';
import {
  BATCH_QTY_TOLERANCE,
  getLineUomFactor,
  getRequiredBatchQty,
  sumBatchQty,
} from '../../utils/batchQuantity';
import { determineTaxCode, recalculateAllTaxCodes, getGSTTypeLabel } from '../../utils/taxEngine';
import { useAuth } from '../../auth/AuthContext';
import { getDocumentLayout } from '../../api/sapLayoutApi';
import {
  DELIVERY_LAYOUT_DOCUMENT_TYPE,
  buildSalesOrderMatrixColumnsFromLayout,
} from '../sales-order/documentLayout';
import { hydrateWorkbookDocumentLine } from '../../utils/workbookLineHydration';
import {
  fetchDeliveryReferenceData,
  fetchDeliveryByDocEntry,
  fetchDeliveryCustomerDetails,
  fetchItemsForModal,
  fetchUomConversionFactor,
  submitDelivery,
  updateDelivery,
  fetchDocumentSeries,
  fetchNextNumber,
  fetchOpenSalesOrders,
  fetchSalesOrderForCopy,
  fetchOpenSalesQuotationsForDelivery,
  fetchSalesQuotationForDeliveryCopy,
  fetchOpenReturnsForDelivery,
  fetchReturnForDeliveryCopy,
  fetchOpenBlanketAgreementsForDelivery,
  fetchBlanketAgreementForDeliveryCopy,
  fetchBatchesByItem,
  fetchFreightCharges,
  validateDeliveryDocument,
  createDeliveryLookupValue,
  saveDeliverySalesEmployeesSetup
} from '../../api/deliveryApi';
import { fetchSalesOrderByDocEntry, fetchSalesOrderReferenceDocumentLookup } from '../../api/salesOrderApi';
import { fetchHSNCodeFromItem } from '../../api/hsnCodeApi';
import { deliveryCopyFromApi, normaliseDocumentHeader, normaliseDocumentLine, BASE_TYPE } from '../../api/copyFromApi';
import {
  FORM_SETTINGS_STORAGE_KEY,
  HEADER_UDF_DEFINITIONS,
  ROW_UDF_DEFINITIONS,
  BASE_MATRIX_COLUMNS,
  createUdfState,
  filterDeliveryRowUdfDefinitions,
  normalizeUdfState,
  readSavedFormSettings,
} from '../../config/deliveryForm';

// ─── helpers ─────────────────────────────────────────────────────────────────
const getErrMsg = (e, fb) => {
  const body = e?.response?.data || {};
  const d = body.detail || body.details;
  if (typeof d === 'string' && d.trim()) return d;
  if (d?.error?.message) return d.error.message;
  if (d?.message) return d.message;
  if (body.message) return d?.hint ? `${body.message} ${d.hint}` : body.message;
  return e?.message || fb;
};
const today = () => new Date().toISOString().split('T')[0];
const parseNum = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const firstNonBlank = (...values) => {
  for (const value of values) {
    if (value !== undefined && value !== null && String(value).trim() !== '') return value;
  }
  return '';
};
const roundTo = (v, d) => { const f = 10 ** Math.max(d, 0); return Math.round((v + Number.EPSILON) * f) / f; };

const hasUdfValue = (value) => value !== undefined && value !== null && String(value).trim() !== '';
const mergeUdfValues = (...sources) =>
  sources.reduce((acc, source) => {
    Object.entries(source || {}).forEach(([key, value]) => {
      if (hasUdfValue(value) || acc[key] === undefined) {
        acc[key] = value ?? '';
      }
    });
    return acc;
  }, {});

const pickLineUdfValues = (source = {}) =>
  Object.entries(source || {}).reduce((acc, [key, value]) => {
    if (String(key || '').toUpperCase().startsWith('U_')) {
      acc[key] = value ?? '';
    }
    return acc;
  }, {});

const normalizeMirrorToken = (value) =>
  String(value || '')
    .trim()
    .toUpperCase()
    .replace(/^U_/, '')
    .replace(/[^A-Z0-9]/g, '');

const getFieldMirrorTokens = (fieldOrValues) => {
  const values = Array.isArray(fieldOrValues)
    ? fieldOrValues
    : [
        fieldOrValues?.key ?? fieldOrValues,
        fieldOrValues?.sapField,
        fieldOrValues?.aliasId,
        fieldOrValues?.label,
        fieldOrValues?.description,
        fieldOrValues?.Descr,
      ];

  return values.map(normalizeMirrorToken).filter(Boolean);
};

const findMatchingRowUdfKeys = (sourceFieldOrValues, rowUdfDefinitions = []) => {
  const sourceTokens = new Set(getFieldMirrorTokens(sourceFieldOrValues));
  if (!sourceTokens.size) return [];

  return (rowUdfDefinitions || [])
    .filter((field) => getFieldMirrorTokens(field).some((token) => sourceTokens.has(token)))
    .map((field) => field.key)
    .filter(Boolean);
};

const unwrapSalesOrderDocument = (data = {}) =>
  data.sales_order || data.salesOrder || data.document || data;

const getDocumentLines = (document = {}) => {
  const lines = document.DocumentLines || document.lines || [];
  return Array.isArray(lines) ? lines : [];
};

const getLineIdentity = (line = {}, fallbackIndex = null) =>
  line.LineNum ?? line.lineNum ?? line.BaseLine ?? line.baseLine ?? fallbackIndex;

const mergeSalesOrderCopyUdfs = (copyData = {}, detailData = {}) => {
  const detailDocument = unwrapSalesOrderDocument(detailData);
  const detailHeaderUdfs = mergeUdfValues(detailDocument.header_udfs, detailDocument.headerUdfs);
  const copyHeaderUdfs = mergeUdfValues(copyData.header_udfs, copyData.headerUdfs);
  const mergedHeaderUdfs = mergeUdfValues(detailHeaderUdfs, copyHeaderUdfs);
  const copyLines = getDocumentLines(copyData);
  const detailLines = getDocumentLines(detailDocument);

  const detailLinesByIdentity = new Map();
  detailLines.forEach((line, index) => {
    const identity = getLineIdentity(line, index);
    if (identity !== null && identity !== undefined) {
      detailLinesByIdentity.set(String(identity), line);
    }
  });

  const mergedLines = copyLines.map((line, index) => {
    const identity = getLineIdentity(line, index);
    const detailLine = detailLinesByIdentity.get(String(identity)) || detailLines[index] || {};

    return {
      ...line,
      udf: mergeUdfValues(
        pickLineUdfValues(detailLine),
        detailLine.udf,
        detailLine.line_udfs,
        detailLine.lineUdfs,
        pickLineUdfValues(line),
        line.udf,
        line.line_udfs,
        line.lineUdfs
      ),
    };
  });

  return {
    ...copyData,
    header_udfs: mergedHeaderUdfs,
    headerUdfs: mergedHeaderUdfs,
    DocumentLines: mergedLines.length ? mergedLines : copyLines,
  };
};
const isEmptyBranchValue = (value) => {
  const normalized = String(value ?? '').trim().toLowerCase();
  return !normalized || normalized === '0' || normalized === '-1' || normalized === 'no branch' || normalized === 'select branch';
};
const normalizeSubmitBranch = (value) =>
  isEmptyBranchValue(value) ? '' : String(value).trim();
const getWarehouseCode = (warehouse = {}) =>
  !warehouse || typeof warehouse !== 'object'
    ? ''
    :
  warehouse.WhsCode ?? warehouse.whsCode ?? warehouse.code ?? '';
const findWarehouse = (warehouses = [], warehouseCode = '') => {
  const normalizedWarehouse = String(warehouseCode || '').trim();
  if (!normalizedWarehouse) return null;
  return (warehouses || []).find((entry) => String(getWarehouseCode(entry) || '').trim() === normalizedWarehouse) || null;
};
const getWarehouseBranchValue = (warehouses = [], warehouseCode = '') =>
  normalizeSubmitBranch(getWarehouseBranchId(findWarehouse(warehouses, warehouseCode)));
const resolveBatchWarehouseCode = (lineWarehouse = '', headerWarehouse = '') =>
  String(headerWarehouse || lineWarehouse || '').trim();
const alignBranchWithWarehouse = (branch, warehouseCode, warehouses = []) => {
  const normalizedBranch = normalizeSubmitBranch(branch);
  if (!normalizedBranch) return '';

  const normalizedWarehouse = String(warehouseCode || '').trim();
  if (!normalizedWarehouse) return normalizedBranch;

  const warehouseBranch = getWarehouseBranchValue(warehouses, warehouseCode);

  if (!warehouseBranch) return normalizedBranch;
  return normalizedBranch === warehouseBranch ? normalizedBranch : warehouseBranch;
};
const resolveCopiedBranchWarehouse = ({
  sourceBranch,
  sourceWarehouse,
  fallbackWarehouse,
  warehouses = [],
} = {}) => {
  const warehouse = String(sourceWarehouse || fallbackWarehouse || '').trim();
  const branch = normalizeSubmitBranch(sourceBranch)
    ? alignBranchWithWarehouse(sourceBranch, warehouse, warehouses)
    : '';

  return {
    branch: isEmptyBranchValue(branch) ? '' : String(branch),
    warehouse,
  };
};
const fmtDec = (v, d) => { if (v === '' || v == null) return ''; const n = Number(v); return Number.isNaN(n) ? '' : n.toFixed(Math.max(d, 0)); };
const calcRoundingAmount = (value, decimals) => roundTo(Math.round(value) - value, decimals);
const TAX_SENSITIVE_LINE_FIELDS = new Set(['itemNo', 'quantity', 'unitPrice', 'stdDiscount', 'taxCode', 'uomCode']);
const sanitize = (v, d) => {
  const c = String(v ?? '').replace(/[^\d.-]/g, '').replace(/(?!^)-/g, '').replace(/^(-?)\./, '$10.').replace(/(\..*)\./g, '$1');
  if (!c) return '';
  if (!c.includes('.')) return c;
  const [w, f] = c.split('.');
  return `${w}.${(f || '').slice(0, Math.max(d, 0))}`;
};
const fmtAddr = (a) => {
  if (!a) return '';
  return [[a.Street, a.StreetNo], [a.Block, a.Building, a.Address2, a.Address3],
  [a.City, a.County, a.State, a.ZipCode], [a.Country]]
    .map(p => p.filter(Boolean).join(', ')).filter(Boolean).join('\n');
};
const mapAddressToModalForm = (address, existing = {}) => ({
  shipToCode: existing.shipToCode || '',
  shipToAddress: existing.shipToAddress || '',
  billToCode: existing.billToCode || '',
  billToAddress: existing.billToAddress || '',
  streetPoBox: address?.Street || '',
  streetNo: address?.StreetNo || '',
  buildingFloorRoom: address?.BuildingFloorRoom || address?.Building || '',
  block: address?.Block || '',
  city: address?.City || '',
  zipCode: address?.ZipCode || '',
  county: address?.County || '',
  state: address?.State || '',
  countryRegion: address?.Country || '',
  addressName2: address?.AddressName2 || address?.Address2 || '',
  addressName3: address?.AddressName3 || address?.Address3 || '',
  gln: address?.GlobalLocationNumber || address?.GlblLocNum || address?.GLN || '',
  erpAddress: address?.U_ERPAddress || address?.U_ERP_Address || address?.ERPAddress || '',
  contactPerson: address?.U_ContactPerson || address?.U_CONTACT_PERSON || address?.ContactPerson || '',
  mobile: address?.U_Mobile || address?.U_MOBILE || address?.Mobile || address?.MobilePhone || '',
  dateOfRegistration: address?.U_DateOfRegistration || address?.U_Date_Of_Registration || address?.DateOfRegistration || '',
  dateDetailsOfRegistration: address?.U_DateDetlOfReg || address?.U_Date_Detl_Of_Reg || address?.DateDetlOfReg || '',
  addressStatus: address?.U_Status || address?.AddressStatus || address?.Status || '',
  gstin: address?.GSTRegnNo || address?.GSTIN || address?.U_GSTIN_No || address?.U_GSTINNo || '',
  ...mapAddressFields(address),
});
const normalizeAddressText = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[\r\n]+/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
const isTruthySapFlag = (value) => {
  if (value === true || value === 1) return true;
  const text = String(value ?? '').trim().toUpperCase();
  return ['Y', 'YES', 'TRUE', 'TYES', '1'].includes(text);
};
const isBatchManaged = (item) => {
  if (!item) return false;

  return [
    item.BatchManaged,
    item.batchManaged,
    item.ManBtchNum,
    item.ManageBatchNumbers,
    item.manageBatchNumbers,
    item.isBatchManaged,
  ].some(isTruthySapFlag);
};
const isLineBatchManaged = (line = {}, item = null) => (
  [
    line.BatchManaged,
    line.batchManaged,
    line.ManBtchNum,
    line.ManageBatchNumbers,
    line.manageBatchNumbers,
    line.isBatchManaged,
  ].some(isTruthySapFlag) || isBatchManaged(item)
);
// Check if batches are available for item in specific warehouse
const checkBatchAvailability = async (itemCode, whsCode) => {
  if (!itemCode || !whsCode) return false;
  
  try {
    console.log('🔍 [checkBatchAvailability] Checking batches for:', { itemCode, whsCode });
    const response = await fetchBatchesByItem(itemCode, whsCode);
    console.log('🔍 [checkBatchAvailability] API Response:', response);
    
    const batches = response.data?.batches || [];
    const hasBatches = batches.length > 0;
    
    console.log('🔍 [checkBatchAvailability] Found batches:', batches.length, 'Has batches:', hasBatches);
    console.log('🔍 [checkBatchAvailability] Batch details:', batches);
    
    return hasBatches;
  } catch (error) {
    console.error('❌ [checkBatchAvailability] Error:', error);
    // If there's an error, assume batches are available for batch-managed items
    // This prevents the button from being hidden due to API errors
    return true;
  }
};

// ─── static fallbacks ────────────────────────────────────────────────────────
const FALLBACK_PAYMENT_TERMS = [
  { value: '0', label: 'Immediate' },
  { value: '1', label: 'Net 30' },
  { value: '2', label: 'Net 60' },
  { value: '3', label: 'Net 90' },
];
const FALLBACK_SHIPPING = [
  { value: '1', label: 'Air' },
  { value: '2', label: 'Sea' },
  { value: '3', label: 'Road' },
  { value: '4', label: 'Courier' },
];
// ─── constants ────────────────────────────────────────────────────────────────
const DEC = { QtyDec: 2, PriceDec: 2, SumDec: 2, RateDec: 2, PercentDec: 2 };
const TAB_NAMES = ['Contents', 'Logistics', 'Accounting', 'Tax', 'Electronic Documents', 'Attachments'];

const DELIVERY_LINE_UPDATE_FIELDS = [
  'lineNum', 'baseEntry', 'baseType', 'baseLine', 'itemNo', 'quantity', 'unitPrice',
  'whse', 'uomEntry', 'uomCode', 'taxCode', 'distRule', 'freeText', 'sacCode',
  'countryOfOrigin', 'specialRebate', 'commission', 'sellerBrokeragePerQty',
  'unitPriceUdf', 'discountAmount', 'sellerBrokerage', 'buyerBrokerage',
  'buyerDelivery', 'sellerDelivery', 'buyerPaymentTerms', 'sellerPaymentTerms',
  'buyerQuality', 'sellerQuality', 'buyerPrice', 'sellerPrice',
  'buyerSpecialInstruction', 'sellerSpecialInstruction', 'sellerBrokerageAmtPer',
  'sellerBrokeragePercent', 'buyerBillDiscount', 'sellerBillDiscount', 'stcode',
  'sellerItem', 'sellerQty', 'freightPurchase', 'freightSales', 'freightProvider',
  'freightProviderName', 'brokerageNumber', 'packingType', 'grossWt', 'totalPackage',
];

const stableSignatureObject = (value) => {
  if (Array.isArray(value)) return value.map(stableSignatureObject);
  if (!value || typeof value !== 'object') return value ?? '';
  return Object.keys(value).sort().reduce((result, key) => {
    result[key] = stableSignatureObject(value[key]);
    return result;
  }, {});
};

const getDeliveryLinesUpdateSignature = (documentLines = []) => JSON.stringify(
  (documentLines || [])
    .filter((line) => String(line?.itemNo || '').trim())
    .map((line) => ({
      ...DELIVERY_LINE_UPDATE_FIELDS.reduce((result, key) => {
        result[key] = line?.[key] ?? '';
        return result;
      }, {}),
      batches: (line?.batches || []).map((batch) => ({
        batchNumber: String(batch?.batchNumber || '').trim(),
        quantity: String(batch?.quantity ?? ''),
      })),
      udf: stableSignatureObject(line?.udf || {}),
    }))
);

const createLine = (rowUdfDefinitions = ROW_UDF_DEFINITIONS, headerUdfsParam = {}) => ({
  itemNo: '', itemDescription: '',
  sellerQuality: '', buyerQuality: '',
  hsnCode: '', quantity: '', unitPrice: '',
  sellerPrice: '', buyerPrice: '',
  sellerDelivery: '', buyerDelivery: '',
  sellerBrokerageAmtPer: '', sellerBrokeragePercent: '',
  sellerBrokerage: '', buyerBrokerage: '',
  specialRebate: '', commission: '', sellerBrokeragePerQty: '', unitPriceUdf: '',
  buyerPaymentTerms: '', sellerPaymentTerms: '', buyerSpecialInstruction: '', sellerSpecialInstruction: '',
  buyerBillDiscount: '', sellerBillDiscount: '', sellerItem: '', sellerQty: '',
  freightPurchase: '', freightSales: '', freightProvider: '', freightProviderName: '',
  brokerageNumber: '',
  uomCode: '', stdDiscount: '', stcode: '', taxCode: '', total: '', taxAmount: '', whse: '',
  uomName: '', price: '', priceAfterDiscount: '', itemCost: '', binLocationAllocation: '',
  distRule: '', freeText: '', countryOfOrigin: '', sacCode: '',
  openQty: '', deliveredQty: '', documentCreated: '',
  loc: '', branch: '', lineNum: undefined, baseEntry: null, baseType: null, baseLine: null,
  batchManaged: false, batches: [],
  hasBatchesAvailable: false, // Track if batches are available for this item-warehouse combo
  inventoryUOM: '', // Base UoM from item master
  uomFactor: 1, // Conversion factor: Document UoM to Base UoM
  // Merge provided header UDFs into line UDF defaults so header values auto-fill matching row UDFs
  udf: mergeUdfValues(createUdfState(rowUdfDefinitions), headerUdfsParam || {}),
});

const needsBatchAllocation = (line = {}) => (
  Boolean(line.batchManaged) &&
  Boolean(String(line.itemNo || '').trim()) &&
  Boolean(String(line.whse || '').trim()) &&
  parseNum(line.quantity) > 0 &&
  (!Array.isArray(line.batches) || line.batches.length === 0) &&
  line.hasBatchesAvailable !== false
);

const clearBaseDocumentLink = (line = {}) => ({
  ...line,
  baseEntry: null,
  baseType: null,
  baseLine: null,
  BaseEntry: null,
  BaseType: null,
  BaseLine: null,
  lineNum: undefined,
  LineNum: undefined,
});

const INIT_HEADER = {
  vendor: '', name: '', contactPerson: '', salesContractNo: '', branch: '', warehouse: '',
  docNo: '', status: 'Open', series: '', nextNumber: '',
  postingDate: today(), deliveryDate: today(), documentDate: today(), contractDate: '',
  branchRegNo: '', shipTo: '', shipToCode: '', payTo: '', payToCode: '',
  shippingType: '', confirmed: false, journalRemark: '', paymentTerms: '',
  paymentMethod: '', otherInstruction: '', discount: '', freight: '', tax: '',
  totalPaymentDue: '', rounding: false, owner: '', purchaser: '',
  placeOfSupply: '', currency: 'INR', useBillToForTax: false,
  billToAddress: '', billToCode: '', shipToAddress: '',
  shipToAddressComponents: null, billToAddressComponents: null,
  edocGenerationType: 'edocGenerateLater', edocExportFormat: '', edocStatus: '',
  languageCode: '', trackingNo: '', stampNo: '', pickAndPackRemarks: '', bpChannelCode: '', bpChannelContact: '',
  centralBankIndicator: '', projectCode: '', qrCodeSource: '', indicator: '', orderNumber: '',
  consolidationType: '', consolidatingBP: '', useShippedGoodsAccount: false,
  transactionCategory: '', taxFormNo: '', dutyStatus: '', exportFlag: false,
  differentialTaxRate: '100', supplyCovered: false,
};

const normalizeDeliveryReferenceDocuments = (rows = []) => (
  (Array.isArray(rows) ? rows : [])
    .map((row) => ({
      lineNum: row.lineNum ?? row.LineNum ?? undefined,
      direction: row.direction || 'to',
      transactionType: String(row.transactionType ?? row.referencedObjectType ?? row.RefObjType ?? row.RefType ?? ''),
      docEntry: String(row.docEntry ?? row.referencedDocEntry ?? row.RefDocEntr ?? row.RefDocEntry ?? ''),
      docNumber: String(row.docNumber ?? row.referencedDocNumber ?? row.RefDocNum ?? row.RefDocNo ?? ''),
      extDocNumber: String(row.extDocNumber ?? row.externalDocNumber ?? row.ExtDocNum ?? ''),
      issueDate: row.issueDate || row.IssueDate || '',
      remark: row.remark || row.Remark || row.Comments || '',
    }))
    .filter((row) => String(row.transactionType || row.docNumber || row.docEntry || row.extDocNumber || '').trim())
);
const hasCompleteDeliveryReferenceDocument = (row = {}) => (
  String(row.transactionType || '').trim() &&
  String(row.docEntry || row.docNumber || row.extDocNumber || '').trim()
);

const createInitialHeader = (settings = readGeneralSettings()) => ({
  ...INIT_HEADER,
  warehouse: settings.deliveryWarehouse || '',
  series: settings.deliverySeries || '',
  postingDate: today(),
  deliveryDate: today(),
  documentDate: today(),
});

const compactColumnToken = (value) => String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

const DELIVERY_ACTUAL_MATRIX_COLUMNS = BASE_MATRIX_COLUMNS.filter((column) => column.key !== 'batch');
const DELIVERY_ACTUAL_MATRIX_KEY_SET = new Set(DELIVERY_ACTUAL_MATRIX_COLUMNS.map((column) => column.key));

const DELIVERY_COLUMN_EXTRA_TOKENS = {
  itemNo: ['ITEMCODE'],
  itemDescription: ['DSCRIPTION', 'DESCRIPTION'],
  uomName: ['UNITMSR', 'UOMNAME'],
  hsnCode: ['HSNCODE', 'HSNENTRY'],
  unitPrice: ['UNITPRICE', 'PRICEBEFDI'],
  taxCode: ['VATGROUP'],
  totalLC: ['LINETOTAL', 'GTOTAL', 'TOTAL'],
  whse: ['WHSCODE', 'WAREHOUSE'],
  binLocationAllocation: ['BINALLOC', 'BINALLOCATION', 'BINLOCATIONALLOCATION'],
  priceAfterDiscount: ['PRICEAFTERDISCOUNT'],
  itemCost: ['ITEMCOST'],
  taxCodeRepeat: ['UTAXCODE'],
  price: ['UPRICE'],
  sellerBrokerage: ['UBROKSELLER'],
  buyerBrokerage: ['UBROKBUYER'],
  buyerDelivery: ['UBUYERDELIVERY'],
  sellerDelivery: ['USELLERDELIVERY'],
  buyerPaymentTerms: ['UBUYERPAYMENTTERMS'],
  sellerPaymentTerms: ['USELLERPAYMENTTERM', 'USELLERPAYMENTTERMS'],
  buyerQuality: ['UBUYERQUALITY'],
  sellerQuality: ['USELLERQUALITY'],
  buyerPrice: ['UBUYERPRICE'],
  sellerPrice: ['USELLERPRICE'],
  buyerSpecialInstruction: ['UBUYERSPINS'],
  sellerSpecialInstruction: ['USELLERSPINS'],
  sellerBrokerageAmtPer: ['USELBROKAP'],
  sellerBrokeragePercent: ['USELLERBROKPER'],
  stcode: ['USELLTCODE'],
  sellerItem: ['USITEM'],
  sellerQty: ['USQTY'],
  specialRebate: ['USPLRBT'],
  commission: ['UCOMPRC', 'COMMISSION'],
  sellerBrokeragePerQty: ['USBROKPERQTY'],
  U_Fix_Brock_B: ['UFIXBROKBUYER', 'UFIXBROCKB', 'UFIXBROKB'],
  U_Fix_Brock_S: ['UFIXBROCKSELLER', 'UFIXBROKSELLER', 'UFIXBROCKS', 'UFIXBROKS'],
};

const buildDeliveryColumnTokenMap = () => {
  const map = new Map();
  const add = (token, key) => {
    const normalized = compactColumnToken(token);
    if (normalized && !map.has(normalized)) map.set(normalized, key);
  };

  DELIVERY_ACTUAL_MATRIX_COLUMNS.forEach((column) => {
    [column.key, column.valueKey, column.rendererKey, column.label].forEach((token) => add(token, column.key));
  });
  Object.entries(DELIVERY_COLUMN_EXTRA_TOKENS).forEach(([key, tokens]) => {
    tokens.forEach((token) => add(token, key));
  });

  return map;
};

const DELIVERY_COLUMN_KEY_BY_TOKEN = buildDeliveryColumnTokenMap();

const getDeliveryColumnIdentity = (column = {}) => {
  if (DELIVERY_ACTUAL_MATRIX_KEY_SET.has(column.key)) return column.key;

  const rawLabel = String(column.label || column.columnTitle || '').trim();
  const rawField = String(column.sapField || column.fieldName || column.layoutFieldName || '').trim();
  const labelToken = compactColumnToken(rawLabel);
  const fieldToken = compactColumnToken(rawField);

  if (labelToken === 'TAXCODE') return rawLabel.includes(' ') ? 'taxCode' : 'taxCodeRepeat';
  if (fieldToken === 'UTAXCODE') return 'taxCodeRepeat';
  if (fieldToken === 'TAXCODE') return 'taxCode';
  if (labelToken === 'UNITPRICE') return 'unitPrice';
  if (labelToken === 'PRICE' && fieldToken.startsWith('U')) return 'price';
  if (fieldToken === 'UPRICE') return 'price';

  const tokens = [
    column.key,
    column.valueKey,
    column.rendererKey,
    column.sapField,
    column.fieldName,
    column.layoutFieldName,
    column.label,
  ].map(compactColumnToken).filter(Boolean);

  return tokens.map((token) => DELIVERY_COLUMN_KEY_BY_TOKEN.get(token)).find(Boolean) || '';
};

const ensureDeliveryMatrixColumns = (columns = []) => {
  const sourceByKey = new Map();
  (Array.isArray(columns) ? columns : []).filter(Boolean).forEach((column) => {
    const key = getDeliveryColumnIdentity(column);
    if (key && !sourceByKey.has(key)) sourceByKey.set(key, column);
  });

  return DELIVERY_ACTUAL_MATRIX_COLUMNS.map((baseColumn, index) => {
    const sourceColumn = sourceByKey.get(baseColumn.key) || {};
    const minWidth = Number(sourceColumn.minWidth || sourceColumn.width || baseColumn.minWidth || 125);

    return {
      ...baseColumn,
      ...sourceColumn,
      key: baseColumn.key,
      valueKey: baseColumn.isUdf
        ? (baseColumn.valueKey || sourceColumn.valueKey || sourceColumn.key || baseColumn.key)
        : (sourceColumn.valueKey || baseColumn.valueKey || sourceColumn.key || baseColumn.key),
      rendererKey: baseColumn.rendererKey || sourceColumn.rendererKey || sourceColumn.valueKey || baseColumn.key,
      label: baseColumn.label,
      visible: sourceColumn.visible !== false && baseColumn.visible !== false,
      active: sourceColumn.active !== false,
      readOnly: sourceColumn.readOnly ?? baseColumn.readOnly,
      isUdf: Boolean(baseColumn.isUdf || sourceColumn.isUdf),
      field: sourceColumn.field || baseColumn.field,
      type: sourceColumn.type || baseColumn.type,
      options: sourceColumn.options || baseColumn.options,
      minWidth,
      width: minWidth,
      order: index + 1,
      columnOrder: index + 1,
      sapControlled: true,
      importedLayout: Boolean(sourceColumn.importedLayout || sourceColumn.sapControlled),
      source: sourceColumn.source || 'delivery-sap-order',
    };
  });
};

const INIT_ATTACH = Array.from({ length: 9 }, (_, i) => ({
  id: i + 1, targetPath: '', fileName: '', attachmentDate: '',
  freeText: '', copyToTargetDocument: '', documentType: '', atchDocDate: '', alert: '',
}));

const getBpGstTypeLabel = (value) => ({
  1: 'Regular/TDS/ISD', 2: 'Composition', 3: 'Casual Taxable Person',
  4: 'Government Department', 5: 'Non-Resident Taxable Person',
  6: 'OIDAR', 7: 'TDS', 8: 'TCS', 9: 'UN Embassy/Body',
})[String(value || '')] || String(value || '');

// ─── Main Component ───────────────────────────────────────────────────────────
function Delivery() {
  const location = useLocation();
  const navigate = useNavigate();
  const { company } = useAuth();
  const activeCompanyId = company?.companyId || '';
  const activeCompanyDb = company?.dbName || '';
  const { removeTask, upsertTask } = useSapWindowTaskbarActions();
  const formRef = useRef(null);
  const isHydratingDocumentRef = useRef(false);
  const loadedLinesSignatureRef = useRef('');
  const handledCopyFromRef = useRef('');
  const copiedLinesNeedBatchOpenRef = useRef(false);
  const generalSettingsRef = useRef(readGeneralSettings());
  const defaultWarehouseAppliedRef = useRef(false);
  const requestedEditDocEntry = isRouteStateForActiveCompany(location.state) ? (
    location.state?.deliveryDocEntry ||
    location.state?.document?.docEntry ||
    location.state?.document?.DocEntry
  ) : null;
  const staleRequestedEditDocEntry = !requestedEditDocEntry && (
    location.state?.deliveryDocEntry ||
    location.state?.document?.docEntry ||
    location.state?.document?.DocEntry
  );

  const [currentDocEntry, setCurrentDocEntry] = useState(null);
  const [header, setHeader] = useState(() => createInitialHeader(generalSettingsRef.current));
  const [headerUdfDefinitions, setHeaderUdfDefinitions] = useState(HEADER_UDF_DEFINITIONS);
  const [rowUdfDefinitions, setRowUdfDefinitions] = useState(ROW_UDF_DEFINITIONS);
  const [matrixColumnDefinitions, setMatrixColumnDefinitions] = useState(BASE_MATRIX_COLUMNS);
  const [lines, setLines] = useState([createLine(ROW_UDF_DEFINITIONS)]);
  const [attachments, setAttachments] = useState(INIT_ATTACH);
  const [activeTab, setActiveTab] = useState('Contents');
  const [referenceDocumentsModal, setReferenceDocumentsModal] = useState(false);
  const [referenceDocuments, setReferenceDocuments] = useState([]);
  const [referenceDocumentsChanged, setReferenceDocumentsChanged] = useState(false);
  const [headerUdfs, setHeaderUdfs] = useState(() => normalizeUdfState(HEADER_UDF_DEFINITIONS));
  const [formSettings, setFormSettings, formSettingsStorageKey] = useCompanyScopedFormSettings(
    FORM_SETTINGS_STORAGE_KEY,
    readSavedFormSettings,
    [headerUdfDefinitions, rowUdfDefinitions, matrixColumnDefinitions],
  );
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const [formSettingsOpen, setFormSettingsOpen] = useState(false);
  const [refData, setRefData] = useState({
    company: '', vendors: [], contacts: [], pay_to_addresses: [], ship_to_addresses: [], bill_to_addresses: [], items: [],
    warehouses: [], warehouse_addresses: [], company_address: {}, tax_codes: [],
    payment_terms: [], payment_methods: [], shipping_types: [], branches: [], uom_groups: [],
    distribution_rules: [], sales_employees: [], quality_options: { buyer: [], seller: [] }, price_options: { buyer: [], seller: [] },
    decimal_settings: DEC, warnings: [], series: [], states: [], udf_metadata: { header: [], rows: [] },
    eway_bill_formats: [],
    eway_bill_transporters: [],
    eway_bill_options: {},
    line_field_metadata: { matrix_columns: BASE_MATRIX_COLUMNS, sap_form: {} },
  });
  const [pageState, setPageState] = useState({ loading: false, vendorLoading: false, posting: false, error: '', success: '', seriesLoading: false });
  const [valErrors, setValErrors] = useState({ header: {}, lines: {}, form: '' });
  useValidationHighlights(valErrors, { rootRef: formRef });
  const [snapshotPending, setSnapshotPending] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [addressModal, setAddressModal] = useState(null);
  const [taxInfoModal, setTaxInfoModal] = useState(false);
  const [batchModal, setBatchModal] = useState({ open: false, lineIndex: null, availableBatches: [], loading: false, error: '' });
  const [bpModal, setBpModal] = useState(false);
  const [stateModal, setStateModal] = useState(false);
  const [hsnModal, setHsnModal] = useState({ open: false, lineIndex: -1 });
  const [itemModal, setItemModal] = useState({ open: false, lineIndex: -1, items: [], loading: false });
  const [qualityModal, setQualityModal] = useState({
    open: false,
    lineIndex: -1,
    field: '',
    title: 'List of User-Defined Values',
    options: [],
    searchPlaceholder: 'Search values',
    emptyMessage: 'No values found',
    allowCreate: true,
  });
  const [freightModal, setFreightModal] = useState({ open: false, freightCharges: [], loading: false });
  const [salesEmployeeSetup, setSalesEmployeeSetup] = useState({ open: false, rows: [], saving: false });
  const [copyFromModal, setCopyFromModal] = useState(false);
  const [eWayBillModalOpen, setEWayBillModalOpen] = useState(false);
  const [eWayBillDetails, setEWayBillDetails] = useState({});
  const [copyFromDocType, setCopyFromDocType] = useState('salesOrder');
  const [addressForm, setAddressForm] = useState({
    shipToCode: '', shipToAddress: '', billToCode: '', billToAddress: '',
    streetPoBox: '', streetNo: '', buildingFloorRoom: '', block: '', city: '', zipCode: '', county: '',
    state: '', countryRegion: '', addressName2: '', addressName3: '', gln: '', gstin: ''
  });
  const [taxInfoForm, setTaxInfoForm] = useState({
    panNo: '', panCircleNo: '', panWardNo: '', panAssessingOfficer: '', deducteeRefNo: '',
    lstVatNo: '', cstNo: '', tanNo: '', serviceTaxNo: '', companyType: '', natureOfBusiness: '',
    assesseeType: '', tinNo: '', itrFiling: '', gstType: '', gstin: ''
  });

  useEffect(() => {
    if (!refData.states?.length || !header.placeOfSupply) return;
    const normalizedPlaceOfSupply = getStateCodeValue(header.placeOfSupply, refData.states);
    if (normalizedPlaceOfSupply && normalizedPlaceOfSupply !== header.placeOfSupply) {
      setHeader(prev => (
        prev.placeOfSupply === header.placeOfSupply
          ? { ...prev, placeOfSupply: normalizedPlaceOfSupply }
          : prev
      ));
    }
  }, [header.placeOfSupply, refData.states]);

  // Close Copy From dropdown when clicking outside
  useEffect(() => {
    const handler = (e) => {
      if (!e.target.closest('.del-dropdown')) {
        document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
      }
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  // decimal config
  const dec = { ...DEC, ...(refData.decimal_settings || {}) };
  const numDec = {
    quantity: Number(dec.QtyDec), unitPrice: Number(dec.PriceDec),
    stdDiscount: Number(dec.PercentDec), total: Number(dec.SumDec),
    discount: Number(dec.PercentDec), freight: Number(dec.SumDec),
    tax: Number(dec.SumDec), totalPaymentDue: Number(dec.SumDec),
  };
  const isDocumentEditable = !currentDocEntry || String(header.status || '').toLowerCase() === 'open';
  const hasBuyerCode = Boolean(String(header.vendor || '').trim());
  const isUpdateMode = Boolean(currentDocEntry);
  const hasUnsavedChanges = Boolean(currentDocEntry && isDirty);
  const updateActionLabel = hasUnsavedChanges ? 'Update' : 'OK';
  const resolvePreferredSeries = (seriesList, postingDateValue, selectedSeries = '') => {
    if (!Array.isArray(seriesList) || !seriesList.length) return null;

    const normalizedSeries = String(selectedSeries || '').trim();
    const matchedSeries = normalizedSeries
      ? seriesList.find((series) => String(series.Series) === normalizedSeries)
      : null;

    if (matchedSeries) return matchedSeries;

    const sapDefaultSeries = seriesList.find((series) => series.IsDefault || series.isDefault);
    if (sapDefaultSeries) return sapDefaultSeries;

    const preferredSeries = String(generalSettingsRef.current.deliverySeries || '').trim();
    const settingsSeries = preferredSeries
      ? seriesList.find((series) => String(series.Series) === preferredSeries)
      : null;

    if (settingsSeries) return settingsSeries;

    const seriesDate = postingDateValue ? new Date(`${postingDateValue}T00:00:00`) : new Date();
    return getDefaultSeriesForCurrentYear(seriesList, seriesDate) || seriesList[0];
  };
  const primaryActionLabel = pageState.posting
    ? 'Saving...'
    : isUpdateMode
      ? updateActionLabel
      : 'Add';
  const secondaryActionLabel = pageState.posting
    ? 'Saving…'
    : currentDocEntry
      ? updateActionLabel
      : 'Add & New';

  useEffect(() => {
    const draft = location.state?.deliveryDraft;
    if (!draft) return;

    setCurrentDocEntry(draft.currentDocEntry || null);
    setHeader(draft.header || createInitialHeader(generalSettingsRef.current));
    setLines(Array.isArray(draft.lines) && draft.lines.length ? draft.lines : [createLine(ROW_UDF_DEFINITIONS)]);
    setHeaderUdfs(draft.headerUdfs || normalizeUdfState(HEADER_UDF_DEFINITIONS));
    setReferenceDocuments(Array.isArray(draft.referenceDocuments) ? draft.referenceDocuments : []);
    setReferenceDocumentsChanged(Boolean(draft.referenceDocumentsChanged));
    setActiveTab(draft.activeTab || 'Contents');
    setIsDirty(Boolean(draft.isDirty));
    setReferenceDocumentsModal(Boolean(draft.referenceDocumentsModalOpen));
    replaceRouteStatePreservingWindow(navigate, location.pathname, location.state);
  }, [location.state, navigate, location.pathname]);

  const buildLinkedRestoreState = useCallback((overrides = {}) => ({
    deliveryDraft: {
      currentDocEntry,
      header,
      lines,
      headerUdfs,
      referenceDocuments: Array.isArray(overrides.referenceDocuments)
        ? overrides.referenceDocuments
        : referenceDocuments,
      referenceDocumentsChanged: overrides.referenceDocumentsChanged ?? referenceDocumentsChanged,
      referenceDocumentsModalOpen: overrides.referenceDocumentsModalOpen ?? referenceDocumentsModal,
      activeTab,
      isDirty,
    },
  }), [activeTab, currentDocEntry, header, headerUdfs, isDirty, lines, referenceDocuments, referenceDocumentsChanged, referenceDocumentsModal]);

  const openBusinessPartnerLink = useCallback(() => {
    openLinkedBusinessPartner({
      cardCode: header.vendor,
      sourcePath: location.pathname,
      sourceTitle: `Delivery${header.docNo || currentDocEntry ? ` #${header.docNo || currentDocEntry}` : ''}`,
      sourceRestoreState: buildLinkedRestoreState(),
      navigate,
      upsertTask,
    });
  }, [buildLinkedRestoreState, currentDocEntry, header.docNo, header.vendor, location.pathname, navigate, upsertTask]);

  const resolveReferenceDocEntry = useCallback(async (row) => {
    const currentDocEntryValue = String(row?.docEntry || '').trim();
    if (currentDocEntryValue) return currentDocEntryValue;

    const docNumber = String(row?.docNumber || '').trim();
    const transactionType = String(row?.transactionType || '').trim();
    if (!docNumber || !transactionType) return '';

    const response = await fetchSalesOrderReferenceDocumentLookup({
      transactionType,
      query: docNumber,
      cardCode: '',
      top: 20,
    });
    const exact = (response.data?.options || []).find((option) => (
      String(option.docNumber || '') === docNumber
    ));
    return exact?.docEntry ? String(exact.docEntry) : '';
  }, []);

  const openReferenceDocument = useCallback(async (row, options = {}) => {
    try {
      const docEntry = await resolveReferenceDocEntry(row);
      if (!docEntry) {
        setPageState(p => ({
          ...p,
          success: '',
          error: 'Referenced document was not found. Choose a document from the lookup first.',
        }));
        return false;
      }

      const opened = openLinkedReferenceDocument({
        transactionType: row?.transactionType,
        docEntry,
        docNumber: row?.docNumber,
        sourcePath: location.pathname,
        sourceTitle: `Delivery${header.docNo || currentDocEntry ? ` #${header.docNo || currentDocEntry}` : ''}`,
        sourceRestoreState: buildLinkedRestoreState(options),
        navigate,
        upsertTask,
      });

      if (!opened) {
        setPageState(p => ({
          ...p,
          success: '',
          error: 'This referenced document type is not configured for navigation.',
        }));
      }
      return opened;
    } catch (error) {
      setPageState(p => ({
        ...p,
        success: '',
        error: getErrMsg(error, 'Failed to open referenced document.'),
      }));
      return false;
    }
  }, [buildLinkedRestoreState, currentDocEntry, header.docNo, location.pathname, navigate, resolveReferenceDocEntry, upsertTask]);

  useEffect(() => {
    if (!snapshotPending || !currentDocEntry || pageState.loading || pageState.vendorLoading) return;
    loadedLinesSignatureRef.current = getDeliveryLinesUpdateSignature(lines);
    setSnapshotPending(false);
  }, [snapshotPending, currentDocEntry, pageState.loading, pageState.vendorLoading, header, lines, headerUdfs]);
  const markDirty = useCallback((event) => {
    if (event?.target?.closest?.('[data-document-dirty-ignore="true"]')) return;
    if (currentDocEntry) setIsDirty(true);
  }, [currentDocEntry]);
  const hydrateLoadedLine = useCallback((line) => {
    const itemCode = String(line?.itemNo || line?.ItemCode || line?.itemCode || '').trim();
    const item = refData.items.find(i => String(i.ItemCode || '').trim() === itemCode);
    const rawUomCode = String(
      line?.uomCode ||
      line?.UoMCode ||
      line?.UomCode ||
      line?.unitMsr ||
      item?.SalesUnit ||
      item?.InventoryUOM ||
      ''
    ).trim();
    const numericFactor = parseFloat(rawUomCode);
    const explicitFactor = Number(line?.uomFactor);
    const uomFactor = Number.isFinite(explicitFactor) && explicitFactor > 0
      ? explicitFactor
      : Number.isFinite(numericFactor) && numericFactor > 0
        ? numericFactor
        : 1;
    const inventoryUOM = String(line?.inventoryUOM || line?.InventoryUOM || item?.InventoryUOM || '').trim();
    const batches = Array.isArray(line?.batches)
      ? line.batches
          .filter(batch => String(batch?.batchNumber || '').trim())
          .map(batch => ({
            batchNumber: String(batch.batchNumber || '').trim(),
            quantity: String(batch.quantity ?? ''),
            expiryDate: batch.expiryDate || '',
          }))
      : [];
    const batchManaged = isLineBatchManaged(line, item);
    const workbookLine = hydrateWorkbookDocumentLine({
      line,
      createLine,
      rowUdfDefinitions,
      normalizeUdfState,
      items: refData.items,
    });

    const hydratedLine = {
      ...workbookLine,
      itemNo: itemCode,
      itemDescription: line?.itemDescription || line?.ItemDescription || line?.Dscription || item?.ItemName || '',
      hsnCode: line?.hsnCode || line?.HSNCode || item?.HSNCode || item?.SWW || item?.U_HSNCode || '',
      quantity: String(line?.quantity ?? line?.Quantity ?? ''),
      openQty: String(line?.openQty ?? line?.OpenQuantity ?? line?.OpenQty ?? ''),
      unitPrice: String(line?.unitPrice ?? line?.UnitPrice ?? line?.Price ?? ''),
      uomName: line?.uomName || line?.UoMName || line?.UomName || line?.UnitMsr || line?.unitMsr || item?.SalesUnit || rawUomCode,
      price: String(firstNonBlank(line?.price, line?.Price, line?.unitPrice, line?.UnitPrice)),
      priceAfterDiscount: String(firstNonBlank(line?.priceAfterDiscount, line?.PriceAfterDiscount)),
      itemCost: String(firstNonBlank(line?.itemCost, line?.ItemCost, line?.StockPrice, line?.stockPrice, item?.ItemCost, item?.AvgPrice)),
      binLocationAllocation: line?.binLocationAllocation || line?.BinLocationAllocation || '',
      sellerPrice: String(line?.sellerPrice ?? line?.SellerPrice ?? ''),
      buyerPrice: String(line?.buyerPrice ?? line?.BuyerPrice ?? ''),
      sellerDelivery: line?.sellerDelivery || line?.SellerDelivery || '',
      buyerDelivery: line?.buyerDelivery || line?.BuyerDelivery || '',
      sellerBrokerageAmtPer: line?.sellerBrokerageAmtPer || line?.SellerBrokerageAmtPer || '',
      sellerBrokeragePercent: String(line?.sellerBrokeragePercent ?? line?.SellerBrokeragePercent ?? ''),
      sellerBrokerage: String(line?.sellerBrokerage ?? line?.SellerBrokerage ?? ''),
      buyerBrokerage: String(line?.buyerBrokerage ?? line?.BuyerBrokerage ?? ''),
      specialRebate: String(line?.specialRebate ?? line?.SpecialRebate ?? ''),
      commission: String(line?.commission ?? line?.Commission ?? ''),
      sellerBrokeragePerQty: String(line?.sellerBrokeragePerQty ?? line?.SellerBrokeragePerQty ?? ''),
      unitPriceUdf: String(line?.unitPriceUdf ?? line?.UnitPriceUdf ?? ''),
      buyerPaymentTerms: line?.buyerPaymentTerms || line?.BuyerPaymentTerms || '',
      sellerPaymentTerms: line?.sellerPaymentTerms || line?.SellerPaymentTerms || '',
      buyerSpecialInstruction: line?.buyerSpecialInstruction || line?.BuyerSpecialInstruction || '',
      sellerSpecialInstruction: line?.sellerSpecialInstruction || line?.SellerSpecialInstruction || '',
      buyerBillDiscount: String(line?.buyerBillDiscount ?? line?.BuyerBillDiscount ?? ''),
      sellerBillDiscount: String(line?.sellerBillDiscount ?? line?.SellerBillDiscount ?? ''),
      sellerItem: line?.sellerItem || line?.SellerItem || '',
      sellerQty: String(line?.sellerQty ?? line?.SellerQty ?? ''),
      freightPurchase: String(line?.freightPurchase ?? line?.FreightPurchase ?? ''),
      freightSales: String(line?.freightSales ?? line?.FreightSales ?? ''),
      freightProvider: line?.freightProvider || line?.FreightProvider || '',
      freightProviderName: line?.freightProviderName || line?.FreightProviderName || '',
      brokerageNumber: line?.brokerageNumber || line?.BrokerageNumber || '',
      uomCode: rawUomCode,
      stdDiscount: String(line?.stdDiscount ?? line?.DiscountPercent ?? line?.DiscPrcnt ?? ''),
      stcode: line?.stcode || line?.STCode || '',
      taxCode: line?.taxCode || line?.TaxCode || '',
      total: String(line?.total ?? line?.LineTotal ?? ''),
      taxAmount: String(line?.taxAmount ?? line?.LineTaxAmount ?? line?.VatSum ?? ''),
      whse: line?.whse || line?.Warehouse || line?.WarehouseCode || line?.WhsCode || '',
      distRule: line?.distRule || line?.DistributionRule || line?.OcrCode || '',
      freeText: line?.freeText || line?.FreeText || '',
      countryOfOrigin: line?.countryOfOrigin || line?.CountryOfOrigin || '',
      sacCode: line?.sacCode || line?.SACCode || '',
      deliveredQty: String(line?.deliveredQty ?? line?.DeliveredQty ?? ''),
      documentCreated: line?.documentCreated || line?.DocumentCreated || '',
      loc: String(line?.loc ?? line?.Loc ?? ''),
      branch: String(line?.branch ?? line?.Branch ?? ''),
      lineNum: line?.lineNum ?? line?.LineNum,
      baseEntry: line?.baseEntry ?? line?.BaseEntry ?? null,
      baseType: line?.baseType ?? line?.BaseType ?? null,
      baseLine: line?.baseLine ?? line?.BaseLine ?? null,
      inventoryUOM,
      uomFactor,
      batchManaged,
      batches,
      hasBatchesAvailable: batchManaged ? true : false,
      udf: normalizeUdfState(
        rowUdfDefinitions,
        mergeUdfValues(pickLineUdfValues(line), workbookLine.udf, line?.line_udfs, line?.lineUdfs, line?.udf)
      ),
    };
    hydratedLine.taxCodeManuallyOverridden = Boolean(
      line?.taxCodeManuallyOverridden ?? String(hydratedLine.taxCode || '').trim()
    );
    return hydratedLine;
  }, [refData.items, rowUdfDefinitions]);

  const openBatchModalForLine = useCallback((lineIndex, line) => {
    if (!line?.itemNo) {
      setPageState(p => ({ ...p, error: 'Select an item before allocating batches.' }));
      return;
    }
    const itemNo = line.itemNo;
    const whse = resolveBatchWarehouseCode(line.whse, header.warehouse);
    if (!whse) {
      setPageState(p => ({ ...p, error: 'Select a warehouse before allocating batches.' }));
      return;
    }

    if (String(line.whse || '').trim() !== whse) {
      setLines(prevLines => prevLines.map((currentLine, currentIndex) => (
        currentIndex === lineIndex
          ? { ...currentLine, whse, batches: [], hasBatchesAvailable: false }
          : currentLine
      )));
    }

    setBatchModal({ open: true, lineIndex, availableBatches: [], loading: true, error: '' });
    window.setTimeout(async () => {
      try {
        const response = await fetchBatchesByItem(itemNo, whse);
        setBatchModal(current => (
          current.open && current.lineIndex === lineIndex
            ? {
              open: true,
              lineIndex,
              availableBatches: response.data.batches || [],
              loading: false,
              error: '',
            }
            : current
        ));
      } catch (error) {
        setBatchModal(current => (
          current.open && current.lineIndex === lineIndex
            ? {
              open: true,
              lineIndex,
              availableBatches: [],
              loading: false,
              error: getErrMsg(error, 'Failed to load available batches.'),
            }
            : current
        ));
      }
    }, 0);
  }, [header.warehouse]);

  const openBatchModal = useCallback((lineIndex, lineOverride = null) => {
    openBatchModalForLine(lineIndex, lineOverride || lines[lineIndex]);
  }, [lines, openBatchModalForLine]);

  const refreshBatchAvailabilityForLines = useCallback((nextLines = []) => {
    nextLines.forEach((line, lineIndex) => {
      const whse = resolveBatchWarehouseCode(line?.whse, header.warehouse);
      if (!line?.batchManaged || !line?.itemNo || !whse) return;
      checkBatchAvailability(line.itemNo, whse).then(hasBatches => {
        setLines(prevLines => prevLines.map((currentLine, currentIndex) => (
          currentIndex === lineIndex &&
          currentLine.itemNo === line.itemNo &&
          resolveBatchWarehouseCode(currentLine.whse, header.warehouse) === whse
            ? { ...currentLine, whse, hasBatchesAvailable: hasBatches }
            : currentLine
        )));
      });
    });
  }, [header.warehouse]);

  const openRequiredBatchAllocationOnAdd = useCallback(() => {
    const hydratedLines = lines.map(line => hydrateLoadedLine(line));
    const lineIndex = hydratedLines.findIndex(needsBatchAllocation);
    if (lineIndex < 0) return false;

    setLines(hydratedLines);
    setActiveTab('Contents');
    setValErrors(prev => ({
      ...prev,
      form: 'Please assign batches before adding this delivery.',
      lines: {
        ...prev.lines,
        [lineIndex]: {
          ...(prev.lines[lineIndex] || {}),
          batches: 'Batch selection is mandatory for batch-managed item',
        },
      },
    }));
    setPageState(p => ({
      ...p,
      posting: false,
      error: 'Please assign batches before adding this delivery.',
      success: '',
    }));
    refreshBatchAvailabilityForLines(hydratedLines);
    window.setTimeout(() => openBatchModal(lineIndex, hydratedLines[lineIndex]), 0);
    return true;
  }, [hydrateLoadedLine, lines, openBatchModal, refreshBatchAvailabilityForLines]);

  // Continue in next part...

  // ── load reference data ───────────────────────────────────────────────────
  useEffect(() => {
    let ignore = false;
    const load = async () => {
      setPageState(p => ({ ...p, loading: true, error: '', success: '' }));
      try {
        if (!activeCompanyId) {
          setHeaderUdfDefinitions([]);
          setRowUdfDefinitions([]);
          setMatrixColumnDefinitions(BASE_MATRIX_COLUMNS);
          setHeaderUdfs({});
          setLines([createLine([])]);
          setRefData(prev => ({
            ...prev,
            company: '',
            vendors: [], contacts: [], pay_to_addresses: [], ship_to_addresses: [], bill_to_addresses: [],
            items: [], warehouses: [], warehouse_addresses: [], company_address: {}, tax_codes: [],
            payment_terms: [], payment_methods: [], shipping_types: [], branches: [], states: [], uom_groups: [],
            distribution_rules: [], sales_employees: [], quality_options: { buyer: [], seller: [] }, price_options: { buyer: [], seller: [] },
            eway_bill_formats: [],
            eway_bill_transporters: [],
            eway_bill_options: {},
            udf_metadata: { header: [], rows: [] },
            line_field_metadata: { matrix_columns: BASE_MATRIX_COLUMNS, sap_form: {} },
          }));
          return;
        }

        setMatrixColumnDefinitions([]);

        const [refDataRes, layoutRes] = await Promise.all([
          fetchDeliveryReferenceData(activeCompanyId),
          getDocumentLayout({
            companyDb: activeCompanyDb || undefined,
            documentType: DELIVERY_LAYOUT_DOCUMENT_TYPE,
            objectType: '15',
          }).catch((error) => ({
            data: {
              success: false,
              columns: [],
              warning: getErrMsg(error, 'Failed to load SAP layout.'),
            },
          })),
        ]);
        
        if (!ignore) {
          const vendorRows = refDataRes.data.vendors || refDataRes.data.customers || [];
          const nextHeaderUdfs = refDataRes.data.udf_metadata?.header || [];
          const nextRowUdfs = filterDeliveryRowUdfDefinitions(refDataRes.data.udf_metadata?.rows || []);
          const liveMatrixColumns = refDataRes.data.line_field_metadata?.matrix_columns?.length
            ? refDataRes.data.line_field_metadata.matrix_columns
            : BASE_MATRIX_COLUMNS;
          let nextMatrixColumns = ensureDeliveryMatrixColumns(buildSalesOrderMatrixColumnsFromLayout({
            layoutColumns: layoutRes?.data?.columns || [],
            liveMatrixColumns,
            rowUdfFields: nextRowUdfs,
            includeLineNumber: false,
          }));
          // Hide wTaxLiable column on Delivery page unless explicitly required by layout
          nextMatrixColumns = nextMatrixColumns.filter((c) => (c.key || c.valueKey || '').toString() !== 'wTaxLiable');
          setHeaderUdfDefinitions(nextHeaderUdfs);
          setRowUdfDefinitions(nextRowUdfs);
          setMatrixColumnDefinitions(nextMatrixColumns);
          setHeaderUdfs((prev) => normalizeUdfState(nextHeaderUdfs, prev));
          setLines((prev) => prev.map((line) => ({
            ...line,
            udf: normalizeUdfState(nextRowUdfs, line.udf || {}),
          })));
          setFormSettings(readSavedFormSettings(nextHeaderUdfs, nextRowUdfs, nextMatrixColumns, formSettingsStorageKey));
          setRefData(prev => ({
            ...prev,
            company: refDataRes.data.company || '',
            vendors: vendorRows,
            contacts: refDataRes.data.contacts || [],
            pay_to_addresses: refDataRes.data.pay_to_addresses || [],
            ship_to_addresses: refDataRes.data.ship_to_addresses || [],
            bill_to_addresses: refDataRes.data.bill_to_addresses || [],
            items: refDataRes.data.items || [],
            warehouses: refDataRes.data.warehouses || [],
            warehouse_addresses: refDataRes.data.warehouse_addresses || [],
            company_address: refDataRes.data.company_address || {},
            tax_codes: refDataRes.data.tax_codes || [],
            payment_terms: refDataRes.data.payment_terms || [],
            payment_methods: refDataRes.data.payment_methods || [],
            shipping_types: refDataRes.data.shipping_types || [],
            sales_employees: refDataRes.data.sales_employees || [],
            branches: refDataRes.data.branches || [],
            states: refDataRes.data.states || [],
            uom_groups: refDataRes.data.uom_groups || [],
            distribution_rules: refDataRes.data.distribution_rules || [],
            quality_options: refDataRes.data.quality_options || { buyer: [], seller: [] },
            price_options: refDataRes.data.price_options || { buyer: [], seller: [] },
            eway_bill_formats: refDataRes.data.eway_bill_formats || [],
            eway_bill_transporters: refDataRes.data.eway_bill_transporters || [],
            eway_bill_options: refDataRes.data.eway_bill_options || {},
            decimal_settings: { ...DEC, ...(refDataRes.data.decimal_settings || {}) },
            warnings: [
              ...(refDataRes.data.warnings || []),
              ...(layoutRes?.data?.warning ? [layoutRes.data.warning] : []),
            ],
            udf_metadata: refDataRes.data.udf_metadata || { header: [], rows: [] },
            line_field_metadata: {
              ...(refDataRes.data.line_field_metadata || { sap_form: {} }),
              matrix_columns: nextMatrixColumns,
              imported_layout: layoutRes?.data || null,
            },
            series: Array.isArray(prev.series) ? prev.series : [],
          }));
        }
      } catch (e) {
        if (!ignore) setPageState(p => ({ ...p, error: getErrMsg(e, 'Failed to load reference data.') }));
      } finally {
        if (!ignore) setPageState(p => ({ ...p, loading: false }));
      }
    };
    load();
    return () => { ignore = true; };
  }, [activeCompanyDb, activeCompanyId, formSettingsStorageKey]);

  useEffect(() => {
    if (currentDocEntry || requestedEditDocEntry || isHydratingDocumentRef.current) return;

    const eWayBillFormats = refData.eway_bill_formats || [];
    if (!header.edocExportFormat && eWayBillFormats.length) {
      setHeader((current) => ({ ...current, edocExportFormat: String(eWayBillFormats[0].AbsEntry) }));
    }
  }, [currentDocEntry, header.edocExportFormat, refData.eway_bill_formats, requestedEditDocEntry]);

  useEffect(() => {
    if (currentDocEntry || requestedEditDocEntry || isHydratingDocumentRef.current) return;

    const seriesDate = String(header.postingDate || '').trim();
    if (!seriesDate) {
      setRefData(prev => ({ ...prev, series: [] }));
      setHeader(prev => ({ ...prev, series: '', nextNumber: '' }));
      return;
    }

    let ignore = false;

    const loadSeriesForPostingDate = async () => {
      try {
        const seriesResponse = await fetchDocumentSeries(seriesDate);
        const availableSeries = seriesResponse.data?.series || [];

        if (ignore || requestedEditDocEntry || isHydratingDocumentRef.current) return;

        setRefData(prev => ({ ...prev, series: availableSeries }));

        if (!availableSeries.length) {
          setHeader(prev => ({ ...prev, series: '', nextNumber: '' }));
          return;
        }

        const currentSeries = String(header.series || '');
        const defaultSeries = resolvePreferredSeries(availableSeries, seriesDate, currentSeries);

        if (!defaultSeries?.Series) return;

        if (String(defaultSeries.Series) !== currentSeries || !String(header.nextNumber || '').trim()) {
          handleSeriesChange(defaultSeries.Series);
        }
      } catch (e) {
        if (!ignore) {
          setPageState(p => ({ ...p, error: getErrMsg(e, 'Failed to load document series.') }));
        }
      }
    };

    loadSeriesForPostingDate();

    return () => { ignore = true; };
  }, [currentDocEntry, requestedEditDocEntry, header.postingDate]);

  // ── load existing order ───────────────────────────────────────────────────
  useEffect(() => {
    if (staleRequestedEditDocEntry) {
      setPageState(p => ({ ...p, loading: false, error: '', success: '' }));
      replaceRouteStatePreservingWindow(navigate, location.pathname, location.state);
      return;
    }

    const docEntry = requestedEditDocEntry;
    if (!docEntry) return;
    let ignore = false;
    let hydrationTimer = null;
    const load = async () => {
      setPageState(p => ({ ...p, loading: true, error: '', success: '' }));
      try {
        isHydratingDocumentRef.current = true;
        const r = await fetchDeliveryByDocEntry(docEntry);
        const so = r.data.delivery;
        let editSeries = [];
        try {
          const seriesDate = so?.header?.postingDate || so?.header?.documentDate || '';
          const seriesResponse = await fetchDocumentSeries(seriesDate);
          editSeries = seriesResponse.data?.series || [];
        } catch (_seriesError) {
          editSeries = [];
        }
        const loadedLines = Array.isArray(so?.lines) && so.lines.length
          ? so.lines
          : Array.isArray(so?.DocumentLines) && so.DocumentLines.length
            ? so.DocumentLines
            : [];
        const loadedReferenceDocuments = normalizeDeliveryReferenceDocuments(
          so.reference_documents || so.referenceDocuments || []
        );
        const firstLineWarehouse = loadedLines.length > 0
          ? String(
              loadedLines[0]?.whse ||
              loadedLines[0]?.Warehouse ||
              loadedLines[0]?.WarehouseCode ||
              loadedLines[0]?.WhsCode ||
              ''
            )
          : '';
        console.log('📦 [Delivery] Loaded delivery data:', so);
        console.log('📦 [Delivery] Header:', so.header);
        console.log('📦 [Delivery] Lines:', so.lines);
        
        if (ignore || !so) return;
        setCurrentDocEntry(so.doc_entry || Number(docEntry));
        setEWayBillDetails(so.eway_bill_details || {});
        setAttachments(so.attachments?.length ? so.attachments : INIT_ATTACH);
        setReferenceDocuments(loadedReferenceDocuments);
        setReferenceDocumentsChanged(false);
        setActiveTab('Contents');
        const savedSeriesValue = String(so.header?.series || '');
        const savedSeriesOption = savedSeriesValue
          ? {
              Series: savedSeriesValue,
              SeriesName: so.header?.seriesName || savedSeriesValue,
              Indicator: so.header?.seriesIndicator || '',
            }
          : null;
        const mergedEditSeries = savedSeriesOption
          ? [
              savedSeriesOption,
              ...editSeries.filter((series) => String(series.Series) !== savedSeriesValue),
            ]
          : editSeries;
        if (mergedEditSeries.length) {
          setRefData(prev => ({
            ...prev,
            series: mergedEditSeries,
          }));
        }
        setHeader(prev => ({
          ...prev,
          ...INIT_HEADER,
          ...(so.header || {}),
          vendor: so.header?.customerCode || so.header?.customer || '',
          contactPerson: so.header?.contactPerson || '',
          name: so.header?.customerName || so.header?.name || '',
          paymentTerms: so.header?.paymentTermsCode || so.header?.paymentTerms || '',
          placeOfSupply: so.header?.placeOfSupply || '',
          branch: so.header?.branch || '',
          warehouse: firstLineWarehouse || so.header?.warehouse || '',
          shipToCode: so.header?.shipToCode || '',
          shipToAddress: so.header?.shipToAddress || so.header?.shipTo || '',
          shipToAddressComponents: so.header?.shipToAddressComponents || null,
          shipTo: so.header?.shipTo || so.header?.shipToAddress || '',
          billToCode: so.header?.billToCode || so.header?.payToCode || '',
          billToAddress: so.header?.billToAddress || so.header?.payTo || '',
          billToAddressComponents: so.header?.billToAddressComponents || null,
          payToCode: so.header?.payToCode || so.header?.billToCode || '',
          payTo: so.header?.payTo || so.header?.billToAddress || '',
          docNo: so.header?.docNo || so.header?.docNum || '',
          series: so.header?.series || '',
          nextNumber: so.header?.docNo || so.header?.docNum || '',
        }));
        
        const hydratedLoadedLines = loadedLines.length
          ? loadedLines.map(l => hydrateLoadedLine(l))
          : [createLine(rowUdfDefinitions)];
        loadedLinesSignatureRef.current = getDeliveryLinesUpdateSignature(hydratedLoadedLines);
        setLines(hydratedLoadedLines);
        
        console.log('📦 [Delivery] Lines after mapping:', lines);
        
        setHeaderUdfs(normalizeUdfState(headerUdfDefinitions, so.header_udfs || {}));
        setSnapshotPending(true);
        setIsDirty(false);
        if (so.header?.customerCode || so.header?.customer) {
          loadVendorDetails(so.header?.customerCode || so.header?.customer, {
            preserveExisting: true,
            selectedBillToCode: so.header?.billToCode || so.header?.payToCode || '',
          });
        }
        
        setPageState(p => ({ ...p, success: so.doc_num ? `Delivery ${so.doc_num} loaded.` : 'Delivery loaded.' }));
      } catch (e) {
        if (!ignore) setPageState(p => ({ ...p, error: getErrMsg(e, 'Failed to load delivery.') }));
      } finally {
        hydrationTimer = setTimeout(() => {
          isHydratingDocumentRef.current = false;
        }, 0);
        if (!ignore) {
          setPageState(p => ({ ...p, loading: false }));
          replaceRouteStatePreservingWindow(navigate, location.pathname, location.state);
        }
      }
    };
    load();
    return () => {
      ignore = true;
      isHydratingDocumentRef.current = false;
      if (hydrationTimer) clearTimeout(hydrationTimer);
    };
  }, [hydrateLoadedLine, location.pathname, location.state, navigate]);

  useEffect(() => {
    if (!currentDocEntry) {
      setFreightModal(prev => (
        prev.freightCharges.length || prev.loading
          ? { ...prev, freightCharges: [], loading: false }
          : prev
      ));
      return;
    }

    let ignore = false;
    const loadSavedFreightCharges = async () => {
      try {
        const response = await fetchFreightCharges(currentDocEntry);
        const savedFreightCharges = response.data.freightCharges || [];
        const savedFreightTotal = savedFreightCharges.reduce((sum, charge) => (
          sum + parseNum(charge.netAmount ?? charge.LineTotal ?? charge.NetAmount ?? charge.DefaultAmount)
        ), 0);
        if (!ignore) {
          setFreightModal(prev => ({
            ...prev,
            freightCharges: savedFreightCharges,
            loading: false,
          }));
          setHeader(prev => ({ ...prev, freight: fmtDec(savedFreightTotal, numDec.freight) }));
        }
      } catch (_error) {
        if (!ignore) {
          setFreightModal(prev => ({ ...prev, freightCharges: [], loading: false }));
        }
      }
    };

    loadSavedFreightCharges();
    return () => { ignore = true; };
  }, [currentDocEntry]);

  useEffect(() => {
    if (!currentDocEntry || !refData.items.length) return;

    setLines(prevLines => prevLines.map(line => hydrateLoadedLine(line)));
  }, [currentDocEntry, hydrateLoadedLine, refData.items.length]);

  useEffect(() => {
    if (currentDocEntry || !refData.items.length || !copiedLinesNeedBatchOpenRef.current) return;

    copiedLinesNeedBatchOpenRef.current = false;
    const hydratedLines = lines.map(line => hydrateLoadedLine(line));
    setLines(hydratedLines);
    refreshBatchAvailabilityForLines(hydratedLines);
  }, [
    currentDocEntry,
    hydrateLoadedLine,
    lines,
    refData.items.length,
    refreshBatchAvailabilityForLines,
  ]);

  // ── Copy To: populate form from Sales Order / other source ────────────────
  useEffect(() => {
    const routedCopyFrom = location.state?.copyFrom;
    if (routedCopyFrom && !isRouteStateForActiveCompany(location.state)) {
      replaceRouteStatePreservingWindow(navigate, location.pathname, location.state);
      return;
    }

    const persistedCopyState = consumePersistedCopyToState(location.pathname, ['/delivery/new', '/delivery']);
    const copyFrom = routedCopyFrom || persistedCopyState?.copyFrom;

    if (!copyFrom) return;

    const copyFromKey = JSON.stringify({
      path: location.pathname,
      type: copyFrom.type,
      docEntry: copyFrom.docEntry,
      lineCount: Array.isArray(copyFrom.lines) ? copyFrom.lines.length : 0,
    });

    if (handledCopyFromRef.current === copyFromKey) {
      return;
    }

    handledCopyFromRef.current = copyFromKey;

    const { header: srcHeader = {}, lines: srcLines = [], baseDocument } = copyFrom;
    const normalizedHeader = normaliseDocumentHeader(srcHeader || {});
    const baseEntry = baseDocument?.baseEntry || copyFrom.docEntry;
    const baseType = baseDocument?.baseType || BASE_TYPE[copyFrom.type] || 17;
    const firstSourceLine = Array.isArray(srcLines) && srcLines.length ? srcLines[0] : {};
    const firstLineWarehouse =
      firstSourceLine?.whse ||
      firstSourceLine?.WarehouseCode ||
      firstSourceLine?.WhsCode ||
      '';
    const copiedLocation = resolveCopiedBranchWarehouse({
      sourceBranch: normalizedHeader.branch || srcHeader.branch || srcHeader.BPL_IDAssignedToInvoice || srcHeader.BPLId,
      sourceWarehouse: srcHeader.warehouse,
      fallbackWarehouse: firstLineWarehouse,
      warehouses: refData.warehouses.length ? refData.warehouses : FALLBACK_WAREHOUSES,
    });

    setCurrentDocEntry(null);
    setEWayBillDetails({});
    setAttachments(INIT_ATTACH);
    setReferenceDocuments([]);
    setReferenceDocumentsChanged(false);
    setReferenceDocumentsModal(false);
    setActiveTab('Contents');
    setSnapshotPending(false);
    setIsDirty(false);
    setValErrors({ header: {}, lines: {}, form: '' });
    setFreightModal({ open: false, freightCharges: [], loading: false });
    setCopyFromModal(false);

    // Populate header for a new Delivery copied from the source document.
    setHeader(prev => ({
      ...INIT_HEADER,
      postingDate: today(),
      documentDate: today(),
      deliveryDate: srcHeader.deliveryDate || srcHeader.DocDueDate || prev.deliveryDate || '',
      vendor:           normalizedHeader.vendor || srcHeader.vendor || srcHeader.CardCode || '',
      name:             normalizedHeader.name || srcHeader.name || srcHeader.CardName || '',
      contactPerson:    normalizedHeader.contactPerson || srcHeader.contactPerson || srcHeader.CntctCode || '',
      salesContractNo:  normalizedHeader.salesContractNo || normalizedHeader.customerRefNo || srcHeader.salesContractNo || srcHeader.customerRefNo || srcHeader.CustomerRefNo || srcHeader.NumAtCard || '',
      branch:           copiedLocation.branch,
      warehouse:        copiedLocation.warehouse,
      paymentTerms:     normalizedHeader.paymentTerms || srcHeader.paymentTerms || srcHeader.GroupNum || '',
      placeOfSupply:    normalizedHeader.placeOfSupply || srcHeader.placeOfSupply || '',
      otherInstruction: normalizedHeader.otherInstruction || srcHeader.otherInstruction || srcHeader.Comments || '',
      discount:         srcHeader.discount || '',
      freight:          srcHeader.freight || '',
      tax:              srcHeader.tax || '',
      currency:         srcHeader.currency || 'INR',
      shipTo:           srcHeader.shipTo || srcHeader.shipToAddress || '',
      shipToCode:       srcHeader.shipToCode || '',
      shipToAddress:    srcHeader.shipToAddress || srcHeader.shipTo || '',
      payTo:            srcHeader.payTo || srcHeader.billToAddress || '',
      payToCode:        srcHeader.payToCode || srcHeader.billToCode || '',
      billToCode:       srcHeader.billToCode || srcHeader.payToCode || '',
      billToAddress:    srcHeader.billToAddress || srcHeader.payTo || '',
    }));
    setHeaderUdfs(normalizeUdfState(
      headerUdfDefinitions,
      mergeUdfValues(copyFrom.headerUdfs, copyFrom.header_udfs, srcHeader.header_udfs, srcHeader.headerUdfs)
    ));

    // Populate lines with base document linking
    if (Array.isArray(srcLines) && srcLines.length > 0) {
      const copiedLines = srcLines.map((l, idx) => {
        const normalizedLine = normaliseDocumentLine(
          l,
          idx,
          baseEntry,
          baseType,
          copiedLocation.branch
        );

        return hydrateLoadedLine({
          ...createLine(rowUdfDefinitions),
          ...normalizedLine,
          taxCode: normalizedLine.taxCode || l.taxCode || l.TaxCode || l.VatGroup || '',
          taxCodeManuallyOverridden: Boolean(String(normalizedLine.taxCode || l.taxCode || l.TaxCode || l.VatGroup || '').trim()),
          stcode: normalizedLine.stcode || l.stcode || '',
          branch: normalizedLine.branch || copiedLocation.branch,
          loc: normalizedLine.loc || copiedLocation.branch,
          whse: normalizedLine.whse || l.whse || l.WarehouseCode || l.WhsCode || copiedLocation.warehouse,
          baseEntry,
          baseType,
          baseLine: l.lineNum ?? l.LineNum ?? normalizedLine.baseLine ?? idx,
          udf: normalizeUdfState(rowUdfDefinitions, mergeUdfValues(pickLineUdfValues(l), l.line_udfs, l.lineUdfs, l.udf)),
        });
      });
      copiedLinesNeedBatchOpenRef.current = !refData.items.length && copiedLines.some(line => line.itemNo);
      setLines(copiedLines);
      refreshBatchAvailabilityForLines(copiedLines);
    } else {
      copiedLinesNeedBatchOpenRef.current = false;
      setLines([createLine(rowUdfDefinitions)]);
    }

    // Load vendor details to populate contacts/addresses
    const cardCode = normalizedHeader.vendor || srcHeader.vendor || srcHeader.CardCode;
    if (cardCode) loadVendorDetails(cardCode, { preserveExisting: true });

    const sourceLabel = copyFrom.sourceLabel || copyFrom.type || 'source document';
    setPageState(p => ({ ...p, success: `Copied from ${sourceLabel}. Please review and save.` }));

    // Clear state so refresh doesn't re-populate
    replaceRouteStatePreservingWindow(navigate, location.pathname, location.state || persistedCopyState);
  }, [location.pathname, location.state?.copyFrom, navigate]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── derived / computed ────────────────────────────────────────────────────
  const vendorCode = String(header.vendor || '');
  const vendorContacts = useMemo(
    () => refData.contacts.filter(c => String(c.CardCode || '') === vendorCode),
    [refData.contacts, vendorCode]
  );
  const contactOptions = useMemo(
    () => header.contactPerson && !vendorContacts.some(c => String(c.CntctCode || '') === String(header.contactPerson || ''))
      ? [{ CardCode: header.vendor, CntctCode: header.contactPerson, Name: header.contactPerson }, ...vendorContacts]
      : vendorContacts,
    [header.contactPerson, header.vendor, vendorContacts]
  );
  const vendorPayToAddresses = useMemo(
    () => refData.pay_to_addresses.filter(a => String(a.CardCode || '') === vendorCode),
    [refData.pay_to_addresses, vendorCode]
  );
  const vendorShipToAddresses = useMemo(
    () => (refData.ship_to_addresses || []).filter(a => String(a.CardCode || '') === vendorCode),
    [refData.ship_to_addresses, vendorCode]
  );
  const vendorBillToAddresses = useMemo(
    () => (refData.bill_to_addresses || []).filter(a => String(a.CardCode || '') === vendorCode),
    [refData.bill_to_addresses, vendorCode]
  );
  const vendorEffectiveShipToAddresses = useMemo(
    () => vendorShipToAddresses.length ? vendorShipToAddresses : vendorPayToAddresses,
    [vendorShipToAddresses, vendorPayToAddresses]
  );
  const vendorEffectiveBillToAddresses = useMemo(
    () => vendorBillToAddresses.length ? vendorBillToAddresses : vendorPayToAddresses,
    [vendorBillToAddresses, vendorPayToAddresses]
  );
  const selectedBranch = useMemo(
    () => refData.branches.find(b => String(b.BPLId || '') === String(header.branch || '')),
    [refData.branches, header.branch]
  );
  const hasSelectedBranchOption =
    !normalizeSubmitBranch(header.branch) ||
    refData.branches.some(b => String(b.BPLId || '') === String(header.branch || ''));
  const firstLineWhse = String(lines[0]?.whse || '').trim();
  const selectedWhseAddr = useMemo(
    () => refData.warehouse_addresses.find(w => String(w.WhsCode || '') === firstLineWhse),
    [refData.warehouse_addresses, firstLineWhse]
  );
  const defaultShipTo = useMemo(() => fmtAddr(refData.company_address), [refData.company_address]);
  const uomGroupMap = useMemo(
    () => (refData.uom_groups || []).reduce((acc, g) => { acc[g.AbsEntry] = g.uomCodes || []; return acc; }, {}),
    [refData.uom_groups]
  );

  const effectiveTaxCodes = refData.tax_codes || [];
  const effectiveSalesEmployees = refData.sales_employees.length
    ? refData.sales_employees
    : [{ SlpCode: -1, SlpName: 'No Sales Employee / Buyer', Active: 'Y' }];
  const effectiveWarehouses = useMemo(
    () => refData.warehouses.length ? refData.warehouses : FALLBACK_WAREHOUSES,
    [refData.warehouses]
  );
  const branchFilteredWarehouses = useMemo(
    () => filterWarehousesByBranch(effectiveWarehouses, header.branch),
    [effectiveWarehouses, header.branch]
  );
  const freightTotals = summarizeFreightRows(freightModal.freightCharges, effectiveTaxCodes);
  const payTermOpts = refData.payment_terms.length
    ? refData.payment_terms.map(t => ({ value: String(t.GroupNum), label: t.PymntGroup }))
    : FALLBACK_PAYMENT_TERMS;
  const paymentMethodOpts = (refData.payment_methods || []).map(method => ({
    value: String(method.Code || '').trim(),
    label: method.Description
      ? `${method.Code} - ${method.Description}`
      : String(method.Code || '').trim(),
  })).filter(method => method.value);
  const shipTypeOpts = refData.shipping_types.length
    ? refData.shipping_types.map(s => ({ value: String(s.TrnspCode), label: s.TrnspName }))
    : FALLBACK_SHIPPING;

  useEffect(() => {
    if (isHydratingDocumentRef.current || currentDocEntry || requestedEditDocEntry || defaultWarehouseAppliedRef.current) return;

    const defaultWarehouse = String(generalSettingsRef.current.deliveryWarehouse || '').trim();
    if (!defaultWarehouse) {
      defaultWarehouseAppliedRef.current = true;
      return;
    }

    if (!effectiveWarehouses.length) return;

    const warehouse = effectiveWarehouses.find((entry) => String(getWarehouseCode(entry) || '') === defaultWarehouse);
    defaultWarehouseAppliedRef.current = true;
    if (!warehouse) return;

    const warehouseBranch = getWarehouseBranchValue(effectiveWarehouses, defaultWarehouse);
    setHeader((prev) => {
      if (prev.warehouse && String(prev.warehouse) !== defaultWarehouse) return prev;
      return {
        ...prev,
        warehouse: prev.warehouse || defaultWarehouse,
        branch: prev.branch || warehouseBranch,
      };
    });
  }, [currentDocEntry, effectiveWarehouses, requestedEditDocEntry]);

  useEffect(() => {
    if (isHydratingDocumentRef.current || currentDocEntry || !header.warehouse) return;

    const alignedBranch = alignBranchWithWarehouse(header.branch, header.warehouse, effectiveWarehouses);
    if (alignedBranch !== normalizeSubmitBranch(header.branch)) {
      setHeader(prev => ({ ...prev, branch: alignedBranch }));
    }
  }, [currentDocEntry, effectiveWarehouses, header.branch, header.warehouse]);

  const resolveDeliveryAddress = useCallback((code, addresses = [], fallbackText = '') => {
    const normalizedCode = String(code || '').trim();
    if (normalizedCode) {
      const exactMatch = addresses.find((address) => String(address?.Address || '').trim() === normalizedCode);
      if (exactMatch) return exactMatch;
    }

    const normalizedFallbackText = normalizeAddressText(fallbackText);
    if (normalizedFallbackText) {
      return addresses.find((address) => normalizeAddressText(fmtAddr(address)) === normalizedFallbackText) || null;
    }

    return null;
  }, []);

  const eWayBillLiveData = useMemo(() => {
    const billTo = resolveDeliveryAddress(
      header.billToCode || header.payToCode,
      vendorEffectiveBillToAddresses,
      header.billToAddress || header.payTo,
    ) || vendorEffectiveBillToAddresses[0] || {};
    const shipTo = resolveDeliveryAddress(
      header.shipToCode,
      vendorEffectiveShipToAddresses,
      header.shipToAddress || header.shipTo,
    ) || vendorEffectiveShipToAddresses[0] || {};
    const dispatchFrom = selectedWhseAddr || refData.company_address || {};
    const stateName = (value) => getStateDisplayName(value, refData.states || []);

    return {
      mainHSN: lines.find((line) => String(line.hsnCode || '').trim())?.hsnCode || '',
      billFromName: selectedBranch?.BPLName || refData.company || '',
      billFromGSTIN: selectedBranch?.TaxIdNum || selectedBranch?.GSTRegnNo || refData.company_address?.GSTIN || '',
      billFromState: stateName(selectedBranch?.State || refData.company_address?.State),
      dispatchFromAddress: fmtAddr(dispatchFrom),
      dispatchFromPlace: dispatchFrom.City || dispatchFrom.County || '',
      dispatchFromZipCode: dispatchFrom.ZipCode || '',
      dispatchFromState: stateName(dispatchFrom.State),
      billToName: header.name || '',
      billToGSTIN: billTo.GSTIN || billTo.GSTRegnNo || '',
      billToState: stateName(billTo.State),
      shipToAddress: fmtAddr(shipTo) || header.shipToAddress || header.shipTo || '',
      shipToPlace: shipTo.City || shipTo.County || '',
      shipToZipCode: shipTo.ZipCode || '',
      shipToState: stateName(shipTo.State),
    };
  }, [
    header.billToAddress,
    header.billToCode,
    header.name,
    header.payTo,
    header.payToCode,
    header.shipTo,
    header.shipToAddress,
    header.shipToCode,
    lines,
    refData.company,
    refData.company_address,
    refData.states,
    resolveDeliveryAddress,
    selectedBranch,
    selectedWhseAddr,
    vendorEffectiveBillToAddresses,
    vendorEffectiveShipToAddresses,
  ]);

  const effectiveEWayBillLiveData = useMemo(() => {
    const stateName = (value) => getStateDisplayName(value, refData.states || []);
    const transporter = (refData.eway_bill_transporters || []).find((entry) =>
      String(entry.AbsEntry ?? entry.TspEntry ?? '') === String(eWayBillDetails.transporterEntry ?? ''));
    const savedDetails = { ...eWayBillDetails };
    ['billFromState', 'dispatchFromState', 'billToState', 'shipToState'].forEach((field) => {
      if (Object.prototype.hasOwnProperty.call(savedDetails, field)) {
        savedDetails[field] = stateName(savedDetails[field]);
      }
    });
    if (transporter || savedDetails.transporterEntry || savedDetails.transporterCode) {
      savedDetails.transporterCode = savedDetails.transporterCode || transporter?.TransCode || '';
      savedDetails.transporterName = savedDetails.transporterName || transporter?.TransName || '';
      savedDetails.transporterId = savedDetails.transporterId || transporter?.TransID || transporter?.GSTIN || '';
    }
    return { ...eWayBillLiveData, ...savedDetails };
  }, [eWayBillDetails, eWayBillLiveData, refData.eway_bill_transporters, refData.states]);

  const saveEWayBillDetails = useCallback(({ udfUpdates = {}, details = {} }) => {
    markDirty();
    setHeaderUdfs((current) => ({ ...current, ...udfUpdates }));
    setEWayBillDetails(details);
  }, [markDirty]);

  const getUomOptions = useCallback((line) => {
    const item = refData.items.find(i => String(i.ItemCode || '') === String(line.itemNo || ''));
    if (item) {
      const codes = uomGroupMap[item.UoMGroupEntry];
      if (codes && codes.length) return codes;
      const fb = String(item.SalesUnit || item.InventoryUOM || '').trim();
      if (fb) return [fb];
    }
    return FALLBACK_UOM;
  }, [refData.items, uomGroupMap]);

  const lineItemOptions = lines.reduce((acc, line, i) => {
    const code = String(line.itemNo || '').trim();
    const exists = refData.items.some(it => String(it.ItemCode || '') === code);
    acc[i] = code && !exists ? [{ ItemCode: code, ItemName: line.itemDescription || code }, ...refData.items] : refData.items;
    return acc;
  }, {});

  const fmtTaxLabel = (t) => {
    const code = String(t?.Code || '').trim();
    const name = String(t?.Name || '').trim();
    const up = `${code} ${name}`.toUpperCase();
    let type = '';
    if (up.includes('IGST')) type = 'IGST';
    else if (up.includes('CGST') && up.includes('SGST')) type = 'CGST+SGST';
    else if (up.includes('CGST')) type = 'CGST';
    else if (up.includes('SGST')) type = 'SGST';
    else if (up.includes('GST')) type = 'GST';
    const rate = t?.Rate != null ? `${Number(t.Rate)}%` : '';
    if (type && rate) return `${code} - ${type} ${rate}`;
    if (type) return `${code} - ${type}`;
    return name ? `${code} - ${name}` : code;
  };

  const getBranchName = (branchId) => {
    if (!branchId) return '';
    const branch = refData.branches.find(b => String(b.BPLId) === String(branchId));
    return branch ? branch.BPLName : branchId;
  };

  // ── calculations ──────────────────────────────────────────────────────────
  const calcLineTotal = (line) => {
    const qty = parseNum(line.quantity), price = parseNum(line.unitPrice), disc = parseNum(line.stdDiscount);
    return roundTo(qty * price * (1 - disc / 100), numDec.total);
  };

  const calcTotals = () => {
    const taxRateMap = new Map(effectiveTaxCodes.map(t => [String(t.Code || ''), parseNum(t.Rate)]));
    const subtotal = lines.reduce((s, l) => s + calcLineTotal(l), 0);
    const discPct = parseNum(header.discount);
    const discAmt = roundTo(subtotal * discPct / 100, numDec.total);
    const discSub = Math.max(0, subtotal - discAmt);
    const freight = roundTo(parseNum(header.freight), numDec.total);
    const freightTaxAmt = roundTo(parseNum(freightTotals.totalTax), numDec.tax);
    let taxAmt = 0;
    const taxMap = new Map();
    if (subtotal > 0) {
      lines.forEach(l => {
        const net = calcLineTotal(l);
        if (net <= 0 || !l.taxCode) return;
        const rate = taxRateMap.get(String(l.taxCode || '')) || 0;
        const base = discSub * (net / subtotal);
        const explicitTaxValue = String(l.taxAmount ?? '').trim() === '' ? null : Number(l.taxAmount);
        const lineTax = Number.isFinite(explicitTaxValue)
          ? roundTo(explicitTaxValue, numDec.tax)
          : roundTo(base * rate / 100, numDec.tax);
        taxAmt += lineTax;
        const ex = taxMap.get(l.taxCode) || { taxCode: l.taxCode, taxRate: rate, taxableAmount: 0, taxAmount: 0 };
        ex.taxableAmount = roundTo(ex.taxableAmount + base, numDec.total);
        ex.taxAmount = roundTo(ex.taxAmount + lineTax, numDec.tax);
        taxMap.set(l.taxCode, ex);
      });
    }
    taxAmt = roundTo(taxAmt, numDec.tax);
    if (taxAmt === 0) { const lt = roundTo(parseNum(header.tax), numDec.tax); if (lt > 0) taxAmt = lt; }
    taxAmt = roundTo(taxAmt + freightTaxAmt, numDec.tax);
    const totalBeforeRounding = roundTo(discSub + freight + taxAmt, numDec.totalPaymentDue);
    const roundingAmount = header.rounding ? calcRoundingAmount(totalBeforeRounding, numDec.totalPaymentDue) : 0;
    const total = roundTo(totalBeforeRounding + roundingAmount, numDec.totalPaymentDue);
    return {
      subtotal,
      discAmt,
      discSub,
      freight,
      freightTaxAmt,
      taxAmt,
      totalBeforeRounding,
      roundingAmount,
      total,
      taxBreakdown: Array.from(taxMap.values()),
    };
  };

  const totals = calcTotals();
  useRelationshipMapRegistration({
    enabled: Boolean(currentDocEntry),
    objectType: 15,
    docEntry: currentDocEntry,
    header,
    total: totals.total,
  });

  // Continue in next part...

  // ── address sync ──────────────────────────────────────────────────────────
  useEffect(() => {
    setHeader(prev => {
      if (prev.shipToCode) return prev;
      const next = selectedWhseAddr ? fmtAddr(selectedWhseAddr) : defaultShipTo;
      if (!next || prev.shipTo === next) return prev;
      return { ...prev, shipToCode: selectedWhseAddr ? selectedWhseAddr.WhsCode : 'COMPANY', shipTo: next };
    });
  }, [selectedWhseAddr, defaultShipTo]);

  useEffect(() => {
    if (!header.vendor) return;
    setHeader(prev => {
      const currentPayToCode = String(prev.payToCode || '').trim();
      const existing = vendorPayToAddresses.find(a => String(a.Address || '').trim() === currentPayToCode);
      if (existing) return prev;
      const def = vendorPayToAddresses[0];
      if (!def) return prev;
      const defaultPayToCode = String(def.Address || '').trim();
      const fmt = fmtAddr(def);
      if (!defaultPayToCode && !fmt) return prev;
      if (currentPayToCode === defaultPayToCode && String(prev.payTo || '') === fmt) return prev;
      return { ...prev, payToCode: defaultPayToCode, payTo: fmt };
    });
  }, [header.vendor, vendorPayToAddresses]);

  useEffect(() => {
    if (!currentDocEntry || !header.vendor) return;

    const resolveAddressCode = (addresses, currentCode, currentText) => {
      const normalizedCode = String(currentCode || '').trim();
      if (normalizedCode && addresses.some((address) => String(address.Address || '').trim() === normalizedCode)) {
        return normalizedCode;
      }

      const normalizedText = normalizeAddressText(currentText);
      if (!normalizedText) return '';

      const matchedAddress = addresses.find((address) => {
        const formatted = normalizeAddressText(fmtAddr(address));
        if (formatted && formatted === normalizedText) return true;

        const compactFormatted = formatted.replace(/\s+/g, '');
        const compactText = normalizedText.replace(/\s+/g, '');
        return compactFormatted && compactFormatted === compactText;
      });

      return matchedAddress ? String(matchedAddress.Address || '').trim() : '';
    };

    const resolvedShipToCode = resolveAddressCode(
      vendorEffectiveShipToAddresses,
      header.shipToCode,
      header.shipToAddress || header.shipTo
    );
    const resolvedBillToCode = resolveAddressCode(
      vendorEffectiveBillToAddresses,
      header.billToCode || header.payToCode,
      header.billToAddress || header.payTo
    );

    if (
      resolvedShipToCode === String(header.shipToCode || '').trim() &&
      resolvedBillToCode === String(header.billToCode || '').trim()
    ) {
      return;
    }

    setHeader((prev) => ({
      ...prev,
      shipToCode: resolvedShipToCode || prev.shipToCode,
      billToCode: resolvedBillToCode || prev.billToCode,
      payToCode: resolvedBillToCode || prev.payToCode,
    }));
  }, [
    currentDocEntry,
    header.vendor,
    header.shipToCode,
    header.shipToAddress,
    header.shipTo,
    header.billToCode,
    header.billToAddress,
    header.payToCode,
    header.payTo,
    vendorEffectiveShipToAddresses,
    vendorEffectiveBillToAddresses,
  ]);

  // ── vendor details ────────────────────────────────────────────────────────
  const loadVendorDetails = async (code, options = {}) => {
    const { preserveExisting = false, selectedBillToCode = '' } = options;
    if (!code) {
      setRefData(p => ({ ...p, contacts: [], pay_to_addresses: [], ship_to_addresses: [], bill_to_addresses: [] }));
      setHeader(prev => ({ ...prev, placeOfSupply: '' }));
      return;
    }

    setPageState(p => ({ ...p, vendorLoading: true }));

    try {
      const r = await fetchDeliveryCustomerDetails(code);
      const contacts = r.data.contacts || [];
      const payToAddresses = r.data.pay_to_addresses || [];
      const shipToAddresses = r.data.ship_to_addresses || [];
      const billToAddresses = r.data.bill_to_addresses || [];
      
      setRefData(p => ({
        ...p,
        contacts: contacts,
        pay_to_addresses: payToAddresses,
        ship_to_addresses: shipToAddresses,
        bill_to_addresses: billToAddresses
      }));

      const defaultShipToAddress = shipToAddresses[0] || payToAddresses[0] || null;
      const defaultBillToAddress = billToAddresses[0] || payToAddresses[0] || null;
      const selectedTaxAddress = billToAddresses.find((address) => String(address.Address || '') === String(selectedBillToCode || header.billToCode || header.payToCode || '')) || defaultBillToAddress;

      if (selectedTaxAddress) {
        const gstin = String(selectedTaxAddress.GSTIN || '').trim();
        setTaxInfoForm((current) => ({
          ...current,
          panNo: gstin.length >= 12 ? gstin.slice(2, 12) : current.panNo,
          gstType: getBpGstTypeLabel(selectedTaxAddress.GSTType) || current.gstType,
          gstin: gstin || current.gstin,
        }));
      }

      setHeader(prev => {
        const nextHeader = { ...prev };

        if (contacts.length > 0 && (!preserveExisting || !prev.contactPerson)) {
          nextHeader.contactPerson = contacts[0].CntctCode;
        }

        if (defaultShipToAddress) {
          const formattedShipTo = fmtAddr(defaultShipToAddress);
          if (!preserveExisting || !prev.shipToCode) {
            nextHeader.shipToCode = defaultShipToAddress.Address || '';
            nextHeader.shipToAddress = formattedShipTo;
            nextHeader.shipTo = formattedShipTo;
          }

          if (defaultShipToAddress.State && (!preserveExisting || !prev.placeOfSupply)) {
            console.log('🌍 Auto-setting Place of Supply from customer address:', defaultShipToAddress.State);
            const stateMatch = refData.states.find(st =>
              st.Name === defaultShipToAddress.State || st.Code === defaultShipToAddress.State
            );
            nextHeader.placeOfSupply = stateMatch ? stateMatch.Code : defaultShipToAddress.State;
          }
        }

        if (defaultBillToAddress && (!preserveExisting || !prev.billToCode)) {
          const formattedBillTo = fmtAddr(defaultBillToAddress);
          nextHeader.billToCode = defaultBillToAddress.Address || '';
          nextHeader.billToAddress = formattedBillTo;
          nextHeader.payToCode = defaultBillToAddress.Address || '';
          nextHeader.payTo = formattedBillTo;
        }

        return nextHeader;
      });

    } catch (err) {
      console.error('Error loading customer details:', err);
      setRefData(p => ({ ...p, contacts: [], pay_to_addresses: [], ship_to_addresses: [], bill_to_addresses: [] }));
    } finally {
      setPageState(p => ({ ...p, vendorLoading: false }));
    }
  };

  const getDefaultJournalRemark = (code) => {
    const normalizedCode = String(code || '').trim();
    return normalizedCode ? `Deliveries - ${normalizedCode}` : '';
  };

  const getDefaultPaymentMethod = (bp = {}) => (
    String(bp.PaymentMethod || bp.PymCode || bp.PeymentMethodCode || '').trim()
  );

  const syncVendor = (code, hdr) => {
    const m = refData.vendors.find(v => String(v.CardCode || '') === String(code || ''));
    if (!m) return { nextHeader: hdr };
    return {
      nextHeader: {
        ...hdr,
        name: m.CardName || hdr.name,
        journalRemark: getDefaultJournalRemark(code),
        paymentTerms: m.PayTermsGrpCode != null ? String(m.PayTermsGrpCode) : hdr.paymentTerms,
        paymentMethod: getDefaultPaymentMethod(m) || hdr.paymentMethod,
        contactPerson: '',
      },
    };
  };

  // ── handlers ──────────────────────────────────────────────────────────────
  const buildSalesEmployeeSetupRows = () => {
    const rows = effectiveSalesEmployees.map(employee => {
      const row = {
        SlpCode: employee.SlpCode,
        SlpName: employee.SlpName || '',
        Commission: employee.Commission != null ? String(employee.Commission) : '',
        Memo: employee.Memo || '',
        Active: String(employee.Active || 'Y').toUpperCase() !== 'N',
        Employee: false,
      };

      return {
        ...row,
        __original: {
          SlpName: row.SlpName,
          Commission: row.Commission,
          Memo: row.Memo,
          Active: row.Active,
        },
      };
    });

    return [
      ...rows,
      { SlpCode: '', SlpName: '', Commission: '', Memo: '', Active: true, Employee: false },
    ];
  };

  const openSalesEmployeeSetup = () => {
    setSalesEmployeeSetup({ open: true, rows: buildSalesEmployeeSetupRows(), saving: false });
  };

  const closeSalesEmployeeSetup = () => {
    setSalesEmployeeSetup(prev => ({ ...prev, open: false, saving: false }));
  };

  const updateSalesEmployeeSetupRow = (index, field, value) => {
    setSalesEmployeeSetup(prev => {
      const rows = prev.rows.map((row, rowIndex) => (
        rowIndex === index ? { ...row, [field]: value } : row
      ));
      const lastRow = rows[rows.length - 1];
      if (lastRow && String(lastRow.SlpName || '').trim()) {
        rows.push({ SlpCode: '', SlpName: '', Commission: '', Memo: '', Active: true, Employee: false });
      }
      return { ...prev, rows };
    });
  };

  const saveSalesEmployeeSetup = async () => {
    const hasSalesEmployeeSetupChanged = row => {
      const original = row.__original;
      if (!original) return true;

      return (
        String(row.SlpName || '').trim() !== String(original.SlpName || '').trim() ||
        String(row.Commission || '').trim() !== String(original.Commission || '').trim() ||
        String(row.Memo || '').trim() !== String(original.Memo || '').trim() ||
        Boolean(row.Active) !== Boolean(original.Active)
      );
    };

    const rowsToSave = salesEmployeeSetup.rows
      .map(row => ({
        SlpCode: row.SlpCode,
        SlpName: String(row.SlpName || '').trim(),
        Commission: String(row.Commission || '').trim(),
        Memo: row.Memo || '',
        Active: row.Active,
        Employee: row.Employee,
        Changed: hasSalesEmployeeSetupChanged(row),
      }))
      .filter(row => row.SlpName && String(row.SlpCode) !== '-1' && row.Changed);

    setSalesEmployeeSetup(prev => ({ ...prev, saving: true }));
    setPageState(p => ({ ...p, error: '', success: '' }));

    try {
      const response = await saveDeliverySalesEmployeesSetup(rowsToSave);
      setRefData(prev => ({ ...prev, sales_employees: response.data?.sales_employees || [] }));
      setSalesEmployeeSetup({ open: false, rows: [], saving: false });
      setPageState(p => ({ ...p, success: response.data?.message || 'Sales employees setup saved.' }));
    } catch (error) {
      setSalesEmployeeSetup(prev => ({ ...prev, saving: false }));
      setPageState(p => ({ ...p, error: getErrMsg(error, 'Failed to save sales employees setup.') }));
    }
  };

  const handleHeaderChange = (e) => {
    const { name, value, type, checked } = e.target;
    setValErrors(p => ({ ...p, header: { ...p.header, [name]: '' }, form: '' }));
    setPageState(p => ({ ...p, error: '', success: '' }));
    
    console.log('🔧 [Delivery] handleHeaderChange called:', { name, value, type });
    
    if (name === 'series') {
      handleSeriesChange(value);
      return;
    }

    if (name === 'purchaser') {
      if (value === '__DEFINE_NEW__') {
        openSalesEmployeeSetup();
        return;
      }

      const selectedEmployee = effectiveSalesEmployees.find(
        employee => String(employee.SlpName || '') === String(value || '')
      );

      setHeader(p => ({
        ...p,
        purchaser: value,
        salesEmployee: selectedEmployee ? String(selectedEmployee.SlpCode) : '-1',
      }));
      return;
    }
    
    if (name === 'shipToCode') {
      handleShipToChange(value);
      return;
    }
    
    if (name === 'vendor') {
      setHeader(prev => {
        const prep = { ...prev, [name]: value };
        const { nextHeader } = syncVendor(value, prep);
        nextHeader.contactPerson = '';
        // Reset address fields when vendor changes
        nextHeader.billToCode = '';
        nextHeader.billToAddress = '';
        nextHeader.shipToCode = '';
        nextHeader.shipToAddress = '';
        nextHeader.placeOfSupply = '';
        return nextHeader;
      });
      loadVendorDetails(value);
      return;
    }

    if (name === 'billToCode') {
      handleBillToChange(value);
      return;
    }

    if (name === 'shipToCode') {
      handleShipToChange(value);
      return;
    }
    if (numDec[name] !== undefined && type !== 'checkbox') {
      setHeader(p => ({ ...p, [name]: sanitize(value, numDec[name]) }));
      if (name === 'discount') {
        setLines(prevLines => prevLines.map(line => (
          String(line.taxAmount ?? '').trim() ? { ...line, taxAmount: '' } : line
        )));
      }
      return;
    }
    
    if (name === 'branch') {
      console.log('🏢 [Delivery] Branch changing to:', value);
      // Clear warehouse when branch changes since it might not belong to the new branch
      setHeader(p => ({ ...p, [name]: value, warehouse: '' }));
      return;
    }
    
    setHeader(p => ({ ...p, [name]: type === 'checkbox' ? checked : value }));
  };
  
  const handleShipToChange = (addressCode) => {
    if (!addressCode || !header.vendor) {
      setHeader(p => ({ ...p, shipToCode: addressCode, shipToAddress: '', placeOfSupply: '' }));
      return;
    }

    const addr = vendorEffectiveShipToAddresses.find(a => String(a.Address || '') === addressCode)
      || vendorEffectiveBillToAddresses.find(a => String(a.Address || '') === addressCode);
    if (addr) {
      // Find the state code that matches the state name
      const stateMatch = refData.states.find(st => 
        st.Name === addr.State || st.Code === addr.State
      );
      const stateCode = stateMatch ? stateMatch.Code : (addr.State || '');
      
      setHeader(p => ({
        ...p,
        shipToCode: addressCode,
        shipToAddress: fmtAddr(addr),
        shipTo: fmtAddr(addr),
        placeOfSupply: stateCode
      }));
    }
  };

  const handleBillToChange = (addressCode) => {
    if (!addressCode || !header.vendor) {
      setHeader(p => ({ ...p, billToCode: addressCode, billToAddress: '' }));
      return;
    }

    const addr = vendorEffectiveBillToAddresses.find(a => String(a.Address || '') === addressCode)
      || vendorEffectiveShipToAddresses.find(a => String(a.Address || '') === addressCode);
    if (addr) {
      setHeader(p => ({
        ...p,
        billToCode: addressCode,
        billToAddress: fmtAddr(addr),
        payToCode: addressCode,
        payTo: fmtAddr(addr)
      }));
    }
  };
  
  const handleSeriesChange = async (seriesValue) => {
    if (!seriesValue) return;
    
    setPageState(p => ({ ...p, seriesLoading: true }));
    setHeader(p => ({ ...p, series: seriesValue, nextNumber: '...' }));
    
    try {
      const res = await fetchNextNumber(seriesValue);
      setHeader(p => ({ ...p, nextNumber: String(res.data.nextNumber || '') }));
    } catch (err) {
      setHeader(p => ({ ...p, nextNumber: 'Error' }));
      setPageState(p => ({ ...p, error: 'Failed to get next document number' }));
    } finally {
      setPageState(p => ({ ...p, seriesLoading: false }));
    }
  };

  const handleLineChange = async (i, e) => {
    const { name, value } = e.target;
    setValErrors(p => ({ ...p, lines: { ...p.lines, [i]: { ...(p.lines[i] || {}), [name]: '' } }, form: '' }));
    setPageState(p => ({ ...p, error: '', success: '' }));
    
    if (name === 'itemNo' && value) {
      // Fetch HSN code from database via API
      try {
        const item = refData.items.find(it => String(it.ItemCode || '') === String(value || ''));
        
        if (item) {
          // Fetch HSN code from OCHP table via JOIN query
          const hsnResponse = await fetchHSNCodeFromItem(value);
          const hsnData = hsnResponse.data;
          
          console.log('🔍 Item Selected - HSN Data:', {
            itemCode: value,
            hsnCode: hsnData.hsnCode,
            hsnDescription: hsnData.hsnDescription,
            hsn_sww: hsnData.hsn_sww,
          });
          
          setLines(prev => prev.map((line, idx) => {
            if (idx !== i) return line;
            const next = clearBaseDocumentLink({ ...line, itemNo: value, taxAmount: '', taxCodeManuallyOverridden: false });
            
            // Reset batches
            next.batches = [];
            next.batchManaged = isBatchManaged(item);
            next.hasBatchesAvailable = false;
            
            // Step 1: Set Item Details
            next.itemDescription = item.ItemName || next.itemDescription;
            next.uomCode = String(item.SalesUnit || item.InventoryUOM || '').trim();
            next.uomName = String(item.SalesUnit || item.InventoryUOM || next.uomCode || '').trim();
            next.itemCost = item.ItemCost != null ? String(item.ItemCost) : (item.AvgPrice != null ? String(item.AvgPrice) : next.itemCost || '');
            next.price = next.unitPrice || next.price || '';

            if (next.batchManaged && next.whse) {
              checkBatchAvailability(next.itemNo, next.whse).then(hasBatches => {
                setLines(prevLines => prevLines.map((l, lIdx) =>
                  lIdx === i ? { ...l, hasBatchesAvailable: hasBatches } : l
                ));
              });
            }
            
            // Step 2: Set HSN Code from API response (OCHP.ChapterID via JOIN)
            next.hsnCode = hsnData.hsnCode || hsnData.hsn_sww || '';
            
            // Step 3: Get Base Tax Code from Item Master
            const baseTaxCode = item.TaxCodeAR || item.SalTaxCode || '';
            
            console.log('🔍 Item Selected:', {
              itemCode: item.ItemCode,
              itemName: item.ItemName,
              hsnCode: next.hsnCode,
              baseTaxCode: baseTaxCode,
              placeOfSupply: header.placeOfSupply,
            });
            
            // Step 4: Determine GST State (Place of Supply)
            const gstState = header.placeOfSupply;
            const companyState = refData.company_address?.State || selectedBranch?.State || '';
            
            // Step 5: Validate States
            if (!gstState || !companyState) {
              console.warn('⚠️ Missing state information for tax determination');
              next.taxCode = '';
              next.total = fmtDec(calcLineTotal(next), numDec.total);
              return next;
            }
            
            // Step 6: Auto-Determine Tax Code using Tax Engine
            const determinedTaxCode = determineTaxCode(
              item,
              gstState,  // shipToState
              gstState,  // billToState (using same as shipTo)
              false,     // useBillToForTax
              companyState,
              effectiveTaxCodes
            );
            
            if (determinedTaxCode) {
              next.taxCode = determinedTaxCode;
              console.log(`✅ Auto-assigned tax code: ${determinedTaxCode} (${getGSTTypeLabel(companyState, gstState)})`);
            } else {
              console.warn('⚠️ Could not determine tax code automatically');
              next.taxCode = '';
            }
            
            next.total = fmtDec(calcLineTotal(next), numDec.total);
            return next;
          }));
        }
      } catch (error) {
        console.error('❌ Error fetching HSN code:', error);
        // Fallback to basic item selection without HSN
        setLines(prev => prev.map((line, idx) => {
          if (idx !== i) return line;
          const next = clearBaseDocumentLink({ ...line, itemNo: value, taxAmount: '', taxCodeManuallyOverridden: false });
          const item = refData.items.find(it => String(it.ItemCode || '') === String(value || ''));
          next.batches = [];
          next.batchManaged = isBatchManaged(item);
          next.hasBatchesAvailable = false; // Reset batch availability
          
          // Check batch availability if item is batch-managed and warehouse is selected
          if (item && next.batchManaged && next.whse) {
            checkBatchAvailability(next.itemNo, next.whse).then(hasBatches => {
              setLines(prevLines => prevLines.map((l, lIdx) => 
                lIdx === i ? { ...l, hasBatchesAvailable: hasBatches } : l
              ));
            });
          }
          
          if (item) {
            next.itemDescription = item.ItemName || next.itemDescription;
            next.uomCode = String(item.SalesUnit || item.InventoryUOM || '').trim();
            next.uomName = String(item.SalesUnit || item.InventoryUOM || next.uomCode || '').trim();
            next.itemCost = item.ItemCost != null ? String(item.ItemCost) : (item.AvgPrice != null ? String(item.AvgPrice) : next.itemCost || '');
            next.price = next.unitPrice || next.price || '';
            next.hsnCode = item.SWW || item.HSNCode || item.U_HSNCode || next.hsnCode || '';
          }
          next.total = fmtDec(calcLineTotal(next), numDec.total);
          return next;
        }));
      }
      return;
    }
    
    setLines(prev => prev.map((line, idx) => {
      if (idx !== i) return line;
      const next = { ...line, [name]: numDec[name] !== undefined ? sanitize(value, numDec[name]) : value };
      if (TAX_SENSITIVE_LINE_FIELDS.has(name)) {
        next.taxAmount = '';
      }
      
      // Handle warehouse change
      if (name === 'whse') {
        next.batches = [];
        next.hasBatchesAvailable = false; // Reset batch availability
        
        // Check batch availability if item is batch-managed and warehouse is selected
        if (next.batchManaged && value) {
          checkBatchAvailability(next.itemNo, value).then(hasBatches => {
            setLines(prevLines => prevLines.map((l, lIdx) => 
              lIdx === i ? { ...l, hasBatchesAvailable: hasBatches } : l
            ));
          });
        }
      }
      
      // Handle UoM change - fetch conversion factor
      if (name === 'uomCode' && value && next.itemNo) {
        // Fetch UoM conversion factor asynchronously
        fetchUomConversionFactor(next.itemNo, value)
          .then(response => {
            const { factor, inventoryUOM: invUoM } = response.data;
            console.log('🔄 UoM Conversion:', {
              itemCode: next.itemNo,
              documentUoM: value,
              inventoryUOM: invUoM,
              factor,
              docQty: next.quantity,
              baseQty: parseNum(next.quantity) * factor
            });
            
            setLines(prevLines => prevLines.map((l, lIdx) => 
              lIdx === i ? { 
                ...l, 
                uomFactor: factor,
                inventoryUOM: invUoM
              } : l
            ));
          })
          .catch(error => {
            console.error('❌ Failed to fetch UoM conversion factor:', error);
            // Default to factor 1 if fetch fails
            setLines(prevLines => prevLines.map((l, lIdx) => 
              lIdx === i ? { ...l, uomFactor: 1 } : l
            ));
          });
      }
      if (name === 'taxCode') {
        next.taxCodeManuallyOverridden = Boolean(String(next.taxCode || '').trim());
      }
      
      next.total = fmtDec(calcLineTotal(next), numDec.total);
      return next;
    }));
  };

  const handleNumBlur = (field, target = 'line', i = null) => {
    const d = numDec[field];
    if (d === undefined) return;
    if (target === 'header') { setHeader(p => ({ ...p, [field]: fmtDec(p[field], d) })); return; }
    setLines(p => p.map((l, idx) => {
      if (idx !== i) return l;
      if (field === 'quantity' && l.batchManaged && Array.isArray(l.batches) && l.batches.length > 0) {
        return { ...l, [field]: String(roundTo(parseNum(l[field]), Math.max(d, 6))) };
      }
      return { ...l, [field]: fmtDec(l[field], d) };
    }));
  };

  const addLine = () => {
    // Validate the last line before adding a new one
    if (lines.length > 0) {
      const lastLine = lines[lines.length - 1];
      const lastIndex = lines.length - 1;
      const errors = {};
      
      // Check if last line has an item
      if (!String(lastLine.itemNo || '').trim()) {
        errors.itemNo = 'Item is required before adding a new line';
      }
      
      // Check if last line has HSN Code
      if (!String(lastLine.hsnCode || '').trim()) {
        errors.hsnCode = 'HSN Code is required before adding a new line';
      }
      
      // Check if last line has quantity
      if (!lastLine.quantity || Number(lastLine.quantity) <= 0) {
        errors.quantity = 'Quantity is required before adding a new line';
      }
      
      // Check if last line has unit price
      if (!lastLine.unitPrice || Number(lastLine.unitPrice) <= 0) {
        errors.unitPrice = 'Unit Price is required before adding a new line';
      }
      
      // Check if last line has Tax Code
      if (!String(lastLine.taxCode || '').trim()) {
        errors.taxCode = 'Tax Code is required before adding a new line';
      }
      
      // Check if last line has Warehouse
      if (!String(lastLine.whse || '').trim()) {
        errors.whse = 'Warehouse is required before adding a new line';
      }
      
      // If there are errors, show them and don't add new line
      if (Object.keys(errors).length > 0) {
        setValErrors(p => ({
          ...p,
          lines: { ...p.lines, [lastIndex]: errors },
          form: 'Please complete the current line before adding a new one.'
        }));
        setPageState(p => ({ 
          ...p, 
          error: 'Please complete the current line before adding a new one.' 
        }));
        return;
      }
    }
    
    // Clear errors and add new line with current header values
    setValErrors(p => ({ ...p, form: '' }));
    setPageState(p => ({ ...p, error: '' }));
    markDirty();
    
    console.log('➕ [Delivery] Adding new line with header values:', {
      branch: header.branch,
      loc: header.branch,
      whse: header.warehouse
    });
    
    setLines(p => [...p, { 
      ...createLine(rowUdfDefinitions, headerUdfs), 
      branch: header.branch || '', 
      loc: header.branch || '',
      whse: header.warehouse || ''
    }]);
  };

  const removeLine = (i) => {
    markDirty();
    setValErrors(p => { const nl = { ...p.lines }; delete nl[i]; return { ...p, lines: nl, form: '' }; });
    setLines(p => p.filter((_, idx) => idx !== i));
  };

  const handleHeaderUdfChange = (k, v) => {
    markDirty();
    setHeaderUdfs(p => ({ ...p, [k]: v }));
    // Auto-fill existing lines' UDFs when header UDF value is provided and line UDF is empty
    if (hasUdfValue(v)) {
      const headerField = headerUdfDefinitions.find((field) => field.key === k) || { key: k };
      const targetKeys = new Set(findMatchingRowUdfKeys(headerField, rowUdfDefinitions));
      if (rowUdfDefinitions.some((field) => field.key === k)) targetKeys.add(k);

      setLines(prev => prev.map((l) => {
        const current = l.udf || {};
        const updates = {};
        targetKeys.forEach((targetKey) => {
          if (!hasUdfValue(current[targetKey])) updates[targetKey] = v;
        });
        return Object.keys(updates).length ? { ...l, udf: mergeUdfValues(current, updates) } : l;
      }));
    }
  };
  const handleRowUdfChange = (i, k, v) => {
    markDirty();
    setLines(p => p.map((l, idx) => {
      if (idx !== i) return l;
      const mirroredUdf = String(k || '').startsWith('U_') ? { [k]: v } : {};
      return { ...l, ...mirroredUdf, udf: { ...(l.udf || {}), [k]: v } };
    }));
  };
  const updateFormSetting = (g, k, prop, val) => setFormSettings(p => ({ ...p, [g]: { ...(p[g] || {}), [k]: { ...((p[g] || {})[k] || {}), [prop]: val } } }));
  const toggleHeaderUdfs = () => {
    setFormSettingsOpen(false);
    setSidebarOpen(p => !p);
  };
  const toggleFormSettings = () => {
    setSidebarOpen(false);
    setFormSettingsOpen(p => !p);
  };

  // ── Address Modal handlers ────────────────────────────────────────────────
  const openAddressModal = (type) => {
    const shipAddress = resolveDeliveryAddress(
      header.shipToCode,
      vendorEffectiveShipToAddresses,
      header.shipToAddress || header.shipTo,
    );
    const billAddress = resolveDeliveryAddress(
      header.billToCode || header.payToCode,
      vendorEffectiveBillToAddresses,
      header.billToAddress || header.payTo,
    );
    const activeAddress = type === 'billTo' ? billAddress : shipAddress;
    const activeComponents = type === 'billTo'
      ? header.billToAddressComponents
      : header.shipToAddressComponents;

    setAddressForm(
      {
        ...mapAddressToModalForm(activeAddress, {
          shipToCode: header.shipToCode || shipAddress?.Address || '',
          shipToAddress: header.shipToAddress || header.shipTo || (shipAddress ? fmtAddr(shipAddress) : ''),
          billToCode: header.billToCode || header.payToCode || billAddress?.Address || '',
          billToAddress: header.billToAddress || header.payTo || (billAddress ? fmtAddr(billAddress) : ''),
        }),
        ...(activeComponents || {}),
      },
    );
    setAddressModal({ type });
  };

  const closeAddressModal = () => {
    setAddressModal(null);
  };

  const saveAddressModal = () => {
    const formatted = formatAddressComponent(addressForm);
    const components = pickAddressComponentFields(addressForm);
    markDirty();

    if (addressModal.type === 'shipTo') {
      setHeader(p => ({
        ...p,
        shipToCode: addressForm.shipToCode,
        shipTo: formatted,
        shipToAddress: formatted,
        shipToAddressComponents: components,
        billToCode: addressForm.billToCode || p.billToCode,
        payToCode: addressForm.billToCode || p.payToCode,
        billToAddress: addressForm.billToAddress || p.billToAddress,
        payTo: addressForm.billToAddress || p.payTo,
        placeOfSupply: addressForm.state || '',
      }));
    } else {
      setHeader(p => ({
        ...p,
        shipToCode: addressForm.shipToCode || p.shipToCode,
        shipToAddress: addressForm.shipToAddress || p.shipToAddress,
        shipTo: addressForm.shipToAddress || p.shipTo,
        billToCode: addressForm.billToCode,
        payToCode: addressForm.billToCode,
        billToAddress: formatted,
        payTo: formatted,
        billToAddressComponents: components,
        placeOfSupply: header.useBillToForTax ? addressForm.state || '' : p.placeOfSupply,
      }));
    }
    closeAddressModal();
  };

  const handleAddressFormChange = (e) => {
    const { name, value } = e.target;

    if (name === 'shipToCode') {
      const selectedAddress = resolveDeliveryAddress(value, vendorEffectiveShipToAddresses);
      setAddressForm(prev => {
        const nextState = {
          ...prev,
          shipToCode: value,
          shipToAddress: selectedAddress ? fmtAddr(selectedAddress) : prev.shipToAddress,
        };
        return addressModal?.type === 'shipTo'
          ? mapAddressToModalForm(selectedAddress, nextState)
          : nextState;
      });
      return;
    }

    if (name === 'billToCode') {
      const selectedAddress = resolveDeliveryAddress(value, vendorEffectiveBillToAddresses);
      setAddressForm(prev => {
        const nextState = {
          ...prev,
          billToCode: value,
          billToAddress: selectedAddress ? fmtAddr(selectedAddress) : prev.billToAddress,
        };
        return addressModal?.type === 'billTo'
          ? mapAddressToModalForm(selectedAddress, nextState)
          : nextState;
      });
      return;
    }

    setAddressForm(p => ({ ...p, [name]: value }));
  };

  // ── Tax Info Modal handlers ───────────────────────────────────────────────
  const openTaxInfoModal = () => {
    setTaxInfoModal(true);
  };

  const closeTaxInfoModal = () => {
    setTaxInfoModal(false);
  };

  const saveTaxInfoModal = () => {
    closeTaxInfoModal();
  };

  // ── BP Modal handlers ─────────────────────────────────────────────────────
  const openBpModal = () => {
    setBpModal(true);
  };

  const closeBpModal = () => {
    setBpModal(false);
  };

  
  // ── State Modal handlers ──────────────────────────────────────────────────
  const openStateModal = () => {
    setStateModal(true);
  };

  const closeStateModal = () => {
    setStateModal(false);
  };

  const handleStateSelect = (state) => {
    setHeader(p => ({ ...p, placeOfSupply: getStateCodeValue(state, refData.states) }));
  };

  // ── BP Modal handlers ─────────────────────────────────────────────────────
  const handleBpSelect = (bp) => {
    const code = bp.CardCode;
    setHeader(prev => {
      const prep = { ...prev, vendor: code };
      const { nextHeader } = syncVendor(code, prep);
      nextHeader.contactPerson = '';
      // Reset address fields when vendor changes
      nextHeader.billToCode = '';
      nextHeader.billToAddress = '';
      nextHeader.shipToCode = '';
      nextHeader.shipToAddress = '';
      nextHeader.placeOfSupply = '';
      return nextHeader;
    });
    loadVendorDetails(code);
  };

  const handleTaxInfoFormChange = (e) => {
    const { name, value } = e.target;
    setTaxInfoForm(p => ({ ...p, [name]: value }));
  };

  // ── Browse Attachment handler ─────────────────────────────────────────────
  const handleBrowseAttachment = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.onchange = (e) => {
      const files = Array.from(e.target.files);
      alert(`Selected ${files.length} file(s). Upload functionality to be implemented.`);
    };
    input.click();
  };

  const closeBatchModal = () => {
    setBatchModal({ open: false, lineIndex: null, availableBatches: [], loading: false, error: '' });
  };

  const saveLineBatches = (nextBatches) => {
    if (batchModal.lineIndex == null) return;
    setLines(prev => prev.map((line, index) => {
      if (index !== batchModal.lineIndex) return line;

      const assignedBaseQty = sumBatchQty(nextBatches);
      const uomFactor = getLineUomFactor(line);
      const selectedBatchWarehouse = String(
        nextBatches.find(batch => String(batch?.whse || batch?.warehouse || '').trim())?.whse
        || nextBatches.find(batch => String(batch?.whse || batch?.warehouse || '').trim())?.warehouse
        || ''
      ).trim();
      const nextDocumentQty = uomFactor > 0
        ? roundTo(assignedBaseQty / uomFactor, 6)
        : roundTo(assignedBaseQty, 6);
      const updatedLine = {
        ...line,
        whse: selectedBatchWarehouse || line.whse,
        batches: nextBatches,
        hasBatchesAvailable: true,
        quantity: String(nextDocumentQty),
      };

      return {
        ...updatedLine,
        total: fmtDec(calcLineTotal(updatedLine), numDec.total),
      };
    }));
    setValErrors(prev => ({
      ...prev,
      lines: {
        ...prev.lines,
        [batchModal.lineIndex]: {
          ...(prev.lines[batchModal.lineIndex] || {}),
          batches: '',
          quantity: '',
        },
      },
      form: '',
    }));
    closeBatchModal();
  };

  // ── HSN Modal handlers ────────────────────────────────────────────────────
  const openHSNModal = (lineIndex) => {
    setHsnModal({ open: true, lineIndex });
  };

  const closeHSNModal = () => {
    setHsnModal({ open: false, lineIndex: -1 });
  };

  const handleHSNSelect = (hsn) => {
    if (hsnModal.lineIndex >= 0) {
      setLines(prev => prev.map((line, idx) => 
        idx === hsnModal.lineIndex 
          ? { ...line, hsnCode: hsn.code || '' }
          : line
      ));
    }
    closeHSNModal();
  };

  // ── Item Selection Modal handlers ─────────────────────────────────────────
  const getPaymentTermsLookupOptions = () => {
    const sourceTerms = refData.payment_terms.length
      ? refData.payment_terms.map((term) => ({
          code: String(term.GroupNum ?? ''),
          name: term.PymntGroup || String(term.GroupNum ?? ''),
        }))
      : FALLBACK_PAYMENT_TERMS.map((term) => ({
          code: term.value,
          name: term.label,
        }));

    return sourceTerms
      .filter((term) => term.name)
      .map((term) => ({
        value: term.name,
        description: term.code ? `Code: ${term.code}` : '',
        label: term.code ? `${term.name} (${term.code})` : term.name,
      }));
  };

  const openPaymentTermsModal = (field, lineIndex) => {
    setQualityModal({
      open: true,
      lineIndex,
      field,
      title: 'List of Buyer Terms of Payment',
      options: getPaymentTermsLookupOptions(),
      searchPlaceholder: 'Search payment terms',
      emptyMessage: 'No payment terms found',
      allowCreate: false,
    });
  };

  const openQualityModal = (field, lineIndex) => {
    const optionMap = {
      buyerQuality: {
        title: 'List of Buyer Quality Values',
        options: refData.quality_options?.buyer || [],
        searchPlaceholder: 'Search buyer quality values',
        emptyMessage: 'No buyer quality values found',
      },
      sellerQuality: {
        title: 'List of Seller Quality Values',
        options: refData.quality_options?.seller || [],
        searchPlaceholder: 'Search seller quality values',
        emptyMessage: 'No seller quality values found',
      },
      buyerPrice: {
        title: 'List of Buyer Price Values',
        options: refData.price_options?.buyer || [],
        searchPlaceholder: 'Search buyer price values',
        emptyMessage: 'No buyer price values found',
      },
      sellerPrice: {
        title: 'List of Seller Price Values',
        options: refData.price_options?.seller || [],
        searchPlaceholder: 'Search seller price values',
        emptyMessage: 'No seller price values found',
      },
    };

    const nextConfig = optionMap[field] || {
      title: 'List of User-Defined Values',
      options: [],
      searchPlaceholder: 'Search values',
      emptyMessage: 'No values found',
      allowCreate: true,
    };

    setQualityModal({
      open: true,
      lineIndex,
      field,
      title: nextConfig.title,
      options: nextConfig.options,
      searchPlaceholder: nextConfig.searchPlaceholder,
      emptyMessage: nextConfig.emptyMessage,
      allowCreate: nextConfig.allowCreate !== false,
    });
  };

  const closeQualityModal = () => {
    setQualityModal({
      open: false,
      lineIndex: -1,
      field: '',
      title: 'List of User-Defined Values',
      options: [],
      searchPlaceholder: 'Search values',
      emptyMessage: 'No values found',
      allowCreate: true,
    });
  };

  const handleQualitySelect = (option) => {
    if (qualityModal.lineIndex < 0 || !qualityModal.field) return;

    setLines(prev => prev.map((line, idx) => (
      idx === qualityModal.lineIndex
        ? { ...line, [qualityModal.field]: option?.value || '' }
        : line
    )));
  };

  const handleQualityCreate = async ({ value, description }) => {
    const field = qualityModal.field;
    if (!field) return null;

    const response = await createDeliveryLookupValue(field, value, description);
    const createdOption = response?.data?.option || {
      value,
      description: description || value,
      label: description && description !== value ? `${value} - ${description}` : value,
    };
    const nextOptions = response?.data?.options || [];

    setRefData((prev) => {
      const next = { ...prev };

      if (field === 'buyerQuality' || field === 'sellerQuality') {
        next.quality_options = {
          ...(prev.quality_options || { buyer: [], seller: [] }),
          [field === 'buyerQuality' ? 'buyer' : 'seller']: nextOptions,
        };
      }

      if (field === 'buyerPrice' || field === 'sellerPrice') {
        next.price_options = {
          ...(prev.price_options || { buyer: [], seller: [] }),
          [field === 'buyerPrice' ? 'buyer' : 'seller']: nextOptions,
        };
      }

      return next;
    });

    setQualityModal((prev) => ({
      ...prev,
      options: nextOptions,
    }));

    return createdOption;
  };

  const openReferenceDocumentsModal = () => {
    setReferenceDocumentsModal(true);
  };

  const closeReferenceDocumentsModal = () => {
    setReferenceDocumentsModal(false);
  };

  const saveReferenceDocumentsModal = (rows) => {
    setReferenceDocuments(normalizeDeliveryReferenceDocuments(rows));
    setReferenceDocumentsChanged(true);
    markDirty();
    setReferenceDocumentsModal(false);
  };

  const openItemModal = async (lineIndex) => {
    console.log('🔍 Opening item modal for line:', lineIndex);
    setItemModal({ open: true, lineIndex, items: [], loading: true });
    
    try {
      console.log('📡 Fetching items from API...');
      const selectedWarehouse = lines[lineIndex]?.whse || header.warehouse || '';
      const response = await fetchItemsForModal(selectedWarehouse);
      console.log('✅ Items received:', response.data);
      console.log('📊 Items count:', response.data.items?.length || 0);
      
      setItemModal(prev => ({
        ...prev,
        items: response.data.items || [],
        loading: false,
      }));
    } catch (error) {
      console.error('❌ Failed to load items:', error);
      console.error('Error details:', error.response?.data || error.message);
      setItemModal(prev => ({
        ...prev,
        items: [],
        loading: false,
      }));
    }
  };

  const closeItemModal = () => {
    setItemModal({ open: false, lineIndex: -1, items: [], loading: false });
  };

  const handleItemSelect = async (item) => {
    if (itemModal.lineIndex < 0) return;
    
    const lineIndex = itemModal.lineIndex;
    const mergedItem = mergeItemMaster(item, refData.items);
    
    console.log('🎯 [handleItemSelect] Item selected:', {
      ItemCode: item.ItemCode,
      ItemName: item.ItemName,
      BatchManaged: item.BatchManaged,
      ManBtchNum: item.ManBtchNum,
      isBatchManaged: isBatchManaged(item),
      SalesUnit: item.SalesUnit,
      InventoryUOM: item.InventoryUOM
    });
    
    try {
      const hsnRes = await fetchHSNCodeFromItem(mergedItem.ItemCode);
      const hsnData = hsnRes.data;
      
      // Get the current line to check warehouse
      const currentLine = lines[lineIndex];
      const itemIsBatchManaged = isBatchManaged(mergedItem);
      
      // Get UoM - prefer SalesUnit, fallback to InventoryUOM
      // Note: UoM codes can be numeric (e.g., "5.6" meaning 5.6BOX)
      const selectedUoM = mergedItem.SalesUnit || mergedItem.InventoryUOM || '';
      const displayUoM = selectedUoM;
      
      console.log('🔍 [handleItemSelect] Selected UoM:', {
        SalesUnit: item.SalesUnit,
        InventoryUOM: item.InventoryUOM,
        selectedUoM,
        displayUoM,
        UoMGroupEntry: item.UoMGroupEntry
      });
      
      // Log available UoMs for this item from UoM Group
      if (item.UoMGroupEntry && refData.uom_groups) {
        const uomGroup = refData.uom_groups.find(g => g.AbsEntry === item.UoMGroupEntry);
        if (uomGroup) {
          console.log('📦 [handleItemSelect] UoM Group Info:', {
            groupName: uomGroup.Name,
            availableUoMs: uomGroup.uomCodes,
            conversions: uomGroup.conversions
          });
        } else {
          console.warn('⚠️ [handleItemSelect] UoM Group not found:', item.UoMGroupEntry);
        }
      }
      
      // Fetch UoM conversion factor
      let uomFactor = 1;
      let inventoryUOM = mergedItem.InventoryUOM || '';
      
      if (selectedUoM && mergedItem.ItemCode) {
        try {
          console.log('🔍 [handleItemSelect] Fetching UoM conversion for:', {
            itemCode: item.ItemCode,
            selectedUoM,
            itemInventoryUOM: item.InventoryUOM
          });
          
          const uomRes = await fetchUomConversionFactor(mergedItem.ItemCode, selectedUoM);
          
          console.log('📦 [handleItemSelect] UoM API Response:', uomRes.data);
          
          uomFactor = uomRes.data.factor || 1;
          inventoryUOM = uomRes.data.inventoryUOM || mergedItem.InventoryUOM || '';
          
          const docQty = parseNum(currentLine.quantity);
          
          console.log('🔄 [handleItemSelect] UoM Conversion Applied:', {
            itemCode: item.ItemCode,
            documentUoM: selectedUoM,
            inventoryUOM,
            factor: uomFactor,
            documentQty: docQty,
            baseQty: docQty * uomFactor,
            calculation: `${docQty} ${selectedUoM} × ${uomFactor} = ${docQty * uomFactor} ${inventoryUOM}`
          });
        } catch (uomError) {
          console.error('❌ [handleItemSelect] Failed to fetch UoM conversion:', uomError);
          console.error('❌ [handleItemSelect] Error details:', {
            message: uomError.message,
            response: uomError.response?.data,
            status: uomError.response?.status
          });
        }
      } else {
        console.warn('⚠️ [handleItemSelect] Skipping UoM conversion - missing data:', {
          hasSelectedUoM: !!selectedUoM,
          hasItemCode: !!item.ItemCode
        });
      }
      
      // Check batch availability BEFORE updating state if item is batch-managed
      let hasBatchesAvailable = false;
      if (itemIsBatchManaged && currentLine.whse) {
        console.log('🔍 [handleItemSelect] Checking batch availability for:', {
          itemCode: item.ItemCode,
          warehouse: currentLine.whse
        });
        hasBatchesAvailable = await checkBatchAvailability(mergedItem.ItemCode, currentLine.whse);
        console.log('✅ [handleItemSelect] Batch availability result:', hasBatchesAvailable);
      }
      
      setLines(prev => prev.map((line, idx) => {
        if (idx === lineIndex) {
          const updatedLine = clearBaseDocumentLink({
            ...hydrateDocumentLineFromItem(line, mergedItem, {
              side: 'sales',
              hsnCode: hsnData.hsnCode || hsnData.hsn_sww || '',
              fallbackWarehouse: header.warehouse,
              syncUnitPriceUdf: false,
              calcLineTotal,
              formatTotal: (value) => fmtDec(value, numDec.total),
            }),
            uomCode: displayUoM, // Use the validated UoM for display
            uomName: mergedItem.SalesUnit || displayUoM || mergedItem.InventoryUOM || '',
            itemCost: mergedItem.ItemCost != null ? String(mergedItem.ItemCost) : (mergedItem.AvgPrice != null ? String(mergedItem.AvgPrice) : ''),
            price: line.unitPrice || '',
            batches: [],
            batchManaged: itemIsBatchManaged,
            hasBatchesAvailable: itemIsBatchManaged ? hasBatchesAvailable : false,
            inventoryUOM: inventoryUOM,
            uomFactor: uomFactor,
            taxAmount: '',
          });
          
          console.log('📝 [handleItemSelect] Updated line:', {
            itemNo: updatedLine.itemNo,
            batchManaged: updatedLine.batchManaged,
            hasBatchesAvailable: updatedLine.hasBatchesAvailable,
            warehouse: updatedLine.whse,
            uomCode: updatedLine.uomCode,
            inventoryUOM: updatedLine.inventoryUOM,
            uomFactor: updatedLine.uomFactor
          });
          
          // Auto-determine tax code
          const gstState = header.placeOfSupply;
          const companyState = refData.company_address?.State || selectedBranch?.State || '';
          
          if (gstState && companyState) {
            const determinedTaxCode = determineTaxCode(
              item,
              gstState,
              gstState,
              false,
              companyState,
              effectiveTaxCodes
            );
            
            if (determinedTaxCode) {
              updatedLine.taxCode = determinedTaxCode;
            }
          }
          
          updatedLine.total = fmtDec(calcLineTotal(updatedLine), numDec.total);
          return updatedLine;
        }
        return line;
      }));
      
      closeItemModal();
    } catch (error) {
      console.error('❌ [handleItemSelect] Error selecting item:', error);
      // Still set basic item info even if HSN fetch fails
      const currentLine = lines[lineIndex];
      const itemIsBatchManaged = isBatchManaged(mergedItem);
      const selectedUoM = mergedItem.SalesUnit || mergedItem.InventoryUOM || '';
      
      // Try to get UoM conversion in error case
      let uomFactor = 1;
      let inventoryUOM = mergedItem.InventoryUOM || '';
      
      if (selectedUoM && mergedItem.ItemCode) {
        try {
          const uomRes = await fetchUomConversionFactor(mergedItem.ItemCode, selectedUoM);
          uomFactor = uomRes.data.factor || 1;
          inventoryUOM = uomRes.data.inventoryUOM || mergedItem.InventoryUOM || '';
        } catch (uomError) {
          console.error('❌ [handleItemSelect] Failed to fetch UoM conversion in error handler:', uomError);
        }
      }
      
      // Check batch availability in error case too
      let hasBatchesAvailable = false;
      if (itemIsBatchManaged && currentLine.whse) {
        try {
          hasBatchesAvailable = await checkBatchAvailability(mergedItem.ItemCode, currentLine.whse);
        } catch (batchError) {
          console.error('❌ [handleItemSelect] Error checking batch availability:', batchError);
        }
      }
      
      setLines(prev => prev.map((line, idx) => {
        if (idx === lineIndex) {
          const updatedLine = clearBaseDocumentLink({
            ...hydrateDocumentLineFromItem(line, mergedItem, {
              side: 'sales',
              hsnCode: mergedItem.HSNCode || '',
              fallbackWarehouse: header.warehouse,
              syncUnitPriceUdf: false,
              calcLineTotal,
              formatTotal: (value) => fmtDec(value, numDec.total),
            }),
            uomCode: selectedUoM,
            uomName: mergedItem.SalesUnit || selectedUoM || mergedItem.InventoryUOM || '',
            itemCost: mergedItem.ItemCost != null ? String(mergedItem.ItemCost) : (mergedItem.AvgPrice != null ? String(mergedItem.AvgPrice) : ''),
            price: line.unitPrice || '',
            batches: [],
            batchManaged: itemIsBatchManaged,
            hasBatchesAvailable: itemIsBatchManaged ? hasBatchesAvailable : false,
            inventoryUOM: inventoryUOM,
            uomFactor: uomFactor,
            taxAmount: '',
          });
          updatedLine.total = fmtDec(calcLineTotal(updatedLine), numDec.total);
          
          return updatedLine;
        }
        return line;
      }));
      closeItemModal();
    }
  };

  // ── Freight Selection Modal handlers ──────────────────────────────────────
  const openFreightModal = async () => {
    console.log('🚚 Opening freight modal, docEntry:', currentDocEntry);
    if (freightModal.freightCharges.length > 0) {
      setFreightModal(prev => ({ ...prev, open: true, loading: false }));
      return;
    }
    setFreightModal(prev => ({ ...prev, open: true, loading: true }));
    
    try {
      console.log('📡 Fetching freight charges from API...');
      const response = await fetchFreightCharges(currentDocEntry);
      console.log('✅ Freight charges received:', response.data);
      console.log('📊 Freight charges count:', response.data.freightCharges?.length || 0);
      
      setFreightModal({
        open: true,
        freightCharges: response.data.freightCharges || [],
        loading: false
      });
    } catch (error) {
      console.error('❌ Failed to load freight charges:', error);
      console.error('Error details:', error.response?.data || error.message);
      setFreightModal({
        open: true,
        freightCharges: [],
        loading: false
      });
    }
  };

  const closeFreightModal = () => {
    setFreightModal(prev => ({ ...prev, open: false, loading: false }));
  };

  const handleFreightApply = (summary) => {
    console.log('🚚 Applied freight charges:', summary);
    setFreightModal(prev => ({
      ...prev,
      open: false,
      loading: false,
      freightCharges: summary.rows || [],
    }));
    setHeader(prev => ({
      ...prev,
      freight: fmtDec(summary.totalNet || 0, numDec.freight),
    }));
  };

  // ── Sync warehouse and branch from header to lines ────────────────────────
  // Sync branch to all lines when header branch changes
  useEffect(() => {
    if (isHydratingDocumentRef.current) return;
    console.log('🔄 [Delivery] Branch sync useEffect triggered');
    console.log('🔄 [Delivery] header.branch value:', header.branch);
    console.log('🔄 [Delivery] header.branch type:', typeof header.branch);
    console.log('🔄 [Delivery] Current lines count:', lines.length);
    
    if (!header.branch || !lines.some(l => String(l.branch || '') !== String(header.branch) || String(l.loc || '') !== String(header.branch))) return;

    if (header.branch) {
      console.log('🔄 [Delivery] Syncing branch to all lines:', header.branch);
      setLines(prev => {
        console.log('🔄 [Delivery] Previous lines:', prev.map(l => ({ itemNo: l.itemNo, branch: l.branch, loc: l.loc })));
        const updated = prev.map(l => ({ 
          ...l, 
          branch: String(header.branch), 
          loc: String(header.branch)
        }));
        console.log('✅ [Delivery] Updated lines:', updated.map(l => ({ itemNo: l.itemNo, branch: l.branch, loc: l.loc })));
        return updated;
      });
    } else {
      console.log('⚠️ [Delivery] Branch is empty, skipping sync');
    }
  }, [header.branch, lines]);
  
  // Initial sync: Set branch on existing lines when branch is first loaded
  useEffect(() => {
    if (isHydratingDocumentRef.current) return;
    if (header.branch && lines.length > 0) {
      const needsSync = lines.some(l => !l.branch || l.branch !== String(header.branch));
      if (needsSync) {
        console.log('🔄 [Delivery] Initial branch sync needed');
        setLines(prev => prev.map(l => ({ 
          ...l, 
          branch: String(header.branch), 
          loc: String(header.branch)
        })));
      }
    }
  }, [refData.branches]); // Trigger when branches are loaded

  useEffect(() => {
    if (isHydratingDocumentRef.current) return;
    if (!header.branch || !refData.warehouses.length) return;

    const allowedWarehouseCodes = new Set(
      branchFilteredWarehouses.map(w => String(w.WhsCode || ''))
    );

    setLines(prev => {
      let changed = false;
      const nextLines = prev.map(line => {
        if (!line.whse || allowedWarehouseCodes.has(String(line.whse))) {
          return line;
        }
        changed = true;
        return { ...line, whse: '', hasBatchesAvailable: false, batches: [] };
      });
      return changed ? nextLines : prev;
    });
  }, [branchFilteredWarehouses, header.branch, refData.warehouses.length]);

  // Sync warehouse to all lines when header warehouse changes and refresh batch availability
  useEffect(() => {
    if (isHydratingDocumentRef.current) return;
    if (!header.warehouse) {
      setLines(prev => {
        let changed = false;
        const nextLines = prev.map(l => {
          if (!l.whse && !l.hasBatchesAvailable && (!Array.isArray(l.batches) || l.batches.length === 0)) {
            return l;
          }
          changed = true;
          return { ...l, whse: '', hasBatchesAvailable: false, batches: [] };
        });
        return changed ? nextLines : prev;
      });
      return;
    }

    setLines(prev => {
      let changed = false;
      const nextLines = prev.map((line, index) => {
      const next = { ...line, whse: header.warehouse };

      if (next.itemNo && next.batchManaged) {
        next.hasBatchesAvailable = false;
        next.batches = [];

        checkBatchAvailability(next.itemNo, header.warehouse).then(hasBatches => {
          setLines(prevLines => prevLines.map((l, idx) => (
            idx === index ? { ...l, hasBatchesAvailable: hasBatches } : l
          )));
        });
      } else {
        next.hasBatchesAvailable = false;
        next.batches = [];
      }

      if (
        line.whse === next.whse &&
        line.hasBatchesAvailable === next.hasBatchesAvailable &&
        JSON.stringify(line.batches || []) === JSON.stringify(next.batches || [])
      ) {
        return line;
      }
      changed = true;
      return next;
      });
      return changed ? nextLines : prev;
    });
  }, [header.warehouse]);

  // ── Recalculate Tax Codes on State/Address Changes ────────────────────────
  useEffect(() => {
    if (currentDocEntry) return;
    if (!header.vendor || !header.placeOfSupply) return;

    const companyState = refData.company_address?.State || selectedBranch?.State || '';
    
    if (!companyState) {
      console.warn('⚠️ Company state not available for tax recalculation');
      return;
    }

    console.log('🔄 Recalculating Tax Codes for All Lines:', {
      placeOfSupply: header.placeOfSupply,
      companyState,
      gstType: getGSTTypeLabel(companyState, header.placeOfSupply),
    });

    // Recalculate tax codes for all lines with items using functional update
    setLines(prevLines => {
      return recalculateAllTaxCodes(
        prevLines,
        refData.items,
        header.placeOfSupply,  // shipToState
        header.placeOfSupply,  // billToState
        false,                 // useBillToForTax
        companyState,
        effectiveTaxCodes
      );
    });
  }, [currentDocEntry, header.placeOfSupply, header.vendor, refData.company_address, selectedBranch, refData.items, effectiveTaxCodes]);

  // Continue in next part...

  // ── validation ────────────────────────────────────────────────────────────
  const validate = async ({ validateDocumentLines = true } = {}) => {
    const isUpdate = !!currentDocEntry;
    const e = { header: {}, lines: {}, form: '' };
    
    // Frontend basic validation first
    if (!isUpdate) {
      const vc = String(header.vendor || '').trim();
      if (!vc) { e.header.vendor = 'Select a customer.'; e.form = 'Please correct the highlighted fields.'; return e; }
      if (!String(header.placeOfSupply || '').trim()) { e.header.placeOfSupply = 'Place of supply is required.'; e.form = 'Please correct the highlighted fields.'; return e; }
    }
    
    if (!String(header.postingDate || '').trim()) { e.header.postingDate = 'Posting date is required.'; e.form = 'Please correct the highlighted fields.'; return e; }
    if (!String(header.documentDate || '').trim()) { e.header.documentDate = 'Document date is required.'; e.form = 'Please correct the highlighted fields.'; return e; }
    if (!String(header.warehouse || '').trim()) { e.header.warehouse = 'Warehouse is required.'; e.form = 'Please correct the highlighted fields.'; return e; }
    for (const field of headerUdfDefinitions.filter(field => field.required)) {
      if (!String(headerUdfs[field.key] ?? '').trim()) {
        e.header[field.key] = `${field.label || field.key} is required.`;
        e.form = 'Please complete required UDF fields.';
        return e;
      }
    }

    const pop = lines.filter(l => String(l.itemNo || '').trim());
    if (validateDocumentLines && !pop.length) { e.form = 'Add at least one item line.'; return e; }
    
    for (let i = 0; validateDocumentLines && i < lines.length; i++) {
      const l = lines[i];
      if (!String(l.itemNo || '').trim()) continue;
      for (const field of rowUdfDefinitions.filter(field => field.required)) {
        if (!String(l.udf?.[field.key] ?? '').trim()) {
          e.lines[i] = { ...(e.lines[i] || {}), [field.key]: `${field.label || field.key} is required.` };
          e.form = 'Please complete required row UDF fields.';
          return e;
        }
      }

      if (!l.itemNo) {
        e.lines[i] = { ...(e.lines[i] || {}), itemNo: 'Item is required' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      if (!l.quantity || Number(l.quantity) <= 0) {
        e.lines[i] = { ...(e.lines[i] || {}), quantity: 'Quantity must be > 0' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      if (!l.hsnCode && !isUpdate) {
        e.lines[i] = { ...(e.lines[i] || {}), hsnCode: 'HSN Code is required' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      if ((!l.unitPrice || Number(l.unitPrice) <= 0) && !isUpdate) {
        e.lines[i] = { ...(e.lines[i] || {}), unitPrice: 'Unit Price must be > 0' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      if (!l.uomCode && !isUpdate) {
        e.lines[i] = { ...(e.lines[i] || {}), uomCode: 'UoM is required' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      if (!l.whse && !isUpdate) {
        e.lines[i] = { ...(e.lines[i] || {}), whse: 'Warehouse is required' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      // Enhanced tax code validation
      if (!l.taxCode || l.taxCode === 'Select' || l.taxCode === '') {
        e.lines[i] = { ...(e.lines[i] || {}), taxCode: 'Please select a valid Tax Code' };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }

      // Enhanced batch validation with UoM conversion
      if (!isUpdate && l.batchManaged && l.hasBatchesAvailable !== false) {
        if (!Array.isArray(l.batches) || l.batches.length === 0) {
          e.lines[i] = { ...(e.lines[i] || {}), batches: 'Batch selection is mandatory for batch-managed item' };
          e.form = 'Please correct the highlighted fields.';
          return e;
        }
        
        const baseQty = getRequiredBatchQty(l);
        const batchQty = sumBatchQty(l.batches);
        const inventoryUOM = l.inventoryUOM || l.uomCode || '';
        
        if (Math.abs(batchQty - baseQty) > BATCH_QTY_TOLERANCE) {
          e.lines[i] = { ...(e.lines[i] || {}), batches: `Batch quantity (${batchQty.toFixed(2)} ${inventoryUOM}) must match base quantity (${baseQty.toFixed(2)} ${inventoryUOM})` };
          e.form = 'Please correct the highlighted fields.';
          return e;
        }
      }
      
      const hasTaxCode = String(l.taxCode || '').trim();
      const taxCodeExists = !hasTaxCode || effectiveTaxCodes.some(t => String(t.Code) === String(l.taxCode));
      if (!taxCodeExists) {
        e.lines[i] = { ...(e.lines[i] || {}), taxCode: `Tax code '${l.taxCode}' is not valid in SAP B1` };
        e.form = 'Please correct the highlighted fields.';
        return e;
      }
    }
    
    // If frontend validation passes, call backend validation
    try {
      const submitBranch = alignBranchWithWarehouse(
        header.branch,
        header.warehouse || lines.find(l => String(l.whse || '').trim())?.whse,
        effectiveWarehouses
      );
      const validationPayload = {
        _isUpdate: isUpdate,
        validateDocumentLines,
        header: {
          customerCode: header.vendor,
          postingDate: header.postingDate,
          documentDate: header.documentDate,
          branch: submitBranch,
          series: header.series
        },
        lines: lines.filter(l => String(l.itemNo || '').trim()).map(l => ({
          itemNo: l.itemNo,
          quantity: l.quantity,
          unitPrice: l.unitPrice,
          hsnCode: l.hsnCode,
          whse: l.whse,
          taxCode: l.taxCode,
          uomCode: l.uomCode,
          uomFactor: l.uomFactor,
          inventoryUOM: l.inventoryUOM,
          baseEntry: l.baseEntry,
          baseType: l.baseType,
          baseLine: l.baseLine,
          batchManaged: l.batchManaged,
          batches: l.batches || [],
          udf: l.udf || {},
        }))
      };

      const backendValidation = await validateDeliveryDocument(validationPayload);
      
      if (!backendValidation.data.success) {
        // Map backend validation errors to frontend format
        const backendErrors = backendValidation.data.errors;
        
        for (const error of backendErrors) {
          if (error.includes('Customer Code')) {
            e.header.vendor = error;
          } else if (error.includes('Posting Date')) {
            e.header.postingDate = error;
          } else if (error.includes('Document Date')) {
            e.header.documentDate = error;
          } else if (error.includes('Branch')) {
            e.header.branch = error;
          } else if (error.includes('Tax Code')) {
            // Find the line number for tax code error
            const lineMatch = error.match(/line (\d+)/);
            if (lineMatch) {
              const lineIndex = parseInt(lineMatch[1]) - 1;
              e.lines[lineIndex] = { ...(e.lines[lineIndex] || {}), taxCode: 'Please select a valid Tax Code' };
            }
          } else if (
            error.includes('batch-managed') ||
            error.includes('Batch quantity') ||
            error.includes('exceeds available quantity')
          ) {
            // Find the line for batch error
            const itemMatch = error.match(/item ([^.,]+)/i);
            if (itemMatch) {
              const itemCode = itemMatch[1].trim();
              const lineIndex = lines.findIndex(l => l.itemNo === itemCode);
              if (lineIndex >= 0) {
                e.lines[lineIndex] = {
                  ...(e.lines[lineIndex] || {}),
                  batches: error.includes('batch-managed')
                    ? 'Batch selection is mandatory for batch-managed item'
                    : error
                };
              }
            }
          } else if (error.includes('Insufficient stock')) {
            // Find the line for stock error
            const itemMatch = error.match(/item ([A-Z0-9]+)/);
            if (itemMatch) {
              const itemCode = itemMatch[1];
              const lineIndex = lines.findIndex(l => l.itemNo === itemCode);
              if (lineIndex >= 0) {
                e.lines[lineIndex] = { ...(e.lines[lineIndex] || {}), quantity: error };
              }
            }
          } else if (error.includes('Warehouse') && error.includes('branch')) {
            // Find the line for warehouse-branch error
            for (let i = 0; i < lines.length; i++) {
              if (lines[i].whse) {
                e.lines[i] = { ...(e.lines[i] || {}), whse: 'Warehouse does not belong to selected branch' };
                break;
              }
            }
          } else if (error.includes('Series')) {
            e.header.series = error;
          } else {
            // Generic error
            e.form = error;
          }
        }
        
        e.form = e.form || 'Please correct the highlighted fields.';
      }
    } catch (validationError) {
      console.error('Backend validation error:', validationError);
      const backendErrors = validationError.response?.data?.errors || [];
      if (backendErrors.length > 0) {
        for (const error of backendErrors) {
          if (error.includes('Insufficient stock')) {
            const itemMatch = error.match(/item ([^ ]+) in warehouse/i);
            const itemCode = itemMatch?.[1];
            const lineIndex = lines.findIndex(l => String(l.itemNo) === String(itemCode));
            if (lineIndex >= 0) {
              e.lines[lineIndex] = { ...(e.lines[lineIndex] || {}), quantity: error };
            } else {
              e.form = error;
            }
          } else {
            e.form = error;
          }
        }
        e.form = e.form || 'Please correct the highlighted fields.';
      } else {
        e.form = getErrMsg(validationError, 'Delivery validation failed.');
      }
    }
    
    // Validate GST tax code combinations (after loop)
    const taxCodesUsed = new Set(pop.map(l => l.taxCode).filter(Boolean));
    const sgstCodes = getTaxComponentCodes(taxCodesUsed, effectiveTaxCodes, 'SGST');
    const cgstCodes = getTaxComponentCodes(taxCodesUsed, effectiveTaxCodes, 'CGST');

    if (sgstCodes.length > 0 && cgstCodes.length === 0) {
      e.form = 'SGST requires CGST to be applied as well. Please check tax codes in line items.';
      return e;
    }
    if (cgstCodes.length > 0 && sgstCodes.length === 0) {
      e.form = 'CGST requires SGST to be applied as well. Please check tax codes in line items.';
      return e;
    }
    if (sgstCodes.length > 0 && cgstCodes.length > 0) {
      const sgstRates = sgstCodes.map(code => {
        const tax = findTaxCode(effectiveTaxCodes, code);
        return tax ? parseNum(tax.Rate) : 0;
      });
      const cgstRates = cgstCodes.map(code => {
        const tax = findTaxCode(effectiveTaxCodes, code);
        return tax ? parseNum(tax.Rate) : 0;
      });
      if (sgstRates[0] !== cgstRates[0]) {
        e.form = 'SGST and CGST rates must be equal. Please check tax codes in line items.';
        return e;
      }
    }

    // Prevent save if total is 0
    const currentTotals = calcTotals();
    if (currentTotals.total <= 0) {
      e.form = 'Total amount must be greater than 0. Please add items with valid prices.';
      return e;
    }

    return e;
  };

  // ── Copy From handler ─────────────────────────────────────────────────────
  const handleCopyFrom = (data, sourceType) => {
    const sourceDocument = data || {};
    const unwrappedDocument =
      sourceDocument.sales_order ||
      sourceDocument.salesOrder ||
      sourceDocument.sales_quotation ||
      sourceDocument.salesQuotation ||
      sourceDocument.delivery ||
      sourceDocument.return ||
      sourceDocument.document ||
      sourceDocument;
    const srcHeader = unwrappedDocument.header ? unwrappedDocument.header : unwrappedDocument;
    const unwrappedLines = getDocumentLines(unwrappedDocument);
    const sourceLines = unwrappedLines.length ? unwrappedLines : getDocumentLines(sourceDocument);
    const baseType = BASE_TYPE[sourceType] || 17;
    const toDateInputValue = (value) => {
      if (!value) return '';
      const text = String(value);
      return text.includes('T') ? text.split('T')[0] : text.slice(0, 10);
    };
    const baseEntry =
      unwrappedDocument.DocEntry ??
      unwrappedDocument.docEntry ??
      unwrappedDocument.doc_entry ??
      sourceDocument.DocEntry ??
      sourceDocument.docEntry ??
      sourceDocument.doc_entry ??
      null;
    const normHeader = normaliseDocumentHeader(srcHeader);
    const firstSourceLine = sourceLines.length ? sourceLines[0] : {};
    const firstLineWarehouse =
      firstSourceLine?.whse ||
      firstSourceLine?.WarehouseCode ||
      firstSourceLine?.WhsCode ||
      '';
    const copiedLocation = resolveCopiedBranchWarehouse({
      sourceBranch: normHeader.branch || srcHeader.branch || srcHeader.BPL_IDAssignedToInvoice || srcHeader.BPLId,
      sourceWarehouse: srcHeader.warehouse,
      fallbackWarehouse: firstLineWarehouse,
      warehouses: refData.warehouses.length ? refData.warehouses : FALLBACK_WAREHOUSES,
    });

    setHeader(prev => ({
      ...prev,
      ...normHeader,
      deliveryDate: toDateInputValue(srcHeader.deliveryDate || srcHeader.DocDueDate || prev.deliveryDate || ''),
      vendor: normHeader.vendor || srcHeader.customerCode || srcHeader.customer || srcHeader.CardCode || '',
      name: normHeader.name || srcHeader.customerName || srcHeader.name || srcHeader.CardName || '',
      contactPerson: normHeader.contactPerson || srcHeader.contactPerson || srcHeader.CntctCode || '',
      branch: copiedLocation.branch,
      warehouse: copiedLocation.warehouse || prev.warehouse || '',
      paymentTerms: normHeader.paymentTerms || srcHeader.paymentTerms || srcHeader.GroupNum || '',
      placeOfSupply: normHeader.placeOfSupply || srcHeader.placeOfSupply || srcHeader.PlaceOfSupply || '',
      salesContractNo: srcHeader.salesContractNo || srcHeader.customerRefNo || srcHeader.NumAtCard || '',
      otherInstruction: normHeader.otherInstruction || srcHeader.otherInstruction || srcHeader.remarks || srcHeader.Comments || '',
      discount: srcHeader.discount || srcHeader.DiscPrcnt || '',
      freight: srcHeader.freight || srcHeader.Freight || '',
      tax: srcHeader.tax || srcHeader.TaxAmount || '',
      currency: srcHeader.currency || srcHeader.DocCur || prev.currency || 'INR',
      shipTo: srcHeader.shipTo || srcHeader.shipToAddress || srcHeader.Address || '',
      shipToCode: srcHeader.shipToCode || srcHeader.ShipToCode || '',
      shipToAddress: srcHeader.shipToAddress || srcHeader.shipTo || srcHeader.Address || '',
      payTo: srcHeader.payTo || srcHeader.billToAddress || srcHeader.Address2 || '',
      payToCode: srcHeader.payToCode || srcHeader.billToCode || srcHeader.PayToCode || '',
      billToCode: srcHeader.billToCode || srcHeader.payToCode || srcHeader.PayToCode || '',
      billToAddress: srcHeader.billToAddress || srcHeader.payTo || srcHeader.Address2 || '',
    }));
    setHeaderUdfs(normalizeUdfState(
      headerUdfDefinitions,
      mergeUdfValues(
        srcHeader.header_udfs,
        srcHeader.headerUdfs,
        sourceDocument.header_udfs,
        sourceDocument.headerUdfs,
        unwrappedDocument.header_udfs,
        unwrappedDocument.headerUdfs
      )
    ));

    const newLines = sourceLines.map((line, idx) => {
      const normalizedLine = normaliseDocumentLine(line, idx, baseEntry, baseType, copiedLocation.branch);
      return hydrateLoadedLine({
        ...createLine(rowUdfDefinitions),
        ...normalizedLine,
        baseEntry: line.baseEntry ?? line.BaseEntry ?? baseEntry,
        baseType: line.baseType ?? line.BaseType ?? baseType,
        baseLine: line.baseLine ?? line.BaseLine ?? line.lineNum ?? line.LineNum ?? normalizedLine.baseLine ?? idx,
        taxCode: normalizedLine.taxCode || line.taxCode || line.TaxCode || line.VatGroup || '',
        taxCodeManuallyOverridden: Boolean(String(normalizedLine.taxCode || line.taxCode || line.TaxCode || line.VatGroup || '').trim()),
        stcode: normalizedLine.stcode || line.stcode || '',
        branch: normalizedLine.branch || copiedLocation.branch,
        loc: normalizedLine.loc || copiedLocation.branch,
        whse: normalizedLine.whse || line.whse || line.WarehouseCode || line.WhsCode || copiedLocation.warehouse,
        udf: normalizeUdfState(
          rowUdfDefinitions,
          mergeUdfValues(pickLineUdfValues(line), line.line_udfs, line.lineUdfs, line.udf)
        ),
      });
    });
    const nextLines = newLines.length > 0 ? newLines : [createLine(rowUdfDefinitions)];
    copiedLinesNeedBatchOpenRef.current = !refData.items.length && newLines.some(line => line.itemNo);
    setLines(nextLines);
    refreshBatchAvailabilityForLines(nextLines);

    const cardCode = normHeader.vendor || srcHeader.customerCode || srcHeader.customer || srcHeader.CardCode;
    if (cardCode && cardCode !== header.vendor) loadVendorDetails(cardCode);

    const labels = { salesOrder: 'Sales Order', salesQuotation: 'Sales Quotation', delivery: 'Delivery', returns: 'Return', blanket: 'Blanket Agreement' };
    setPageState(p => ({ ...p, success: `Copied from ${labels[sourceType] || sourceType}` }));
  };

  // ── Copy From Modal Handlers ───────────────────────────────────────────────
  const openCopyFromModal = (docType) => {
    if (currentDocEntry) return;

    console.log('🟢 Copy From Clicked');

    // ✅ ONLY BUYER VALIDATION
    if (!header.vendor) {
      setValErrors({
        header: { vendor: 'Select Customer first' },
        lines: {},
        form: ''
      });
      return;
    }

    // ✅ CLEAR ALL ERRORS
    setValErrors({ header: {}, lines: {}, form: '' });
    setPageState(p => ({ ...p, error: '', success: '' }));

    setCopyFromDocType(docType);
    setCopyFromModal(true);
  };

  // ── Copy From fetch handlers ───────────────────────────────────────────────
  const fetchCopyFromDocuments = async (docType) => {
    try {
      const bpCode = String(header.vendor || '').trim();
      if (!bpCode) return [];

      // Sales Quotations: use dedicated API
      if (docType === 'salesQuotation') {
        const res = await fetchOpenSalesQuotationsForDelivery(bpCode);
        return res?.data?.quotations || res?.data?.documents || [];
      }
      // Sales Orders: filter by current customer for relevance
      if (docType === 'salesOrder') {
        const res = await fetchOpenSalesOrders(bpCode);
        return res?.data?.orders || [];
      }
      // Returns (AR Credit Memo): use dedicated API
      if (docType === 'returns') {
        const res = await fetchOpenReturnsForDelivery();
        return res?.data?.creditMemos || [];
      }
      // Blanket Agreements: use dedicated API
      if (docType === 'blanket') {
        const res = await fetchOpenBlanketAgreementsForDelivery();
        return res?.data?.agreements || [];
      }
      return await deliveryCopyFromApi.fetchOpenDocuments(docType, bpCode);
    } catch (err) {
      console.error('Error fetching documents:', err);
      throw err;
    }
  };

  const fetchCopyFromDocumentDetails = async (docType, docEntry) => {
    try {
      if (docType === 'salesQuotation') {
        const res = await fetchSalesQuotationForDeliveryCopy(docEntry);
        return res.data;
      }
      if (docType === 'salesOrder') {
        const res = await fetchSalesOrderForCopy(docEntry);
        const copyData = res.data || {};

        try {
          const detailRes = await fetchSalesOrderByDocEntry(docEntry);
          return mergeSalesOrderCopyUdfs(copyData, detailRes.data || {});
        } catch (detailError) {
          console.warn('Failed to load full sales order UDF detail. Using copy payload only.', detailError);
          return copyData;
        }
      }
      if (docType === 'returns') {
        const res = await fetchReturnForDeliveryCopy(docEntry);
        return res.data;
      }
      if (docType === 'blanket') {
        const res = await fetchBlanketAgreementForDeliveryCopy(docEntry);
        return res.data;
      }
      return await deliveryCopyFromApi.fetchDocumentForCopy(docType, docEntry);
    } catch (err) {
      console.error('Error fetching document details:', err);
      throw err;
    }
  };

  // ── Copy To handler ───────────────────────────────────────────────────────
  const handleCopyTo = async (targetType) => {
    await copyToDocument({
      sourceDocType: 'delivery',
      targetType,
      sourceDocEntry: currentDocEntry,
      sourceDocNo: header.docNo,
      sourcePath: location.pathname,
      sourceSnapshot: { header, lines, headerUdfs },
      restoreState: { deliveryDocEntry: currentDocEntry },
      navigate,
      upsertTask,
      removeTask,
      beforeNavigate: () => document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active')),
      setError: (message) => setPageState(p => ({ ...p, success: '', error: message })),
      errorMessage: 'Please save the delivery first before copying to another document.',
    });
  };

  const handleDuplicate = async () => {
    const duplicateDate = today();
    const duplicateWarehouse = resolveBatchWarehouseCode(
      lines.find(line => String(line.whse || '').trim())?.whse,
      header.warehouse
    );
    const duplicateLines = buildDuplicateLines(lines, createLine, rowUdfDefinitions).map(line => ({
      ...line,
      whse: duplicateWarehouse || line.whse || '',
      batches: [],
      hasBatchesAvailable: false,
    }));
    const duplicated = duplicateDocumentInPlace({
      currentDocEntry,
      header,
      initialHeader: INIT_HEADER,
      lines,
      createLine,
      rowUdfDefinitions,
      setCurrentDocEntry,
      setHeader,
      setLines: () => setLines(duplicateLines),
      setActiveTab,
      setValErrors,
      setPageState,
      setSnapshotPending,
      setIsDirty,
      setFreightModal,
      navigate,
      location,
      successMessage: 'Delivery duplicated. Review and add it as a new entry.',
    });

    if (duplicated) {
      setHeader(prev => ({
        ...prev,
        postingDate: duplicateDate,
        documentDate: duplicateDate,
        deliveryDate: duplicateDate,
        series: '',
        nextNumber: '',
      }));
      refreshBatchAvailabilityForLines(duplicateLines);

      try {
        const seriesResponse = await fetchDocumentSeries(duplicateDate);
        const duplicateSeries = seriesResponse.data?.series || [];
        setRefData(prev => ({ ...prev, series: duplicateSeries }));

        const defaultSeries = resolvePreferredSeries(duplicateSeries, duplicateDate, '');
        if (defaultSeries?.Series != null) {
          await handleSeriesChange(defaultSeries.Series);
        }
      } catch (_error) {
        const fallbackSeries = resolvePreferredSeries(refData.series, duplicateDate, '');
        if (fallbackSeries?.Series != null) {
          await handleSeriesChange(fallbackSeries.Series);
        }
      }
    }
  };

  // ── submit ────────────────────────────────────────────────────────────────
  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!isDocumentEditable) {
      setPageState(p => ({ ...p, error: 'This document is closed and cannot be edited.', success: '' }));
      return;
    }
    if (currentDocEntry && !hasUnsavedChanges) return;
    const isUpdate = Boolean(currentDocEntry);
    const documentLinesChanged = isUpdate && (
      !loadedLinesSignatureRef.current ||
      getDeliveryLinesUpdateSignature(lines) !== loadedLinesSignatureRef.current
    );
    if (!isUpdate && openRequiredBatchAllocationOnAdd()) return;

    const e = await validate({ validateDocumentLines: !isUpdate || documentLinesChanged });
    if (e.form || Object.values(e.header).some(Boolean) || Object.values(e.lines).some(le => Object.values(le || {}).some(Boolean))) {
      setValErrors(e);
      setPageState(p => ({ ...p, error: e.form || 'Please correct the highlighted fields.', success: '' }));
      const firstBatchErrorLineIndex = Object.entries(e.lines || {}).find(([, lineErrors]) =>
        Boolean(lineErrors?.batches)
      )?.[0];
      if (firstBatchErrorLineIndex !== undefined) {
        const lineIndex = Number(firstBatchErrorLineIndex);
        if (Number.isInteger(lineIndex) && lineIndex >= 0) {
          setActiveTab('Contents');
          window.setTimeout(() => openBatchModal(lineIndex), 0);
        }
      }
      return;
    }
    setValErrors({ header: {}, lines: {}, form: '' });
    setPageState(p => ({ ...p, posting: true, error: '', success: '' }));
    try {
      const submitBranch = alignBranchWithWarehouse(
        header.branch,
        header.warehouse || lines.find(line => String(line.whse || '').trim())?.whse,
        effectiveWarehouses
      );
      const prep = { 
        ...header, 
        customerCode: header.customerCode || header.vendor,
        customer: header.customer || header.vendor,
        deliveryDate: header.deliveryDate || header.postingDate || header.documentDate,
        placeOfSupply: header.placeOfSupply,
        branch: submitBranch,
        contactPerson: header.contactPerson,
        series: header.series ? Number(header.series) : undefined,
        totalPaymentDue: fmtDec(totals.total, numDec.totalPaymentDue),
        roundingAmount: fmtDec(totals.roundingAmount, numDec.totalPaymentDue),
      };
      
      const payload = {
        company_id: activeCompanyId,
        header: prep,
        lines: lines.map((line) => ({
          ...line,
          udf: buildVisibleEnteredRowUdfPayload(rowUdfDefinitions, line.udf || {}, formSettings),
        })),
        freightCharges: freightModal.freightCharges,
        eway_bill_details: eWayBillDetails,
        include_document_lines: !isUpdate || documentLinesChanged,
        reference_documents: referenceDocuments,
        reference_documents_changed: referenceDocumentsChanged && referenceDocuments.some(hasCompleteDeliveryReferenceDocument),
        header_udfs: normalizeUdfState(headerUdfDefinitions, headerUdfs),
      };
      const r = currentDocEntry ? await updateDelivery(currentDocEntry, payload) : await submitDelivery(payload);
      const dn = r.data.doc_num ? ` Doc No: ${r.data.doc_num}.` : '';
      setSnapshotPending(false);
      setIsDirty(false);
      defaultWarehouseAppliedRef.current = false;
      const resetHeader = createInitialHeader(generalSettingsRef.current);
      setCurrentDocEntry(null); setHeader(resetHeader); setLines([createLine(rowUdfDefinitions)]);
      setReferenceDocuments([]);
      setReferenceDocumentsChanged(false);
      setReferenceDocumentsModal(false);
      setEWayBillDetails({});
      setAttachments(INIT_ATTACH);
      setHeaderUdfs(createUdfState(headerUdfDefinitions)); setActiveTab('Contents');
      setRefData(p => ({ ...p, contacts: [], pay_to_addresses: [], ship_to_addresses: [], bill_to_addresses: [] }));
      setValErrors({ header: {}, lines: {}, form: '' });
      
      if (refData.series.length > 0) {
        const defaultSeries = resolvePreferredSeries(refData.series, resetHeader.postingDate);
        if (defaultSeries?.Series != null) {
          handleSeriesChange(defaultSeries.Series);
        }
      }
      
      setPageState(p => ({ ...p, success: `${r.data.message || 'Sales order saved.'}${dn}` }));
    } catch (e) {
      const message = getErrMsg(e, 'Delivery submission failed.');
      if (
        message.includes('batch-managed') ||
        message.includes('Batch selection') ||
        message.includes('Batch quantity') ||
        message.includes('exceeds available quantity')
      ) {
        const itemMatch = message.match(/item ([^.,]+)/i);
        const itemCode = itemMatch?.[1]?.trim();
        const hydratedLines = lines.map((line) => {
          if (itemCode && String(line.itemNo || '').trim() !== itemCode) return hydrateLoadedLine(line);
          return hydrateLoadedLine({ ...line, batchManaged: true, hasBatchesAvailable: true });
        });
        const lineIndex = itemCode
          ? hydratedLines.findIndex(line => String(line.itemNo || '').trim() === itemCode)
          : hydratedLines.findIndex(line => line.batchManaged && line.hasBatchesAvailable !== false);
        setLines(hydratedLines);
        if (lineIndex >= 0) {
          setActiveTab('Contents');
          setValErrors({
            header: {},
            lines: {
              [lineIndex]: {
                batches: message.includes('batch-managed')
                  ? 'Batch selection is mandatory for batch-managed item'
                  : message,
              },
            },
            form: 'Please assign batches before adding this delivery.',
          });
          window.setTimeout(() => openBatchModal(lineIndex, hydratedLines[lineIndex]), 0);
        }
      } else if (message.includes('Warehouse') && message.toLowerCase().includes('branch')) {
        const lineIndex = lines.findIndex(line => String(line.whse || '').trim());
        setValErrors({
          header: {},
          lines: lineIndex >= 0
            ? { [lineIndex]: { whse: 'Warehouse does not belong to selected branch' } }
            : {},
          form: 'Please correct the highlighted fields.',
        });
      }
      setPageState(p => ({ ...p, error: message, success: '' }));
    } finally {
      setPageState(p => ({ ...p, posting: false }));
    }
  };

  const resetForm = () => {
    defaultWarehouseAppliedRef.current = false;
    const resetHeader = createInitialHeader(generalSettingsRef.current);
    setSnapshotPending(false);
    setIsDirty(false);
    setCurrentDocEntry(null); setHeader(resetHeader); setLines([createLine(rowUdfDefinitions)]);
    setReferenceDocuments([]);
    setReferenceDocumentsChanged(false);
    setReferenceDocumentsModal(false);
    setEWayBillDetails({});
    setAttachments(INIT_ATTACH);
    setHeaderUdfs(createUdfState(headerUdfDefinitions)); setActiveTab('Contents');
    setValErrors({ header: {}, lines: {}, form: '' });
    setPageState(p => ({ ...p, error: '', success: '' }));
  };

  const visibleHeaderUdfs = headerUdfDefinitions.filter(f => formSettings.headerUdfs?.[f.key]?.visible !== false);
  const visibleRowUdfs = filterDeliveryRowUdfDefinitions(rowUdfDefinitions).filter(f => formSettings.rowUdfs?.[f.key]?.visible !== false);
  const isRightSidebarOpen = sidebarOpen || formSettingsOpen;

  useEffect(() => {
    const handleShortcut = (event) => {
      if (!event.altKey || event.ctrlKey || event.shiftKey || event.metaKey) return;
      if (pageState.posting || !isDocumentEditable) return;

      const key = String(event.key || '').toLowerCase();
      const shouldSubmit = (!isUpdateMode && key === 'a') || (isUpdateMode && hasUnsavedChanges && key === 'u');
      if (!shouldSubmit) return;

      event.preventDefault();
      formRef.current?.requestSubmit();
    };

    window.addEventListener('keydown', handleShortcut);
    return () => window.removeEventListener('keydown', handleShortcut);
  }, [hasUnsavedChanges, isDocumentEditable, isUpdateMode, pageState.posting]);

  // Continue in next part with render...

  // ── render ────────────────────────────────────────────────────────────────
  return (
    <form ref={formRef} className={`del-page sap-document-page${isRightSidebarOpen ? ' del-page--sidebar-open' : ''}`} onSubmit={handleSubmit} onChangeCapture={markDirty}>

      {/* toolbar */}
      <div className="del-toolbar sap-document-toolbar">
        <span className="del-toolbar__title">Delivery{currentDocEntry ? ` — #${header.docNo || currentDocEntry}` : ''}</span>
        <button type="submit" className="del-btn del-btn--primary sap-document-toolbar__primary" disabled={pageState.posting || !isDocumentEditable} title={primaryActionLabel}>
          {primaryActionLabel}
        </button>
        <button type="button" className="del-btn sap-document-toolbar__cancel" onClick={resetForm}>
          Cancel
        </button>
      
        <button
          type="button"
          className="del-btn sap-document-toolbar__udf"
          onClick={toggleHeaderUdfs}
        >
          {sidebarOpen ? 'Hide UDFs' : 'Show UDFs'}
        </button>
        <button type="button" className="del-btn sap-document-toolbar__settings" onClick={toggleFormSettings}>
          Form Settings
        </button>
        <PrintLayoutToolbar
          documentType="delivery"
          documentLabel="Delivery"
          docEntry={currentDocEntry}
          docNumber={header.docNo}
          series={header.series}
          cardCode={header.vendor}
          disabled={pageState.posting}
          classPrefix="del"
          onSuccess={(message) => setPageState(p => ({ ...p, error: '', success: message }))}
          onError={(message) => setPageState(p => ({ ...p, success: '', error: message }))}
        />
        <div className="del-dropdown" style={{ position: 'relative', display: 'inline-block' }}>
          <button
            type="button"
            className="del-btn"
            disabled={!isDocumentEditable || !!currentDocEntry || !hasBuyerCode}
            style={{ opacity: (!isDocumentEditable || !!currentDocEntry || !hasBuyerCode) ? 0.5 : 1 }}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (currentDocEntry || !hasBuyerCode) return;
              setValErrors({ header: {}, lines: {}, form: '' });
              setPageState(p => ({ ...p, error: '', success: '' }));
              const dropdown = e.currentTarget.parentElement;
              const isActive = dropdown.classList.contains('active');
              document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
              if (!isActive) dropdown.classList.add('active');
            }}
          >
            Copy From ▼
          </button>
          <div className="del-dropdown-menu">
            {[
              { key: 'salesQuotation', label: 'Sales Quotations' },
              { key: 'salesOrder',     label: 'Sales Orders' },
              { key: 'returns',        label: 'Returns' },
              { key: 'blanket',        label: 'Blanket Agreement' },
            ].map(opt => (
              <button
                key={opt.key}
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  openCopyFromModal(opt.key);
                  document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
        <div className="del-dropdown" style={{ position: 'relative', display: 'inline-block' }}>
          <button
            type="button"
            className="del-btn"
            disabled={!currentDocEntry}
            style={{ opacity: !currentDocEntry ? 0.5 : 1 }}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (!currentDocEntry) return;
              const dropdown = e.currentTarget.parentElement;
              const isActive = dropdown.classList.contains('active');
              document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
              if (!isActive) dropdown.classList.add('active');
            }}
          >
            Copy To ▼
          </button>
          <div className="del-dropdown-menu">
            {[
              { key: 'ar-invoice', label: 'A/R Invoice' },
            ].map(opt => (
              <button
                key={opt.key}
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleCopyTo(opt.key);
                  document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
        {currentDocEntry && (
          <button type="button" className="del-btn sap-document-toolbar__duplicate" onClick={handleDuplicate}>
            Duplicate
          </button>
        )}
        <button type="button" className="del-btn sap-document-toolbar__find" onClick={() => navigate('/delivery/find')}>Find</button>
        <button type="button" className="del-btn sap-document-toolbar__new" onClick={resetForm}>New</button>
      </div>

      {/* alerts */}
      {pageState.loading && <div className="del-alert del-alert--success" style={{ marginTop: 0 }}>Loading…</div>}
      {pageState.error && <div className="del-alert del-alert--error">{pageState.error}</div>}
      {pageState.success && <div className="del-alert del-alert--success">{pageState.success}</div>}
      {refData.warnings?.length > 0 && (
        <div className="alert alert-warning py-2" style={{ fontSize: 11 }}>
          <strong>SAP warnings:</strong>
          {refData.warnings.map((w, i) => <div key={i}>{w}</div>)}
          <div style={{ marginTop: 4, color: '#555' }}>Dropdowns are showing fallback values. Connect to SAP to load live data.</div>
          <div style={{ marginTop: 4, color: '#d00', fontWeight: 600 }}>⚠️ Tax codes shown are examples only. Use actual SAP tax codes to avoid submission errors.</div>
        </div>
      )}

      <fieldset disabled={!isDocumentEditable} style={{ border: 0, margin: 0, padding: 0, minWidth: 0 }}>
        <div className={`sap-document-layout del-layout${isRightSidebarOpen ? ' is-sidebar-open' : ' sap-document-layout--no-udf'}`}>

          <div className="sap-document-main del-layout__main">

            {/* ══ HEADER CARD ══════════════════════════════════════════════ */}
            <div className="del-header-card">
              <div className="row g-2">
                {/* LEFT COLUMN */}
                <div className="col-md-6">
                  <div className="del-field-grid del-field-grid--single">
                    
                    {/* Buyer's Code */}
                    <div className="del-field">
                      <label className="del-field__label">Buyer's Code *</label>
                      <div className="sap-input-group">
                         <input
                          name="vendor"
                          className={`del-field__input${valErrors.header.vendor ? ' del-field__input--error' : ''}`}
                         value={header.vendor}
                          onChange={handleHeaderChange}
                          disabled={!!currentDocEntry}
                          placeholder="Customer code"
                        />
                        <SapGoldenArrowButton
                          onClick={openBusinessPartnerLink}
                          disabled={!header.vendor}
                          title="Open Business Partner"
                        />
                        <button
                          type="button"
                          className="del-btn del-btn--lookup"
                          onClick={openBpModal}
                          disabled={!!currentDocEntry}
                          title="Select Business Partner"
                        >
                          ...
                        </button>
                      </div>
                    </div>

                    {/* Buyer's Name */}
                    <div className="del-field">
                      <label className="del-field__label">Buyer's Name</label>
                      <input name="name" className="del-field__input" value={header.name} readOnly />
                    </div>

                    <fieldset disabled={!hasBuyerCode} style={{ border: 0, margin: 0, padding: 0, minWidth: 0 }}>
                    {/* Contact Person */}
                    <div className="del-field">
                      <label className="del-field__label">Contact Person</label>
                      <select
                        name="contactPerson"
                        className="del-field__select"
                        value={header.contactPerson || ''}
                        onChange={handleHeaderChange}
                        disabled={pageState.vendorLoading || !header.vendor || !!currentDocEntry}
                      >
                        <option value="">Select</option>
                        {contactOptions.map(c => (
                          <option key={c.CntctCode} value={c.CntctCode}>
                            {c.Name || `${c.FirstName || ''} ${c.LastName || ''}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <DocumentCurrencySelect
                      classPrefix="del"
                      header={header}
                      onHeaderChange={handleHeaderChange}
                      businessPartners={refData.vendors || []}
                      disabled={pageState.vendorLoading || !header.vendor || !!currentDocEntry}
                    />

                    {/* Place of Supply */}
                    <div className="del-field">
                      <label className="del-field__label">Place of Supply *</label>
                      <div className="sap-input-group">
                        <input
                          name="placeOfSupply"
                          className={`del-field__input${valErrors.header.placeOfSupply ? ' del-field__input--error' : ''}`}
                          value={getStateDisplayName(header.placeOfSupply, refData.states)}
                          onChange={handleHeaderChange}
                          placeholder="State code"
                        />
                        <button
                          type="button"
                          className="del-btn del-btn--lookup"
                          onClick={openStateModal}
                          title="Select State"
                        >
                          ...
                        </button>
                      </div>
                    </div>

                    {/* Payment Terms */}
                    <div className="del-field">
                      <label className="del-field__label">Payment Terms</label>
                      <select name="paymentTerms" className="del-field__select" value={header.paymentTerms} onChange={handleHeaderChange}>
                        <option value="">Select</option>
                        {payTermOpts.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                      </select>
                    </div>

                    <div className="del-field">
                      <label className="del-field__label">Branch</label>
                      <select name="branch" className={`del-field__select${valErrors.header.branch ? ' del-field__select--error' : ''}`} value={normalizeSubmitBranch(header.branch)} onChange={handleHeaderChange} disabled={!!currentDocEntry}>
                        <option value="">Select Branch</option>
                        {!hasSelectedBranchOption && (
                          <option value={header.branch}>{`Branch ${header.branch}`}</option>
                        )}
                        {refData.branches.map(b => (
                          <option key={b.BPLId} value={b.BPLId}>
                            {b.BPLName}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Warehouse */}
                    <div className="del-field">
                      <label className="del-field__label">Warehouse *</label>
                      <select 
                        name="warehouse" 
                        className={`del-field__select${valErrors.header.warehouse ? ' del-field__select--error' : ''}`}
                        value={header.warehouse || ''} 
                        onChange={handleHeaderChange}
                      >
                        <option value="">Select Warehouse</option>
                        {branchFilteredWarehouses.map(w => (
                          <option key={w.WhsCode} value={w.WhsCode}>
                            {w.WhsCode} - {w.WhsName}
                          </option>
                        ))}
                      </select>
                    </div>
                    </fieldset>

                  </div>
                </div>

                {/* RIGHT COLUMN */}
                <div className="col-md-6">
                  <fieldset style={{ border: 0, margin: 0, padding: 0, minWidth: 0 }}>
                  <div className="del-field-grid del-field-grid--single">

                    {/* Series */}
                    <div className="del-field">
                      <label className="del-field__label">Series</label>
                      <select 
                        name="series"
                        className="del-field__select" 
                        value={header.series}
                        onChange={handleHeaderChange}
                        disabled={!!currentDocEntry || pageState.seriesLoading}
                      >
                        <option value="">Select Series</option>
                        {refData.series.map(s => (
                          <option key={s.Series} value={s.Series}>
                            {s.SeriesName} ({s.Indicator})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Auto Number */}
                    <div className="del-field">
                      <label className="del-field__label">Number</label>
                      <input 
                        name="nextNumber" 
                        className="del-field__input" 
                        value={currentDocEntry ? (header.docNo || header.nextNumber || '') : (pageState.seriesLoading ? '...' : header.nextNumber)}
                        readOnly 
                        style={{ background: '#f0f2f5' }}
                        title="Number will be assigned after saving"
                      />
                    </div>

                    {/* Customer Ref. No. */}
                    <div className="del-field">
                      <label className="del-field__label">Customer Ref. No.</label>
                      <input name="salesContractNo" className="del-field__input" value={header.salesContractNo} onChange={handleHeaderChange} />
                    </div>

                    {/* Status */}
                    <div className="del-field">
                      <label className="del-field__label">Status</label>
                      <input name="status" className="del-field__input" value={header.status} readOnly style={{ background: '#f0f2f5', color: header.status === 'Open' ? '#1a7a30' : '#c00', fontWeight: 600 }} />
                    </div>

                    {/* Posting Date */}
                    <div className="del-field">
                      <label className="del-field__label">Posting Date *</label>
                      <input type="date" name="postingDate" className={`del-field__input${valErrors.header.postingDate ? ' del-field__input--error' : ''}`} value={header.postingDate} onChange={handleHeaderChange} />
                    </div>

                    {/* Delivery Date */}
                    <div className="del-field">
                      <label className="del-field__label">Delivery Date</label>
                      <input type="date" name="deliveryDate" className="del-field__input" value={header.deliveryDate} onChange={handleHeaderChange} />
                    </div>

                    {/* Document Date */}
                    <div className="del-field">
                      <label className="del-field__label">Document Date *</label>
                      <input type="date" name="documentDate" className={`del-field__input${valErrors.header.documentDate ? ' del-field__input--error' : ''}`} value={header.documentDate} onChange={handleHeaderChange} />
                    </div>

                  </div>
                  </fieldset>
                </div>
              </div>
            </div>

            {/* ══ TABS ══════════════════════════════════════════════════════ */}
            <fieldset disabled={!hasBuyerCode} style={{ border: 0, margin: 0, padding: 0, minWidth: 0 }}>
            <div className="del-tabs" role="tablist" aria-label="Delivery details">
              {TAB_NAMES.map(t => (
                <div
                  key={t}
                  role="tab"
                  tabIndex={0}
                  aria-selected={activeTab === t}
                  className={`del-tab${activeTab === t ? ' del-tab--active' : ''}`}
                  onClick={() => setActiveTab(t)}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' || event.key === ' ') {
                      event.preventDefault();
                      setActiveTab(t);
                    }
                  }}
                >
                  {t}
                </div>
              ))}
            </div>

            {/* ══ TAB CONTENT ═══════════════════════════════════════════════ */}
            {activeTab === 'Contents' && (
              <ContentsTab
                lines={lines}
                onLineChange={handleLineChange}
                onNumBlur={handleNumBlur}
                onAddLine={addLine}
                onRemoveLine={removeLine}
                onOpenBatchModal={openBatchModal}
                onOpenHSNModal={openHSNModal}
                onOpenItemModal={openItemModal}
                lineItemOptions={lineItemOptions}
                getUomOptions={getUomOptions}
                effectiveTaxCodes={effectiveTaxCodes}
                effectiveWarehouses={branchFilteredWarehouses}
                fmtTaxLabel={fmtTaxLabel}
                getBranchName={getBranchName}
                valErrors={valErrors}
                distributionRules={refData.distribution_rules || []}
                onOpenQualityModal={openQualityModal}
                onOpenPaymentTermsModal={openPaymentTermsModal}
                formSettings={formSettings}
                matrixFields={matrixColumnDefinitions}
                rowUdfFields={visibleRowUdfs}
                onRowUdfChange={handleRowUdfChange}
                currency={header.currency || 'INR'}
              />
            )}

            {activeTab === 'Logistics' && (
              <LogisticsTab
                header={header}
                onHeaderChange={handleHeaderChange}
                vendorShipToAddresses={vendorEffectiveShipToAddresses}
                vendorBillToAddresses={vendorEffectiveBillToAddresses}
                shipTypeOpts={shipTypeOpts}
                onOpenAddressModal={openAddressModal}
                isEditable={isDocumentEditable}
              />
            )}

            {activeTab === 'Accounting' && (
              <AccountingTab
                header={header}
                onHeaderChange={handleHeaderChange}
                payTermOpts={payTermOpts}
                paymentMethodOpts={paymentMethodOpts}
                referenceDocuments={referenceDocuments}
                onOpenReferenceDocuments={openReferenceDocumentsModal}
                isEditable={isDocumentEditable}
              />
            )}

            {activeTab === 'Tax' && (
              <TaxTab
                header={header}
                onHeaderChange={handleHeaderChange}
                onOpenTaxInfoModal={openTaxInfoModal}
                isEditable={isDocumentEditable}
              />
            )}

            {activeTab === 'Electronic Documents' && (
              <ElectronicDocumentsTab
                header={header}
                onHeaderChange={handleHeaderChange}
                formats={refData.eway_bill_formats || []}
                onOpenEWayBill={() => setEWayBillModalOpen(true)}
                disabled={!isDocumentEditable}
              />
            )}

            {activeTab === 'Attachments' && (
              <AttachmentsTab
                attachments={attachments}
                onBrowseAttachment={handleBrowseAttachment}
              />
            )}

            {/* Continue in next part... */}

            {/* ══ TOTALS FOOTER ═════════════════════════════════════════════ */}
            <div className="del-header-card">
              <div className="del-field-grid del-field-grid--summary">
                <div>
                  <div className="del-field">
                    <label className="del-field__label">Sales Employee</label>
                    <select name="purchaser" className="del-field__select" value={header.purchaser || ''} onChange={handleHeaderChange}>
                      <option value="">No Sales Employee / Buyer</option>
                      {effectiveSalesEmployees
                        .filter(employee => String(employee.SlpCode) !== '-1')
                        .map(employee => (
                          <option key={employee.SlpCode} value={employee.SlpName}>
                            {employee.SlpName}
                          </option>
                        ))}
                      <option value="__DEFINE_NEW__">Define New</option>
                    </select>
                  </div>
                  <div className="del-field">
                    <label className="del-field__label">Owner</label>
                    <input name="owner" className="del-field__input" value={header.owner || ''} onChange={handleHeaderChange} />
                  </div>
                  <div className="del-field">
                    <label className="del-field__label">Remarks</label>
                    <textarea className="del-textarea" rows={3} name="otherInstruction" value={header.otherInstruction} onChange={handleHeaderChange} />
                  </div>
                </div>
                <div>
                  <div className="del-section-title">Tax Summary</div>
                  {totals.taxBreakdown.length > 0 && (
                    <div style={{ marginBottom: '12px' }}>
                      {totals.taxBreakdown.map(t => (
                        <div key={t.taxCode} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 4 }}>
                          <span>{t.taxCode} ({t.taxRate}%)</span>
                          <span>{fmtDec(t.taxAmount, numDec.tax)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="del-grid-wrap">
                    <table className="del-grid" style={{ marginTop: '8px' }}>
                      <tbody>
                        <tr>
                          <td>Total Before Discount</td>
                          <td className="del-grid__cell--num"><input className="del-grid__input" value={fmtDec(totals.subtotal, numDec.total)} readOnly /></td>
                        </tr>
                        <tr>
                          <td>Discount %</td>
                          <td className="del-grid__cell--num"><input className="del-grid__input" name="discount" value={header.discount} onChange={handleHeaderChange} onBlur={() => handleNumBlur('discount', 'header')} /></td>
                        </tr>
                        <tr>
                          <td>Freight</td>
                          <td className="del-grid__cell--num" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <input 
                              className="del-grid__input" 
                              name="freight" 
                              value={header.freight} 
                              onChange={handleHeaderChange} 
                              onBlur={() => handleNumBlur('freight', 'header')} 
                              style={{ flex: 1 }}
                            />
                            <button
                              type="button"
                              onClick={openFreightModal}
                              style={{
                                padding: '2px 8px',
                                fontSize: '11px',
                                border: '1px solid #d0d7de',
                                borderRadius: '3px',
                                background: 'linear-gradient(180deg, #f6f8fa 0%, #e9ecef 100%)',
                                cursor: 'pointer',
                                minWidth: '24px'
                              }}
                              title="Select Freight Charge"
                            >
                              ...
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td><input type="checkbox" className="" name="rounding" checked={header.rounding} onChange={handleHeaderChange} style={{ marginRight: 6 }} /><span>Rounding</span></td>
                          <td className="del-grid__cell--num">
                            <input className="del-grid__input" value={fmtDec(totals.roundingAmount, numDec.totalPaymentDue)} readOnly />
                          </td>
                        </tr>
                        <tr>
                          <td>Tax</td>
                          <td className="del-grid__cell--num"><input className="del-grid__input" value={fmtDec(totals.taxAmt, numDec.tax)} readOnly /></td>
                        </tr>
                        <tr style={{ borderTop: '2px solid #a0aab4' }}>
                          <td style={{ fontWeight: 700, color: '#003366' }}>Total</td>
                          <td className="del-grid__cell--num" style={{ fontWeight: 700, color: '#003366' }}><input className="del-grid__input" style={{ fontWeight: 700, color: '#003366' }} value={fmtDec(totals.total, numDec.totalPaymentDue)} readOnly /></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            {/* ══ ACTION BUTTONS ════════════════════════════════════════════ */}
            {false && (
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '12px', marginBottom: '12px', gap: '8px' }}>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button type="submit" className="del-btn del-btn--primary" disabled={pageState.posting}>
                  {secondaryActionLabel}
                </button>
                <button type="button" className="del-btn" onClick={resetForm}>
                  Cancel
                </button>
              </div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                {/* Copy From Dropdown - SAP B1 style, same as Sales Order */}
                <div className="del-dropdown">
                  <button
                    type="button"
                    className="del-btn"
                    disabled={!isDocumentEditable || !!currentDocEntry || !hasBuyerCode}
                    style={{ opacity: (!isDocumentEditable || !!currentDocEntry || !hasBuyerCode) ? 0.5 : 1 }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (currentDocEntry || !hasBuyerCode) return;
                      setValErrors({ header: {}, lines: {}, form: '' });
                      setPageState(p => ({ ...p, error: '', success: '' }));
                      const dropdown = e.currentTarget.parentElement;
                      const isActive = dropdown.classList.contains('active');
                      document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
                      if (!isActive) dropdown.classList.add('active');
                    }}
                  >
                    Copy From ▼
                  </button>
                  <div className="del-dropdown-menu">
                    {[
                      { key: 'salesQuotation', label: 'Sales Quotations' },
                      { key: 'salesOrder',     label: 'Sales Orders' },
                      { key: 'returns',        label: 'Returns' },
                      { key: 'blanket',        label: 'Blanket Agreement' },
                    ].map(opt => (
                      <button
                        key={opt.key}
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          openCopyFromModal(opt.key);
                          document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Copy To Dropdown - SAP B1 style */}
                <div className="del-dropdown">
                  <button
                    type="button"
                    className="del-btn"
                    disabled={!currentDocEntry}
                    style={{ opacity: !currentDocEntry ? 0.5 : 1 }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (!currentDocEntry) return;
                      const dropdown = e.currentTarget.parentElement;
                      const isActive = dropdown.classList.contains('active');
                      document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
                      if (!isActive) dropdown.classList.add('active');
                    }}
                  >
                    Copy To ▼
                  </button>
                  <div className="del-dropdown-menu">
                    {[
                      { key: 'ar-invoice', label: 'A/R Invoice' },
                    ].map(opt => (
                      <button
                        key={opt.key}
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          handleCopyTo(opt.key);
                          document.querySelectorAll('.del-dropdown').forEach(d => d.classList.remove('active'));
                        }}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            )}

          </fieldset>

          </div>{/* end main col */}

          <HeaderUdfSidebar
            className="sap-header-udf-panel del-layout__sidebar"
            isOpen={sidebarOpen}
            fields={visibleHeaderUdfs}
            formSettings={formSettings}
            values={headerUdfs}
            disabled={!hasBuyerCode}
            onFieldChange={handleHeaderUdfChange}
            onClose={() => setSidebarOpen(false)}
          />
          <FormSettingsPanel
            variant="sidebar"
            className="sap-header-udf-panel del-layout__sidebar"
            isOpen={formSettingsOpen}
            onClose={() => setFormSettingsOpen(false)}
            matrixFields={matrixColumnDefinitions}
            headerUdfFields={headerUdfDefinitions}
            rowUdfFields={filterDeliveryRowUdfDefinitions(rowUdfDefinitions)}
            formSettings={formSettings}
            onSettingChange={updateFormSetting}
          />
        </div>
      </fieldset>

      <EWayBillModal
        isOpen={eWayBillModalOpen}
        onClose={() => setEWayBillModalOpen(false)}
        onSave={saveEWayBillDetails}
        udfValues={headerUdfs}
        udfDefinitions={headerUdfDefinitions}
        liveData={effectiveEWayBillLiveData}
        transporters={refData.eway_bill_transporters || []}
        dropdownOptions={refData.eway_bill_options || {}}
        workspaceRef={formRef}
        disabled={!isDocumentEditable}
      />

      {/* Address Component Modal */}
      <AddressModal
        isOpen={!!addressModal}
        onClose={closeAddressModal}
        onSave={saveAddressModal}
        addressForm={addressForm}
        onFormChange={handleAddressFormChange}
        states={refData.states}
      />

      {/* Tax Information Modal */}
      <TaxInfoModal
        isOpen={taxInfoModal}
        onClose={closeTaxInfoModal}
        onSave={saveTaxInfoModal}
        taxInfoForm={taxInfoForm}
        onFormChange={handleTaxInfoFormChange}
        disabled={!isDocumentEditable}
      />

      <BatchAllocationModal
        isOpen={batchModal.open}
        line={batchModal.lineIndex != null ? lines[batchModal.lineIndex] : null}
        availableBatches={batchModal.availableBatches}
        loading={batchModal.loading}
        error={batchModal.error}
        onClose={closeBatchModal}
        onSave={saveLineBatches}
      />

      {/* State Selection Modal */}
      <StateSelectionModal
        isOpen={stateModal}
        onClose={closeStateModal}
        onSelect={handleStateSelect}
        states={refData.states || []}
      />

      {/* Business Partner Selection Modal */}
      <BusinessPartnerModal
        isOpen={bpModal}
        onClose={closeBpModal}
        onSelect={handleBpSelect}
        businessPartners={refData.vendors || []}
      />

      {/* HSN Code Selection Modal */}
      <HSNCodeModal
        isOpen={hsnModal.open}
        onClose={closeHSNModal}
        onSelect={handleHSNSelect}
      />

      {/* Item Selection Modal */}
      <ItemSelectionModal
        isOpen={itemModal.open}
        onClose={closeItemModal}
        onSelect={handleItemSelect}
        items={itemModal.items}
        loading={itemModal.loading}
      />

      <QualitySelectionModal
        isOpen={qualityModal.open}
        onClose={closeQualityModal}
        onSelect={handleQualitySelect}
        onCreate={handleQualityCreate}
        options={qualityModal.options}
        title={qualityModal.title}
        searchPlaceholder={qualityModal.searchPlaceholder}
        emptyMessage={qualityModal.emptyMessage}
        allowCreate={qualityModal.allowCreate}
      />

      {/* Copy From Modal */}
      <CopyFromModal
        isOpen={copyFromModal}
        onClose={() => setCopyFromModal(false)}
        onCopy={handleCopyFrom}
        documentType={copyFromDocType}
        onFetchDocuments={fetchCopyFromDocuments}
        onFetchDocumentDetails={fetchCopyFromDocumentDetails}
      />

      {salesEmployeeSetup.open && (
        <div className="sap-setup-overlay" role="dialog" aria-modal="true">
          <div className="sap-setup-window">
            <div className="sap-setup-titlebar">
              <span>Sales Employees/Buyers - Setup</span>
              <div className="sap-setup-window-actions">
                <button type="button" aria-label="Close" onClick={closeSalesEmployeeSetup}>x</button>
              </div>
            </div>
            <div className="sap-setup-body">
              <div className="sap-setup-grid-wrap">
                <table className="sap-setup-grid">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Sales Employee Name</th>
                      <th>Commission Group</th>
                      <th>Commission %</th>
                      <th>Remarks</th>
                      <th>Active</th>
                      <th>Employee</th>
                      <th>T...</th>
                    </tr>
                  </thead>
                  <tbody>
                    {salesEmployeeSetup.rows.map((row, index) => (
                      <tr key={`${row.SlpCode || 'new'}-${index}`}>
                        <td>{index + 1}</td>
                        <td>
                          <input
                            value={row.SlpName}
                            onChange={event => updateSalesEmployeeSetupRow(index, 'SlpName', event.target.value)}
                            disabled={row.SlpCode === -1}
                          />
                        </td>
                        <td>
                          <select value="user-defined" disabled={row.SlpCode === -1}>
                            <option value="user-defined">User-Defined Commission</option>
                          </select>
                        </td>
                        <td>
                          <input
                            className="sap-setup-num"
                            value={row.Commission}
                            onChange={event => updateSalesEmployeeSetupRow(index, 'Commission', sanitize(event.target.value, numDec.discount))}
                            disabled={row.SlpCode === -1}
                          />
                        </td>
                        <td>
                          <input
                            value={row.Memo}
                            onChange={event => updateSalesEmployeeSetupRow(index, 'Memo', event.target.value)}
                            disabled={row.SlpCode === -1}
                          />
                        </td>
                        <td>
                          <input
                            type="checkbox"
                            checked={row.Active}
                            onChange={event => updateSalesEmployeeSetupRow(index, 'Active', event.target.checked)}
                            disabled={row.SlpCode === -1}
                          />
                        </td>
                        <td>
                          <input
                            type="checkbox"
                            checked={row.Employee}
                            onChange={event => updateSalesEmployeeSetupRow(index, 'Employee', event.target.checked)}
                            disabled={row.SlpCode === -1}
                          />
                        </td>
                        <td></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="sap-setup-footer">
                <div>
                  <button type="button" className="sap-setup-primary" onClick={saveSalesEmployeeSetup} disabled={salesEmployeeSetup.saving}>
                    {salesEmployeeSetup.saving ? 'Saving...' : 'OK'}
                  </button>
                  <button type="button" onClick={closeSalesEmployeeSetup} disabled={salesEmployeeSetup.saving}>Cancel</button>
                </div>
                <button type="button" disabled>Set as Default</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <ReferenceDocumentsModal
        isOpen={referenceDocumentsModal}
        referenceDocuments={referenceDocuments}
        onClose={closeReferenceDocumentsModal}
        onSave={saveReferenceDocumentsModal}
        isEditable={isDocumentEditable}
        cardCode={header.vendor}
        onOpenDocument={openReferenceDocument}
      />

      {/* Freight Selection Modal */}
      <FreightChargesModal
        isOpen={freightModal.open}
        onClose={closeFreightModal}
        onApply={handleFreightApply}
        freightCharges={freightModal.freightCharges}
        taxCodes={effectiveTaxCodes}
        loading={freightModal.loading}
      />
    </form>
  );
}

export default Delivery;
